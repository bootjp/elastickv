package kv

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"log/slog"
	"maps"
	"slices"
	"sync"
	"sync/atomic"
	"time"

	"github.com/bootjp/elastickv/distribution"
	"github.com/bootjp/elastickv/internal/monoclock"
	"github.com/bootjp/elastickv/internal/raftengine"
	"github.com/bootjp/elastickv/keyviz"
	pb "github.com/bootjp/elastickv/proto"
	"github.com/bootjp/elastickv/store"
	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/errors/secondary"
)

type ShardGroup struct {
	Engine raftengine.Engine
	Store  store.MVCCStore
	Txn    Transactional
	// TSOState is set only for reserved group 0. Keeping the applied floor and
	// cutover marker next to the group's engine lets the leader allocator read
	// consensus-owned state without treating the shared HLC mirror as durable.
	TSOState *TSOStateMachine
	lease    leaseState
	// lp caches the Engine's optional LeaseProvider capability so the
	// groupLeaseRead / maybeRefresh hot paths test a single field for
	// nil instead of performing an interface type assertion per call.
	// NewShardedCoordinator resolves it once for every group it owns; it
	// is nil when the Engine does not implement raftengine.LeaseProvider.
	// Engine is not reassigned after the coordinator is constructed, so
	// the cached value stays valid.
	lp raftengine.LeaseProvider
	// raftPayloadWrap is the Stage 6E-2c hot-swap point for the raft
	// envelope wrap closure. A nil load means the wrap is inactive
	// and proposals pass through cleartext (the Stage 3 default).
	// A non-nil load applies the closure to every payload before it
	// reaches the engine — Propose and ProposeAdmin alike, by
	// design (see kv/raft_payload_wrapper.go for the rationale).
	//
	// The cell is read on every proposal via dynamicWrappedProposer,
	// installed in the TransactionManager's proposer chain AND on
	// the cached proposer below when the ShardGroup is constructed
	// via NewLeaderProxyForShardGroup. SetRaftPayloadWrap publishes
	// a fresh closure atomically so EnableRaftEnvelope (Stage
	// 6E-2d) can activate the wrap the instant the cutover entry
	// commits, without rebuilding the TransactionManager or
	// stalling in-flight proposals.
	raftPayloadWrap            atomic.Pointer[RaftPayloadWrapper]
	raftPayloadWrapInvalidator atomic.Pointer[func() func()]
	// proposer is the wrap-aware proposer chain for this shard
	// group. Set by NewLeaderProxyForShardGroup so direct shard
	// proposals (HLC lease renewal — see RunHLCLeaseRenewal —
	// and any future direct-engine.Propose call site) route
	// through the same dynamicWrappedProposer the
	// TransactionManager uses. The Proposer() accessor falls back
	// to Engine when this is nil (the legacy / test-fixture path
	// that constructs ShardGroup via struct literal without
	// NewLeaderProxyForShardGroup), so the no-wrap default keeps
	// working.
	proposer raftengine.Proposer
	// leaderRead forwards a read barrier to this group's current leader when
	// the local replica is a follower. It is installed with the LeaderProxy.
	leaderRead func(context.Context) (leaseReadResult, error)
	// leaderReadToken authenticates follower-to-leader lease-read RPCs. Admin
	// service setup publishes it once before the public listeners are opened.
	leaderReadToken atomic.Pointer[string]
}

// SetLeaderReadToken configures the bearer token used by forwarded lease-read
// RPCs. An empty token preserves explicitly configured insecure admin mode.
func (g *ShardGroup) SetLeaderReadToken(token string) {
	if token == "" {
		g.leaderReadToken.Store(nil)
		return
	}
	t := token
	g.leaderReadToken.Store(&t)
}

func (g *ShardGroup) forwardedLeaderReadToken() string {
	if g == nil {
		return ""
	}
	token := g.leaderReadToken.Load()
	if token == nil {
		return ""
	}
	return *token
}

// Proposer returns the wrap-aware proposer chain installed by
// NewLeaderProxyForShardGroup, or the raw Engine when the
// constructor was bypassed (legacy / test fixtures that build
// ShardGroup via struct literal). Direct shard proposals
// (HLC lease renewal, future cipher rotations, etc.) MUST go
// through this getter rather than g.Engine.Propose so the
// Stage 6E-2c dynamic wrap path applies — a direct g.Engine
// Propose call would bypass the wrap pointer and let post-cutover
// writes land cleartext above the raft-envelope cutover, halting
// the apply loop on §6.3 strict-> unwrap (codex P2 round-1).
func (g *ShardGroup) Proposer() raftengine.Proposer {
	if g.proposer != nil {
		return g.proposer
	}
	return g.Engine
}

// SetRaftPayloadWrap publishes wrap as the active raft envelope
// closure for this shard group. Passing nil clears the wrap (the
// proposer reverts to cleartext pass-through). Safe to call from
// any goroutine; the next Propose / ProposeAdmin observes the new
// state via the proposer's atomic.Pointer.Load.
//
// This is the sole supported way to install or rotate the wrap
// closure on a running coordinator. Stage 6E-2d's
// EnableRaftEnvelope handler will call this on every leader when
// the cutover entry commits.
func (g *ShardGroup) SetRaftPayloadWrap(wrap RaftPayloadWrapper) {
	g.SetObservedRaftPayloadWrap(wrap)
}

// RaftPayloadWrap returns the currently-installed wrap closure, or
// nil if the wrap is inactive. Primarily intended for tests and
// diagnostics; production proposers consult the underlying
// atomic.Pointer directly (see dynamicWrappedProposer).
func (g *ShardGroup) RaftPayloadWrap() RaftPayloadWrapper {
	if p := g.raftPayloadWrap.Load(); p != nil {
		return *p
	}
	return nil
}

// cutoverBarrierProposer is the optional interface a Proposer can
// satisfy to participate in the §7.1 quiescence barrier. Production
// proposers built via NewLeaderProxyForShardGroup (i.e.,
// *dynamicWrappedProposer) implement it; test fixtures that wire a
// bare engine into ShardGroup.Engine do not. The ShardGroup
// forwarders below type-assert on this interface so the barrier
// control degrades gracefully (immediate-success drain, no-op
// Begin/End) when the proposer can't participate.
type cutoverBarrierProposer interface {
	raftengine.Proposer
	BeginCutoverBarrier() <-chan struct{}
	WaitInflightDrained(ctx context.Context) error
	EndCutoverBarrier()
}

// BeginCutoverBarrier opens the §7.1 step-1 quiescence barrier on
// this shard group's proposer chain. Returns a channel that closes
// when all in-flight user Propose calls drain; the typical caller
// uses WaitInflightDrained which composes context cancellation.
//
// Forwards to *dynamicWrappedProposer when present. When the
// proposer is the bare engine (raw Engine fallback in test
// fixtures), returns a pre-closed channel so callers that don't
// distinguish barrier-capable from -incapable proposers can drive
// the same state-machine shape against either.
//
// 6E-2d wiring: every leader's EnableRaftEnvelope handler calls this
// on each ShardGroup that participates in the cutover before
// proposing the cutover entry. After return, the proposer's
// dynamicWrappedProposer.Propose rejects fresh user calls with
// raftengine.ErrEnvelopeCutoverInProgress.
func (g *ShardGroup) BeginCutoverBarrier() <-chan struct{} {
	if cbp, ok := g.Proposer().(cutoverBarrierProposer); ok {
		return cbp.BeginCutoverBarrier()
	}
	ch := make(chan struct{})
	close(ch)
	return ch
}

// WaitInflightDrained blocks until the in-flight Propose counter
// drops to 0 after BeginCutoverBarrier ran on this ShardGroup, or
// ctx fires. Returns nil on drain or when the proposer is barrier-
// incapable (degraded fast-path so test fixtures don't deadlock
// the handler). Wraps ctx.Err() on cancellation.
func (g *ShardGroup) WaitInflightDrained(ctx context.Context) error {
	if cbp, ok := g.Proposer().(cutoverBarrierProposer); ok {
		// dynamicWrappedProposer.WaitInflightDrained returns raw
		// ctx.Err() so this single wrap is the canonical operator-
		// log entry (claude r2 finding B: avoid the redundant
		// "kv: ... kv: ..." chain a doubled wrap would produce).
		if err := cbp.WaitInflightDrained(ctx); err != nil {
			return errors.Wrap(err, "kv: shard group wait inflight drained")
		}
		return nil
	}
	return nil
}

// EndCutoverBarrier closes the §7.1 step-6 barrier on this shard
// group's proposer chain. Idempotent against barrier-incapable
// proposers (no-op). Callers MUST pair each BeginCutoverBarrier
// with exactly one EndCutoverBarrier (the EnableRaftEnvelope
// handler uses defer).
func (g *ShardGroup) EndCutoverBarrier() {
	if cbp, ok := g.Proposer().(cutoverBarrierProposer); ok {
		cbp.EndCutoverBarrier()
	}
}

// NewLeaderProxyForShardGroup wires a LeaderProxy whose proposer
// consults g.raftPayloadWrap on every call, so SetRaftPayloadWrap
// becomes the hot-swap surface for the raft envelope cutover.
//
// Use this in preference to NewLeaderProxyWithEngine(g.Engine, ...)
// for any ShardGroup that participates in the encryption cutover
// pipeline — without the dynamic wrap, post-cutover writes would
// land cleartext at index > cutoverIndex and halt the apply loop on
// strict-> unwrap. The non-wrap-aware constructor remains as a
// convenience for shard groups that opt out of encryption (test
// fixtures, transient groups).
//
// Contract: g MUST be non-nil. The constructor takes the address
// of g.raftPayloadWrap so a nil receiver is an immediate nil deref
// — caller bug, not silently swallowed. Returning nil here would
// only defer the panic to the first sg.Txn.Commit call site (see
// main.go's buildShardGroups), with worse diagnostics; CLAUDE.md's
// "don't validate for scenarios that can't happen at internal
// boundaries" applies.
func NewLeaderProxyForShardGroup(g *ShardGroup, opts ...TransactionOption) *LeaderProxy {
	// Build a single dynamicWrappedProposer for this shard group and
	// cache it on g.proposer so direct shard proposals (HLC lease
	// renewal in RunHLCLeaseRenewal, future cipher rotations) and
	// the TransactionManager.Commit / Abort path share the same
	// wrap pointer and the same Propose / ProposeAdmin call shape.
	// A direct g.Engine.Propose call would bypass the wrap pointer
	// (codex P2 round-1); routing both paths through the same
	// proposer closes that hole.
	g.proposer = newDynamicWrappedProposer(g.Engine, &g.raftPayloadWrap)
	p := &LeaderProxy{
		engine: g.Engine,
		tm:     NewTransactionWithProposer(g.proposer, opts...),
		group:  g,
	}
	g.leaderRead = p.forwardLeaseRead
	return p
}

// leaseRefreshingTxn wraps a Transactional so every Commit / Abort that
// produced a real Raft commit extends its shard's lease. Mirrors
// Coordinate.Dispatch's lease hook for the per-shard case.
//
// Both TransactionManager.Commit and .Abort can return success WITHOUT
// going through Raft -- Commit short-circuits on empty input, Abort
// short-circuits when every request's abortRequestFor is nil (nothing
// to release). Refreshing the lease in those cases would be unsound:
// no quorum confirmation happened. We gate the refresh on
// resp.CommitIndex > 0, which the underlying manager sets to the
// last applied index only when at least one proposal went through.
type leaseRefreshingTxn struct {
	groupID uint64
	inner   Transactional
	g       *ShardGroup
	// coord back-references the owning coordinator so Commit can
	// consult the Stage 7a registration barrier. Every self-originated
	// write — client writes via router.Commit AND internal
	// lock-resolution via ShardStore's direct g.Txn.Commit — funnels
	// through this wrapper, so gating here (in addition to the
	// Dispatch-level gate for client groups) closes the lock-resolution
	// path codex P1 flagged. nil in tests that construct the wrapper
	// directly; awaitRegistrationBarrier is nil-receiver-safe.
	coord *ShardedCoordinator
}

func (t *leaseRefreshingTxn) Commit(ctx context.Context, reqs []*pb.Request) (*TransactionResponse, error) {
	start := monoclock.Now()
	expectedGen := t.g.lease.generation()
	resp, err := admittedOperation(ctx, t.operationAdmission(), t.groupID, AdmissionData, func(owned context.Context) (*TransactionResponse, error) {
		return t.commitAdmitted(owned, reqs)
	})
	if err == nil {
		t.maybeRefresh(resp, start, expectedGen)
	}
	return resp, err
}

func (t *leaseRefreshingTxn) operationAdmission() OperationAdmission {
	if t.coord == nil {
		return nil
	}
	return t.coord.operationAdmission
}

func (t *leaseRefreshingTxn) commitAdmitted(ctx context.Context, reqs []*pb.Request) (*TransactionResponse, error) {
	// Stage 7a §4.1: every Commit is a self-originated write, so gate it
	// on this node's writer registration. This is the universal
	// chokepoint (router.Commit and ShardStore lock-resolution both land
	// here), closing the lock-resolution path the Dispatch-level gate
	// alone misses (codex P1 on PR #839).
	if err := t.coord.awaitRegistrationBarrier(ctx); err != nil {
		return nil, err
	}
	if err := t.stampRawTimestampsForLocalCommit(ctx, reqs); err != nil {
		return nil, err
	}
	resp, leaderCommitTS, err := t.commitWithLocalStamp(ctx, reqs)
	if err != nil {
		// Only invalidate on errors that actually signal a leadership
		// change. Write-conflicts, validation errors, and deadline
		// exceeded on non-ReadIndex paths do NOT imply the leader is
		// gone; invalidating the lease for them forces every read
		// into the slow LinearizableRead path and defeats the whole
		// point of the lease. The engine's own leader-loss callback
		// already handles true leadership loss, plus
		// Coordinate.LeaseRead guards the fast path on
		// engine.State() == StateLeader.
		if isLeadershipLossError(err) {
			t.g.lease.invalidate()
		}
		return resp, errors.WithStack(err)
	}
	if leaderCommitTS != 0 && resp != nil {
		if resp.CommitTS != 0 && resp.CommitTS != leaderCommitTS {
			return nil, errors.WithStack(ErrInvalidRequest)
		}
		resp.CommitTS = leaderCommitTS
	}
	return resp, nil
}

func (t *leaseRefreshingTxn) commitWithLocalStamp(ctx context.Context, reqs []*pb.Request) (*TransactionResponse, uint64, error) {
	if proxy, ok := t.inner.(*LeaderProxy); ok {
		resp, err := proxy.commitWithLocalStamp(ctx, reqs, t.stampLeaderIssuedTxnForVerifiedLocalCommit)
		return resp, 0, err
	}
	commitTS, err := t.stampLeaderIssuedTxnForLocalCommit(ctx, reqs)
	if err != nil {
		return nil, 0, err
	}
	resp, err := t.inner.Commit(ctx, reqs)
	return resp, commitTS, errors.WithStack(err)
}

// A seal can observe a follower in dispatchTxn and then reach this wrapper
// after the shard becomes leader. Stamp its one-phase commit here so the local
// LeaderProxy path has the same leader-issued timestamp as a forwarded commit.
func (t *leaseRefreshingTxn) stampLeaderIssuedTxnForLocalCommit(ctx context.Context, reqs []*pb.Request) (uint64, error) {
	if t == nil || t.g == nil || t.g.Engine == nil ||
		ctx.Value(leaderIssuedCommitTSContextKey{}) != true ||
		!isLeaderEngine(t.g.Engine) || !canStampRawTimestampsOnEngine(ctx, t.g.Engine) {
		return 0, nil
	}
	return t.stampLeaderIssuedTxnForVerifiedLocalCommit(ctx, reqs)
}

func (t *leaseRefreshingTxn) stampLeaderIssuedTxnForVerifiedLocalCommit(ctx context.Context, reqs []*pb.Request) (uint64, error) {
	if t == nil || t.coord == nil || ctx.Value(leaderIssuedCommitTSContextKey{}) != true {
		return 0, nil
	}
	r, metaMutation := leaderIssuedOnePhaseRequest(reqs)
	if r == nil {
		return 0, nil
	}
	meta, err := DecodeTxnMeta(metaMutation.Value)
	if err != nil {
		return 0, errors.WithStack(err)
	}
	if meta.CommitTS != 0 {
		return 0, nil
	}
	commitTS, err := t.coord.resolveTxnCommitTS(ctx, r.Ts, 0)
	if err != nil {
		return 0, err
	}
	if err := t.coord.ensureMutationsWriteAllowedWithBypass(r.Mutations[1:], commitTS, r.GetWriteFenceBypassKeys()); err != nil {
		return 0, err
	}
	if err := StampMutationCommitTS(r.Mutations, commitTS); err != nil {
		return 0, err
	}
	meta.CommitTS = commitTS
	metaMutation.Value = EncodeTxnMeta(meta)
	return commitTS, nil
}

func leaderIssuedOnePhaseRequest(reqs []*pb.Request) (*pb.Request, *pb.Mutation) {
	if len(reqs) != 1 || reqs[0] == nil || !reqs[0].IsTxn ||
		reqs[0].Phase != pb.Phase_NONE || len(reqs[0].Mutations) == 0 {
		return nil, nil
	}
	metaMutation := reqs[0].Mutations[0]
	if metaMutation == nil || !bytes.Equal(metaMutation.Key, []byte(txnMetaPrefix)) {
		return nil, nil
	}
	return reqs[0], metaMutation
}

func (t *leaseRefreshingTxn) stampRawTimestampsForLocalCommit(ctx context.Context, reqs []*pb.Request) error {
	if t == nil || t.coord == nil || !hasUnstampedRawRequests(reqs) {
		return nil
	}
	if t.g != nil && t.g.Engine != nil {
		if !isLeaderEngine(t.g.Engine) {
			return nil
		}
		if !canStampRawTimestampsOnEngine(ctx, t.g.Engine) {
			return nil
		}
	}
	return t.coord.stampRawRequestTimestamps(ctx, reqs)
}

func canStampRawTimestampsOnEngine(ctx context.Context, engine raftengine.Engine) bool {
	return verifyLeaderEngineCtx(ctx, engine) == nil
}

func hasUnstampedRawRequests(reqs []*pb.Request) bool {
	for _, r := range reqs {
		if r != nil && !r.IsTxn && r.Ts == 0 {
			return true
		}
	}
	return false
}

func (t *leaseRefreshingTxn) Abort(ctx context.Context, reqs []*pb.Request) (*TransactionResponse, error) {
	start := monoclock.Now()
	expectedGen := t.g.lease.generation()
	resp, err := admittedOperation(ctx, t.operationAdmission(), t.groupID, AdmissionData, func(owned context.Context) (*TransactionResponse, error) {
		return t.inner.Abort(owned, reqs)
	})
	if err != nil {
		if isLeadershipLossError(err) {
			t.g.lease.invalidate()
		}
		return resp, errors.WithStack(err)
	}
	t.maybeRefresh(resp, start, expectedGen)
	return resp, nil
}

// maybeRefresh extends the per-shard lease only when the operation
// actually produced a Raft commit. expectedGen is sampled BEFORE the
// underlying Commit/Abort so an invalidation that fires during that
// call observes a generation mismatch inside extend and the refresh
// is rejected. See the struct doc comment for why.
func (t *leaseRefreshingTxn) maybeRefresh(resp *TransactionResponse, start monoclock.Instant, expectedGen uint64) {
	if resp == nil || resp.CommitIndex == 0 {
		return
	}
	if t.g.lp == nil {
		return
	}
	t.g.lease.extend(start.Add(t.g.lp.LeaseDuration()), expectedGen)
}

// Close forwards to the wrapped Transactional if it implements
// io.Closer. ShardStore.closeGroup relies on the type assertion
// `g.Txn.(io.Closer)` to release per-shard resources (e.g. the gRPC
// connection cached by LeaderProxy). Without this pass-through, the
// wrapping would silently swallow the Closer capability and leak
// connections / goroutines at shutdown.
func (t *leaseRefreshingTxn) Close() error {
	closer, ok := t.inner.(io.Closer)
	if !ok {
		return nil
	}
	if err := closer.Close(); err != nil {
		return errors.WithStack(err)
	}
	return nil
}

const (
	txnPhaseCount = 2

	txnSecondaryCommitRetryAttempts = 3
	txnSecondaryCommitRetryBackoff  = 20 * time.Millisecond

	// composed1RetryAttempts bounds how many times Dispatch re-issues a
	// txn after the FSM's M3 verifyComposed1 gate returned
	// ErrComposed1Violation / ErrComposed1VersionGCd.  Per design doc
	// §M4: "retries it once" — so the total attempt count is 1 (initial)
	// + composed1RetryAttempts = 2.  Beyond one retry the sentinel
	// surfaces unchanged so the client (or a wrapping retry harness in
	// the adapter) sees the failure rather than the coordinator spinning
	// on a persistent route shift.
	composed1RetryAttempts         = 1
	maxAppliedReadTimestampVouches = 4096
)

// ShardedCoordinator routes operations to shard-specific raft groups.
// It issues timestamps via a shared HLC and uses ShardRouter to dispatch.
type ShardedCoordinator struct {
	operationAdmission OperationAdmission
	engine             *distribution.Engine
	router             *ShardRouter
	groups             map[uint64]*ShardGroup
	defaultGroup       uint64
	clock              *HLC
	// tsAllocator is an optional TSO-backed timestamp source used for every
	// coordinator-owned persistence timestamp. Nil preserves the legacy shared
	// HLC path.
	tsAllocator TimestampAllocator
	// timestampFloor is the highest replicated backup cut observed by this
	// process. It deduplicates the same cut as each local shard applies its pin.
	timestampFloor atomic.Uint64
	// timestampGroup pins IsTimestampLeader to a dedicated Raft group when
	// timestampGroupConfigured is true. Nil/false preserves the M3 bridge
	// behavior where any locally-led shard group can issue TSO timestamps.
	timestampGroup           uint64
	timestampGroupConfigured bool
	// timestampGroupCandidate is the group WithTimestampGroup would pin once
	// the dedicated allocator takes over. It is recorded at startup even while
	// the deployment is still in legacy warm-up so that a Phase-D marker
	// applied later -- through the durable, consensus-owned cutover state
	// rather than a process-local mode flag -- can pin it without a racy
	// runtime mutation. See effectiveTimestampGroup.
	timestampGroupCandidate    uint64
	timestampGroupCandidateSet bool
	// tsoCutoverState is consensus-owned group-0 migration state. Phase D uses
	// it to retire data-shard HLC renewal and reject legacy cross-shard startTS.
	tsoCutoverState interface {
		CutoverActive() bool
		PhaseDActive() bool
	}
	appliedReadVoucherMu sync.Mutex
	appliedReadVouchers  map[appliedReadVoucherKey]uint64
	// allShardGroupIDs, when configured, is the explicit set of data groups
	// that whole-keyspace operations must visit. It lets callers keep
	// non-data groups (for example a reserved timestamp group) in c.groups
	// without letting Scan fences or DEL_PREFIX broadcasts touch them.
	allShardGroupIDs         []uint64
	allShardGroupsConfigured bool
	store                    store.MVCCStore
	log                      *slog.Logger
	// deregisterLeaseCbs removes the per-shard leader-loss callbacks
	// registered at construction. See Coordinate.Close for the
	// rationale.
	deregisterLeaseCbs []func()
	// leaseObserver records lease-read hit/miss for every shard the
	// coordinator owns. Nil-safe; see Coordinate.leaseObserver.
	leaseObserver LeaseReadObserver
	// sampler counts requests per RouteID for the key visualizer
	// heatmap. Nil-safe at the call site; the implementation
	// (keyviz.MemSampler) also tolerates a typed-nil receiver, so a
	// disabled keyviz wires through to a no-op without branching on
	// the hot path.
	sampler keyviz.Sampler
	// keyvizLabelsEnabled controls whether adapter-supplied labels are
	// allowed to reach the sampler. When false, observations keep the
	// legacy unlabeled route-only shape.
	keyvizLabelsEnabled bool
	// hlcRenewalBlocked lets startup code temporarily suppress background HLC
	// lease proposals while another startup-only Raft mutation must run first.
	hlcRenewalBlocked func() bool
	// commitTSFenceActivation makes the coordinator propose the raw and
	// PREPARE apply-order fence activation on groups it leads
	// (WithCommitTSFenceActivation).
	commitTSFenceActivation         bool
	commitTSFenceActivationReady    func() bool
	commitTSFenceActivationInFlight atomic.Bool
	commitTSFenceActiveGroups       sync.Map
	hlcRecoveryMu                   sync.Mutex
	// hlcRenewalInFlight prevents a slow or quorum-stalled group from stacking
	// another background HLC lease proposal for the same group on the next tick.
	hlcRenewalMu       sync.Mutex
	hlcRenewalInFlight map[uint64]struct{}
	// inflightTxns holds the (primaryKey, startTS) identities of cross-shard
	// transactions between their first PREPARE and their return. See
	// acquireTxnIdentity.
	inflightTxnMu sync.Mutex
	inflightTxns  map[txnIdentity]struct{}
	// Retained identities cannot be safely released without a terminal proof.
	// The counter makes their process-lifetime accumulation observable.
	retainedTxnCount atomic.Uint64
	// registrationGate is the Stage 7a §4.1 first-write barrier: when
	// set, self-originated mutating writes that would land as §4.1
	// storage envelopes block until this node's writer registration
	// commits. nil when encryption is off / no registration is pending
	// (the common case — ungated). See RegistrationGate.
	registrationGate *RegistrationGate
}

type appliedReadVoucherKey struct {
	timestamp uint64
	ref       AppliedReadTimestampVoucherRef
}

// RegistrationGate carries the Stage 7a §4.1 registration-before-
// first-write barrier into the coordinator. main.go owns the
// encryption StateCache and the registration goroutine and supplies
// this; kv stays decoupled from internal/encryption by taking a plain
// channel + predicate closures rather than the StateCache type.
//
// Barrier three-state (per the 7a design §3.2):
//   - nil           → no registration pending (Phase 0 / skip / off) → ungated
//   - open (non-nil, not closed) → registration in flight → mutating
//     encrypted writes block on it
//   - closed        → registration committed → ungated (fast path)
type RegistrationGate struct {
	// Barrier is the open-or-closed channel described above. A nil
	// Barrier (the zero value, or an explicitly nil field) means
	// "never armed" → ungated; awaitRegistration checks for nil first
	// so a nil channel is never received on (which would block forever).
	Barrier <-chan struct{}
	// StorageEnvelopeActive and ActiveStorageKeyID read the process-wide
	// encryption StateCache. A write is gated only when the §7.1 cutover
	// has fired AND a storage DEK is active — i.e. the write would land
	// encrypted and thus emit a nonce under this node's identity.
	StorageEnvelopeActive func() bool
	ActiveStorageKeyID    func() (uint32, bool)
}

// WithRegistrationGate wires the Stage 7a first-write barrier onto the
// coordinator. Applied after construction for the same reason as the
// other With* options. A nil gate (or a gate with a nil Barrier)
// leaves every write ungated — the encryption-off / no-pending-
// registration posture.
func (c *ShardedCoordinator) WithRegistrationGate(g *RegistrationGate) *ShardedCoordinator {
	c.registrationGate = g
	return c
}

// WithTSOAllocator routes sharded-coordinator timestamp issuance through a
// TSO-compatible allocator. Existing deployments keep the legacy shared-HLC
// path unless this is wired explicitly.
func (c *ShardedCoordinator) WithTSOAllocator(alloc TimestampAllocator) *ShardedCoordinator {
	c.tsAllocator = alloc
	return c
}

// TimestampAllocator exposes the configured allocator to coordinator
// decorators without widening the Coordinator interface.
func (c *ShardedCoordinator) TimestampAllocator() TimestampAllocator {
	if c == nil {
		return nil
	}
	return c.tsAllocator
}

// VouchAppliedReadTimestamp records one use of an audited adapter watermark.
// The bounded map prevents abandoned requests from growing process memory.
func (c *ShardedCoordinator) VouchAppliedReadTimestamp(timestamp uint64, ref AppliedReadTimestampVoucherRef) error {
	if c == nil || timestamp == 0 || timestamp == ^uint64(0) || ref.id == 0 {
		return errors.WithStack(ErrTSOTimestampInvalid)
	}
	key := appliedReadVoucherKey{timestamp: timestamp, ref: ref}
	c.appliedReadVoucherMu.Lock()
	defer c.appliedReadVoucherMu.Unlock()
	if c.appliedReadVouchers == nil {
		c.appliedReadVouchers = make(map[appliedReadVoucherKey]uint64)
	}
	if uses, ok := c.appliedReadVouchers[key]; ok {
		c.appliedReadVouchers[key] = uses + 1
		return nil
	}
	if len(c.appliedReadVouchers) >= maxAppliedReadTimestampVouches {
		return errors.WithStack(ErrTSOReadVoucherLimit)
	}
	c.appliedReadVouchers[key] = 1
	return nil
}

// RevokeAppliedReadTimestamp removes one prepared voucher that did not reach
// ShardedCoordinator dispatch validation, for example because an outer
// coordinator decorator rejected the dispatch first.
func (c *ShardedCoordinator) RevokeAppliedReadTimestamp(timestamp uint64, ref AppliedReadTimestampVoucherRef) {
	if c == nil || timestamp == 0 || timestamp == ^uint64(0) || ref.id == 0 {
		return
	}
	key := appliedReadVoucherKey{timestamp: timestamp, ref: ref}
	c.appliedReadVoucherMu.Lock()
	defer c.appliedReadVoucherMu.Unlock()
	uses, ok := c.appliedReadVouchers[key]
	if !ok {
		return
	}
	if uses <= 1 {
		delete(c.appliedReadVouchers, key)
		return
	}
	c.appliedReadVouchers[key] = uses - 1
}

func (c *ShardedCoordinator) SupportsAppliedReadTimestampVoucher() bool { return true }

func (c *ShardedCoordinator) consumeAppliedReadTimestampVoucher(ctx context.Context, timestamp uint64) bool {
	if c == nil {
		return false
	}
	ref, ok := appliedReadTimestampVoucherRefFromContext(ctx, timestamp)
	if !ok {
		return false
	}
	key := appliedReadVoucherKey{timestamp: timestamp, ref: ref}
	c.appliedReadVoucherMu.Lock()
	defer c.appliedReadVoucherMu.Unlock()
	uses, ok := c.appliedReadVouchers[key]
	if !ok {
		return false
	}
	if uses <= 1 {
		delete(c.appliedReadVouchers, key)
	} else {
		c.appliedReadVouchers[key] = uses - 1
	}
	return true
}

// ObserveTimestampFloor advances the process clock past a replicated backup
// cut and invalidates any cached TSO batch that could still contain values at
// or below it. Claims returned before invalidation remain protected by the
// FSM's durable backup timestamp floor.
func (c *ShardedCoordinator) ObserveTimestampFloor(ts uint64) {
	if c == nil || ts == 0 {
		return
	}
	for {
		floor := c.timestampFloor.Load()
		if ts <= floor {
			return
		}
		if c.timestampFloor.CompareAndSwap(floor, ts) {
			break
		}
	}
	if c.clock != nil {
		c.clock.Observe(ts)
	}
	invalidateTimestampWindow(c.tsAllocator)
}

// WithTimestampGroup pins timestamp issuance leadership to one Raft group.
// Callers should only enable this once a data-shard leader can redirect
// timestamp allocation to that group; otherwise data leaders would stop being
// able to commit writes when they do not also lead the timestamp group.
func (c *ShardedCoordinator) WithTimestampGroup(groupID uint64) *ShardedCoordinator {
	c.timestampGroup = groupID
	c.timestampGroupConfigured = true
	c.timestampGroupCandidate = groupID
	c.timestampGroupCandidateSet = true
	return c
}

// WithTimestampGroupCandidate records the group that owns timestamp issuance
// once the dedicated allocator takes over, without pinning it yet.
//
// A deployment can start in legacy warm-up and advance to Phase D later, either
// by reloading --tsoModeFile or by another node proposing the marker. The
// warm-up contract forbids pinning up front: while persistence timestamps still
// come from the data groups' local HLC path, narrowing lease renewal to the
// timestamp group would let a group-0 quorum loss expire healthy data groups'
// ceilings. But leaving the group unknown is worse once Phase D activates --
// shouldRenewHLCGroup then retires every data group and finds no timestamp
// group to renew instead, so every ceiling expires and issuance fails with
// ErrCeilingExpired. Recording the candidate here lets effectiveTimestampGroup
// pin it exactly when PhaseDActive flips, with no runtime mutation of the
// coordinator.
func (c *ShardedCoordinator) WithTimestampGroupCandidate(groupID uint64) *ShardedCoordinator {
	c.timestampGroupCandidate = groupID
	c.timestampGroupCandidateSet = true
	return c
}

// effectiveTimestampGroup reports the group that currently owns HLC lease
// renewal, leadership, and recovery, and whether one is pinned at all.
func (c *ShardedCoordinator) effectiveTimestampGroup() (uint64, bool) {
	if c == nil {
		return 0, false
	}
	if c.timestampGroupConfigured {
		return c.timestampGroup, true
	}
	if c.timestampGroupCandidateSet && c.tsoCutoverState != nil && c.tsoCutoverState.PhaseDActive() {
		return c.timestampGroupCandidate, true
	}
	return 0, false
}

// WithTSOCutoverState wires the durable group-0 migration state. The state is
// read dynamically so a marker applied after startup changes renewal and
// validation behavior without a process-local mode race.
func (c *ShardedCoordinator) WithTSOCutoverState(state interface {
	CutoverActive() bool
	PhaseDActive() bool
}) *ShardedCoordinator {
	c.tsoCutoverState = state
	return c
}

// WithAllShardGroups restricts whole-keyspace operations to the supplied data
// groups. When unset, the coordinator preserves the legacy behaviour and uses
// every group it owns.
func (c *ShardedCoordinator) WithAllShardGroups(groupIDs ...uint64) *ShardedCoordinator {
	c.allShardGroupIDs = slices.Clone(groupIDs)
	slices.Sort(c.allShardGroupIDs)
	c.allShardGroupIDs = slices.Compact(c.allShardGroupIDs)
	c.allShardGroupsConfigured = true
	return c
}

// awaitRegistration implements the §4.1 first-write barrier (7a §3.2).
// It returns nil (ungated) unless a registration is genuinely pending
// AND this request is a mutating write that would land encrypted, in
// which case it blocks until the registration commits or ctx ends.
// Fail-closed: a write that cannot register within its ctx returns the
// ctx error rather than proceeding to emit an unregistered nonce.
func (c *ShardedCoordinator) awaitRegistration(ctx context.Context, reqs *OperationGroup[OP]) error {
	g := c.registrationGate
	if g == nil || g.Barrier == nil {
		return nil
	}
	select {
	case <-g.Barrier:
		return nil // registration committed — fast path
	default:
	}
	// Registration is in flight. Gate only mutating writes that would
	// land encrypted; reads never reach Dispatch, and cleartext writes
	// (pre-cutover / no active DEK) emit no nonce.
	if !c.writeWouldEncrypt(reqs) {
		return nil
	}
	select {
	case <-g.Barrier:
		return nil
	case <-ctx.Done():
		return errors.Wrap(ctx.Err(), "encryption: write blocked on pending §4.1 writer registration")
	}
}

// writeWouldEncrypt reports whether reqs is a mutating write that would
// land as a §4.1 storage envelope under the current gate state — i.e.
// the cutover has fired AND a storage DEK is active. Only such writes
// are gated by awaitRegistration; reads and cleartext writes are not.
func (c *ShardedCoordinator) writeWouldEncrypt(reqs *OperationGroup[OP]) bool {
	if c.registrationGate == nil {
		return false
	}
	return hasMutatingElems(reqs) && c.encryptionWriteActive()
}

// awaitRegistrationBarrier is the write-layer (Transactional.Commit)
// half of the §4.1 first-write gate. Unlike awaitRegistration it takes
// no OperationGroup: every Commit is a write, so the gate fires
// whenever a registration is pending AND the write would land
// encrypted (cutover fired + active DEK). nil-receiver-safe (tests
// construct leaseRefreshingTxn without a coordinator).
func (c *ShardedCoordinator) awaitRegistrationBarrier(ctx context.Context) error {
	if c == nil {
		return nil
	}
	g := c.registrationGate
	if g == nil || g.Barrier == nil {
		return nil
	}
	select {
	case <-g.Barrier:
		return nil // committed — fast path
	default:
	}
	if !c.encryptionWriteActive() {
		return nil
	}
	select {
	case <-g.Barrier:
		return nil
	case <-ctx.Done():
		return errors.Wrap(ctx.Err(), "encryption: commit blocked on pending §4.1 writer registration")
	}
}

// encryptionWriteActive reports whether a write would currently land as
// a §4.1 storage envelope: the cutover has fired AND a storage DEK is
// active. Shared by writeWouldEncrypt (Dispatch gate) and
// awaitRegistrationBarrier (Commit gate). Assumes c.registrationGate
// is non-nil (both callers check that first).
func (c *ShardedCoordinator) encryptionWriteActive() bool {
	g := c.registrationGate
	if g.StorageEnvelopeActive == nil || !g.StorageEnvelopeActive() {
		return false
	}
	if g.ActiveStorageKeyID == nil {
		return false
	}
	_, ok := g.ActiveStorageKeyID()
	return ok
}

// hasMutatingElems reports whether the group carries at least one
// mutating operation. Every OP in OperationGroup (Put / Del /
// DelPrefix) mutates — reads use separate Coordinator methods that
// never reach Dispatch — so a read-only transaction reaches here with
// only ReadKeys set and an empty Elems slice, and must stay ungated.
func hasMutatingElems(reqs *OperationGroup[OP]) bool {
	if reqs == nil {
		return false
	}
	// The per-Elem nil check is defensive: validateOperationGroup runs
	// before this and rejects groups with nil elements, so a non-empty
	// Elems is effectively all-non-nil in practice. The guard keeps
	// hasMutatingElems correct even if a future caller bypasses that
	// validation.
	for _, e := range reqs.Elems {
		if e != nil {
			return true
		}
	}
	return false
}

// WithLeaseReadObserver wires a LeaseReadObserver onto a
// ShardedCoordinator. Applied after construction because the
// NewShardedCoordinator signature is already heavily overloaded;
// see Coordinate.WithLeaseReadObserver for the equivalent option on
// the single-group coordinator, including the typed-nil guard
// rationale.
func (c *ShardedCoordinator) WithLeaseReadObserver(observer LeaseReadObserver) *ShardedCoordinator {
	c.leaseObserver = normalizeLeaseObserver(observer)
	return c
}

// SetHLCLeaseRenewalBlocker installs a predicate that suppresses background
// HLC lease-renewal proposals while it returns true.
func (c *ShardedCoordinator) SetHLCLeaseRenewalBlocker(blocked func() bool) {
	if c == nil {
		return
	}
	c.hlcRenewalBlocked = blocked
}

// WithSampler wires a keyviz.Sampler onto a ShardedCoordinator. The
// coordinator calls sampler.Observe at dispatch entry — once per
// resolved (RouteID, mutation key) pair — to feed the key visualizer
// heatmap (design doc §5.1). Applied after construction for the same
// reason as WithLeaseReadObserver: NewShardedCoordinator is already
// heavily overloaded.
//
// Passing a nil interface value is supported and disables sampling
// (the call site guards against it). Passing a typed-nil
// *keyviz.MemSampler also works because Observe is nil-safe by
// contract.
func (c *ShardedCoordinator) WithSampler(s keyviz.Sampler) *ShardedCoordinator {
	c.sampler = s
	return c
}

func (c *ShardedCoordinator) WithKeyVizLabelsEnabled(enabled bool) *ShardedCoordinator {
	c.keyvizLabelsEnabled = enabled
	return c
}

// WithPartitionResolver wires a PartitionResolver onto the
// coordinator's underlying ShardRouter. The resolver runs before
// the byte-range engine on every dispatch, so partition-keyspace
// schemes (e.g. SQS HT-FIFO) can override the default shard layout
// without breaking the engine's non-overlapping-cover invariant.
//
// Applied after construction for the same reason as the other
// With* options on this type — NewShardedCoordinator is already
// heavily overloaded. Passing a nil resolver clears any previously-
// installed resolver.
func (c *ShardedCoordinator) WithPartitionResolver(r PartitionResolver) *ShardedCoordinator {
	c.router.WithPartitionResolver(r)
	return c
}

// NewShardedCoordinator builds a coordinator for the provided shard groups.
// The defaultGroup is used for non-keyed leader checks.
func NewShardedCoordinator(engine *distribution.Engine, groups map[uint64]*ShardGroup, defaultGroup uint64, clock *HLC, st store.MVCCStore) *ShardedCoordinator {
	router := NewShardRouter(engine)
	ownedGroups := map[uint64]*ShardGroup(nil)
	if groups != nil {
		ownedGroups = make(map[uint64]*ShardGroup, len(groups))
		for gid, group := range groups {
			ownedGroups[gid] = group
		}
	}
	// Construct the coordinator before wrapping the per-shard
	// Transactionals so each leaseRefreshingTxn can back-reference it
	// for the §4.1 registration barrier (the gate is installed later
	// via WithRegistrationGate and read at Commit time).
	c := &ShardedCoordinator{
		engine:       engine,
		router:       router,
		groups:       ownedGroups,
		defaultGroup: defaultGroup,
		clock:        clock,
		store:        st,
		log:          slog.Default(),
	}
	var deregisters []func()
	for gid, g := range ownedGroups {
		// Wrap Txn so every successful Commit/Abort refreshes the
		// per-shard lease. Leave nil transactions unchanged, and skip
		// if already wrapped so repeat calls don't stack wrappers.
		if g.Txn != nil {
			if existing, already := g.Txn.(*leaseRefreshingTxn); already {
				// Re-binding over the same ShardGroup (this function
				// supports repeat construction by not stacking
				// wrappers): point the existing wrapper at the NEW
				// coordinator so Commit consults the freshly-installed
				// registration gate, not a stale one.
				existing.coord = c
				existing.groupID = gid
			} else {
				g.Txn = &leaseRefreshingTxn{inner: g.Txn, g: g, coord: c, groupID: gid}
			}
		}
		c.configureTimestampAdmissionForGroup(g)
		if gid != 0 {
			configureMigrationRequestAdmission(g.Txn, g.Store, gid)
		}
		router.Register(gid, g.Txn, g.Store)
		// Resolve the optional LeaseProvider capability once so
		// groupLeaseRead / maybeRefresh test g.lp for nil instead of
		// re-asserting the interface per call.
		// Per-shard leader-loss hook: when this group's engine notices
		// a state transition out of leader, drop the lease so the next
		// LeaseReadForKey on that shard takes the slow path.
		if lp, ok := g.Engine.(raftengine.LeaseProvider); ok {
			g.lp = lp
			group := g
			deregisters = append(deregisters, lp.RegisterLeaderLossCallback(func() {
				group.lease.invalidate()
				c.invalidateTimestampWindow()
			}))
		}
	}
	c.deregisterLeaseCbs = deregisters
	return c
}

// Close releases per-shard engine-side registrations. Idempotent.
func (c *ShardedCoordinator) Close() error {
	if c == nil {
		return nil
	}
	cbs := c.deregisterLeaseCbs
	c.deregisterLeaseCbs = nil
	for _, fn := range cbs {
		fn()
	}
	return nil
}

func (c *ShardedCoordinator) Dispatch(ctx context.Context, reqs *OperationGroup[OP]) (*CoordinateResponse, error) {
	group := c.defaultGroup
	if c.operationAdmission != nil {
		group = c.dispatchAdmissionGroup(reqs)
	}
	return admittedOperation(ctx, c.operationAdmission, group, AdmissionData, func(owned context.Context) (*CoordinateResponse, error) {
		return c.dispatchAdmitted(owned, reqs)
	})
}

func (c *ShardedCoordinator) dispatchAdmissionGroup(reqs *OperationGroup[OP]) uint64 {
	if reqs == nil || len(reqs.Elems) == 0 || reqs.Elems[0] == nil || reqs.Elems[0].Op == DelPrefix {
		return c.defaultGroup
	}
	if reqs.Elems[0].GroupID != 0 {
		return reqs.Elems[0].GroupID
	}
	if c.router != nil {
		if gid, ok := c.router.ResolveGroup(reqs.Elems[0].Key); ok {
			return gid
		}
	}
	return c.defaultGroup
}

func (c *ShardedCoordinator) dispatchAdmitted(ctx context.Context, reqs *OperationGroup[OP]) (*CoordinateResponse, error) {
	if ctx == nil {
		ctx = context.Background()
	}

	if err := validateOperationGroup(reqs); err != nil {
		return nil, err
	}

	// Stage 7a §4.1: block self-originated mutating encrypted writes
	// until this node's writer registration commits. Ungated fast path
	// (no gate / committed / cleartext) returns immediately.
	if err := c.awaitRegistration(ctx, reqs); err != nil {
		return nil, err
	}

	// Capture whether the caller supplied a non-zero StartTS BEFORE
	// the coordinator-allocates-on-zero branch below mutates the
	// field.  A caller-supplied StartTS names a specific snapshot
	// the caller already read against (e.g. adapter/s3.go:573
	// reads bucket metadata at readTS and dispatches with
	// StartTS=readTS; adapter/sqs_messages.go and adapter/dynamodb.go
	// follow the same readTS-then-mutate pattern across dozens of
	// sites).  The pre-Dispatch read is invisible to the
	// coordinator — it is NOT surfaced as a ReadKeys entry — so
	// the only signal that the snapshot is owned by the caller is
	// reqs.StartTS being non-zero on entry.  The M4 retry path
	// uses this to gate the StartTS bump: bumping a caller-owned
	// timestamp would let any commit landed in (originalStartTS,
	// newStartTS) bypass the FSM's latest>startTS write-conflict
	// check (codex P1 on 57da8886, PR #900).
	callerSuppliedStartTS := reqs.IsTxn && reqs.StartTS != 0

	if reqs.IsTxn && reqs.StartTS == 0 {
		startTS, err := c.nextStartTS(ctx, reqs.Elems)
		if err != nil {
			return nil, err
		}
		reqs.StartTS = startTS
		// When the coordinator assigns StartTS, also clear any caller-provided
		// CommitTS so dispatchTxn generates both timestamps consistently.
		// A caller-supplied CommitTS without a matching StartTS could produce
		// CommitTS <= StartTS (an invalid transaction).
		reqs.CommitTS = 0
	}

	if reqs.IsTxn {
		if resp, handled, err := c.dispatchBeforeShardRouting(ctx, reqs); handled {
			return resp, err
		}
		return c.dispatchTxnWithComposed1Retry(ctx, reqs, callerSuppliedStartTS)
	}

	return c.dispatchRawWithComposed1Retry(ctx, reqs)
}

func (c *ShardedCoordinator) dispatchBeforeShardRouting(ctx context.Context, reqs *OperationGroup[OP]) (*CoordinateResponse, bool, error) {
	// DEL_PREFIX cannot be routed to a single shard because the prefix may
	// span multiple shards (or be nil, meaning "all keys"). Broadcast the
	// operation to every shard group so each FSM scans locally.
	if hasDelPrefixElem(reqs.Elems) {
		resp, err := c.dispatchDelPrefixBroadcast(ctx, reqs.IsTxn, reqs.Elems, reqs.ObservedRouteVersion)
		return resp, true, err
	}
	if err := c.rejectWriteFencedPointElems(reqs.Elems); err != nil {
		return nil, true, err
	}
	return nil, false, nil
}

// dispatchTxnWithComposed1Retry runs the M4 Composed-1 retry loop
// (design doc
// docs/design/2026_05_29_implemented_composed1_cross_group_commit_guard.md
// §M4).  Pins reqs.ObservedRouteVersion to the engine's current
// catalog version on the FIRST attempt when the caller left it at the
// zero sentinel — every txn that flows through ShardedCoordinator
// gets gate-eligible by default so the M3 verifyComposed1 check has
// teeth without each adapter rediscovering the contract.  On
// ErrComposed1Violation or ErrComposed1VersionGCd, re-reads the
// catalog version, re-stamps observed+commit on the OperationGroup,
// and re-issues dispatchTxn ONCE.  Beyond one retry the sentinel
// surfaces unchanged.
//
// The retry is bounded at composed1RetryAttempts = 1 because both
// sentinels are "route shifted, retry on the fresh catalog" signals
// — a persistent failure across two attempts means the catalog is
// churning faster than this dispatch can keep up, and surfacing the
// error lets a wrapping adapter retry harness (or the client) decide
// whether to keep trying.
// maybeAutoPinObservedRouteVersion stamps reqs.ObservedRouteVersion
// with the engine's current catalog version at Dispatch entry, but
// ONLY when (a) the txn has no read keys AND (b) the caller did not
// supply StartTS AND (c) no element's key is claimed by a partition
// resolver.  Per design doc §4.1 the version must be pinned at
// BeginTxn (read-set capture time); the auto-pin is a best-effort
// backfill for callers that have not yet migrated to pin
// themselves.  Three cases skip the auto-pin:
//
//   - len(ReadKeys) != 0 — the caller already performed reads at
//     some earlier moment (Redis MULTI/EXEC's txnContext.commit
//     builds an OperationGroup with StartTS from MULTI and
//     ReadKeys from the GETs inside the txn body).  Stamping the
//     catalog version at this Dispatch call would associate
//     post-shift routes with pre-shift reads (codex P1 on
//     10123c5a, PR #900).
//
//   - callerSuppliedStartTS — the caller supplied StartTS,
//     meaning a read at the adapter layer happened against that
//     snapshot before Dispatch even though it is not surfaced as
//     a ReadKeys entry.  The 13+ S3/SQS/DynamoDB adapter sites
//     identified in the M4-StartTS-gate audit (adapter/s3.go:573
//     etc.) fall in this bucket.  Stamping the catalog version
//     at Dispatch time would mask any route shift between the
//     adapter-layer read and Dispatch entry — verifyComposed1
//     would find no mismatch at apply time and the shift becomes
//     INVISIBLE.  That is strictly worse than ObservedRouteVersion=0
//     (gate short-circuits, no false claim made): the spurious
//     auto-pin gives false confidence (codex P1 on 144ec0ca,
//     PR #900).
//
//   - any element's key is resolver-claimed — when a
//     PartitionResolver is wired (SQS HT-FIFO partition keys
//     etc.), ShardRouter routes via the resolver but
//     verifyComposed1 calls route-history OwnerOf on the raw
//     mutation key against the BYTE-RANGE engine snapshot.  The
//     engine has no knowledge of the resolver's mapping, so the
//     gate spuriously rejects resolver-routed commits even when
//     the resolver picked the correct gid.  Skip the auto-pin
//     for any resolver-recognised key; the request flows with
//     ObservedRouteVersion=0 and the M3 gate short-circuits —
//     restoring the pre-auto-pin behaviour for resolver-routed
//     txns.  Resolver-aware M3 is M5+ work (codex P1 on
//     6a458a28, PR #900).
//
// The non-auto-pin case (request flows with ObservedRouteVersion=0,
// M3 gate short-circuits) is the safe non-regressing posture for
// non-migrated callers — the gate cannot retroactively pin reads
// it was not present for.  Adapters that want M3 protection must
// migrate to pin at BeginTxn per §4.1.
//
// Extracted from dispatchTxnWithComposed1Retry to keep its
// cyclomatic complexity in the cyclop budget.
func (c *ShardedCoordinator) maybeAutoPinObservedRouteVersion(reqs *OperationGroup[OP], callerSuppliedStartTS bool) {
	if c.engine == nil || reqs.ObservedRouteVersion != 0 || len(reqs.ReadKeys) != 0 || callerSuppliedStartTS {
		return
	}
	if c.anyResolverClaimedKey(reqs.Elems) {
		return
	}
	reqs.ObservedRouteVersion = EncodeObservedRouteVersion(c.engine.Version())
}

// anyResolverClaimedKey reports whether any element's key is
// claimed by the partition resolver.  Returns false when the
// router has no resolver installed (the most common case) so the
// auto-pin path stays inexpensive in the byte-range-only deployment.
// Extracted from maybeAutoPinObservedRouteVersion to keep the
// auto-pin's cyclomatic complexity in the cyclop budget.
func (c *ShardedCoordinator) anyResolverClaimedKey(elems []*Elem[OP]) bool {
	if c.router == nil || c.router.partitionResolver == nil {
		return false
	}
	for _, e := range elems {
		if e == nil || len(e.Key) == 0 {
			continue
		}
		if c.router.partitionResolver.RecognisesPartitionedKey(e.Key) {
			return true
		}
	}
	return false
}

func (c *ShardedCoordinator) dispatchTxnWithComposed1Retry(ctx context.Context, reqs *OperationGroup[OP], callerSuppliedStartTS bool) (*CoordinateResponse, error) {
	c.pinStrictRouteVersion(reqs)
	c.maybeAutoPinObservedRouteVersion(reqs, callerSuppliedStartTS)

	for attempt := 0; attempt <= composed1RetryAttempts; attempt++ {
		resp, err := c.dispatchTxn(
			ctx,
			reqs.StartTS,
			reqs.CommitTS,
			reqs.PrevCommitTS,
			reqs.Elems,
			reqs.ReadKeys,
			reqs.ObservedRouteVersion,
			reqs.KeyVizLabel,
			callerSuppliedStartTS,
			reqs.RequireAllParticipants,
			reqs.PrimaryKey,
		)
		if err == nil {
			return resp, nil
		}
		if errors.Is(err, ErrTransactionOutcomeUnknown) || !isComposed1RetryableError(err) {
			return resp, err
		}
		// Read-write txns (ReadKeys non-empty) MUST surface the
		// sentinel without retry.  The client already performed
		// the reads at the original StartTS; transparently bumping
		// StartTS on retry would let any concurrent write that
		// committed between the old and new timestamps go
		// undetected by the FSM's OCC check (which only rejects
		// versions with `latest > startTS`), letting the retry
		// commit decisions based on stale reads — a strict-
		// serialisability violation (gemini CRITICAL / codex P1
		// on PR #900).
		//
		// The caller / adapter is responsible for re-executing the
		// entire txn (including re-reading the keys at a fresh
		// timestamp) when this sentinel surfaces.  Write-only
		// txns (no reads to invalidate) remain safe to retry.
		if len(reqs.ReadKeys) > 0 {
			return resp, err
		}
		// Caller-supplied StartTS (ReadKeys-empty case) MUST also
		// surface — the caller's pre-Dispatch read at this snapshot
		// is invisible to the coordinator, so we cannot prove the
		// retry's bumped StartTS would still preserve OCC against
		// commits landed in (originalStartTS, newStartTS).  This
		// catches dozens of adapter sites that supply
		// StartTS=readTS without populating ReadKeys: S3
		// createBucket / admin object writes, SQS messages /
		// FIFO / purge / tags, DynamoDB metadata writes, etc.
		// Only coordinator-allocated StartTS (caller passed 0
		// at Dispatch entry, the coordinator allocated it from
		// nextStartTS, and no read has happened at it) is safe
		// to bump on retry (codex P1 on 57da8886, PR #900).
		if callerSuppliedStartTS {
			return resp, err
		}
		if attempt == composed1RetryAttempts {
			return resp, err
		}
		// Re-route by re-reading the engine's current catalog
		// version and stamping it on the txn.  groupMutations on
		// the next dispatchTxn pass re-runs router.ResolveGroup,
		// so a key whose owning group changed since the last
		// attempt naturally lands on the new group's FSM.
		if c.engine != nil {
			reqs.ObservedRouteVersion = EncodeObservedRouteVersion(c.engine.Version())
		}
		// Clear the timestamps so the next attempt allocates a
		// fresh pair against the post-shift HLC.  The OCC
		// invariants require commitTS > startTS computed under the
		// same HLC observation; reusing the stale pair would risk
		// a startTS that no longer dominates the new shard's
		// applied commitTS.
		//
		// Allocate StartTS unconditionally — nextStartTS already
		// handles the nil-clock case (falls back to
		// maxTS+1 internally).  Gating on c.clock!=nil would leave
		// reqs.StartTS at 0 in the nil-clock test fixture, and
		// dispatchTxn does NOT re-allocate when StartTS is zero,
		// so the retry would run with StartTS=0 — violating MVCC
		// invariants (gemini HIGH on PR #900).
		reqs.CommitTS = 0
		// IMPORTANT — do NOT clear reqs.PrevCommitTS here.  An earlier
		// round of this PR did (taking claude[bot]'s reasoning at face
		// value: "M3 fired at apply time, so the original attempt never
		// committed → probe is stale").  That reasoning conflates two
		// different "original attempts" and is wrong (codex P1 on
		// 43c55dfe, PR #900):
		//
		//   * Within M4: attempt 1's M3 rejection does prove attempt 1
		//     did not write anything (the FSM rejects before any state
		//     change).
		//   * Across adapter retries: PrevCommitTS names the
		//     ADAPTER'S prior attempt (e.g. adapter/redis.go:3209,
		//     :3615 send PrevCommitTS = pending.commitTS as the
		//     option-2 ambiguous-outcome probe).  That earlier
		//     attempt may have actually landed at the named commitTS
		//     before the route shift that triggered our M3 sentinel.
		//
		// Dropping the probe in the retry would let the FSM re-apply
		// the writes against the post-shift route, double-writing the
		// caller's at-most-once-payload if the named prior attempt did
		// land.  Preserving it has the cost that
		// dispatchMultiShardTxn:749 surfaces
		// ErrTxnDedupRequiresSingleShard when the post-shift route now
		// spans multiple groups — which IS the faithful signal: the
		// adapter's at-most-once retry contract cannot be transparently
		// honoured across a shard split, and the caller must reckon
		// with the ambiguity at a higher level (re-read, re-execute,
		// abort).  Surfacing that error is strictly safer than silently
		// losing dedup.
		startTS, allocErr := c.nextStartTS(ctx, reqs.Elems)
		if allocErr != nil {
			// resp here is the failed first attempt's response (always
			// nil for the Composed-1 sentinels) — return nil
			// explicitly so the contract "non-nil response on success
			// only" is unambiguous (claude[bot] nit on PR #900).
			return nil, allocErr
		}
		reqs.StartTS = startTS
	}
	// Unreachable — the loop body always returns on each iteration.
	// Kept here so the function has an unambiguous return shape.
	return nil, errors.WithStack(ErrInvalidRequest)
}

func (c *ShardedCoordinator) pinStrictRouteVersion(reqs *OperationGroup[OP]) {
	if reqs.RequireAllParticipants && reqs.ObservedRouteVersion == 0 && c.engine != nil {
		reqs.ObservedRouteVersion = EncodeObservedRouteVersion(c.engine.Version())
	}
}

// JournalRouteVersion returns a pin for journal read/modify/write operations.
// Version zero is not a usable pin until its wire encoding is enabled.
func (c *ShardedCoordinator) JournalRouteVersion() (uint64, bool) {
	if c == nil || c.engine == nil {
		return 0, false
	}
	observed := EncodeObservedRouteVersion(c.engine.Version())
	return observed, observed != 0
}

func (c *ShardedCoordinator) ensureStrictRouteVersion(observed uint64, strict bool) error {
	if !strict || c.engine == nil {
		return nil
	}
	pinned, tracked := DecodeObservedRouteVersion(observed)
	if !tracked || c.engine.Version() != pinned {
		return errors.WithStack(ErrTransactionOutcomeUnknown)
	}
	return nil
}

// isComposed1RetryableError reports whether err is one of the M3 gate
// sentinels that M4 retries.  Both surface as wrapped errors from the
// underlying transactional Commit; errors.Is unwraps them correctly.
func isComposed1RetryableError(err error) bool {
	return errors.Is(err, ErrComposed1Violation) || errors.Is(err, ErrComposed1VersionGCd)
}

// dispatchNonTxn routes a non-transactional operation group through the
// shard router. Extracted from Dispatch to keep that method's branch
// count within the cyclop budget after the 7a registration gate landed.
func (c *ShardedCoordinator) dispatchNonTxn(ctx context.Context, reqs *OperationGroup[OP]) (*CoordinateResponse, rawDispatchShape, error) {
	if err := c.rejectWriteFencedPointElems(reqs.Elems); err != nil {
		return nil, rawDispatchShape{}, err
	}
	if hasExplicitGroupElem(reqs.Elems) {
		return c.dispatchExplicitGroupNonTxn(ctx, reqs)
	}
	logs, err := c.requestLogs(ctx, reqs)
	if err != nil {
		return nil, rawDispatchShape{}, err
	}
	r, groupCount, err := c.router.commitWithGroupCount(ctx, logs)
	shape := rawDispatchShape{groupCount: groupCount, requestCount: len(logs)}
	if err != nil {
		return nil, shape, errors.WithStack(err)
	}
	return &CoordinateResponse{CommitIndex: r.CommitIndex}, shape, nil
}

func hasExplicitGroupElem(elems []*Elem[OP]) bool {
	for _, elem := range elems {
		if elem != nil && elem.GroupID != 0 {
			return true
		}
	}
	return false
}

func (c *ShardedCoordinator) dispatchExplicitGroupNonTxn(ctx context.Context, reqs *OperationGroup[OP]) (*CoordinateResponse, rawDispatchShape, error) {
	logs, gids, err := c.rawLogsWithGroups(ctx, reqs)
	if err != nil {
		return nil, rawDispatchShape{}, err
	}
	shape := rawDispatchShape{groupCount: len(gids), requestCount: len(logs)}
	var maxIndex uint64
	for i, gid := range gids {
		g, err := c.txnGroupForID(gid)
		if err != nil {
			return nil, shape, err
		}
		resp, err := g.Txn.Commit(ctx, []*pb.Request{logs[i]})
		if err != nil {
			return nil, shape, errors.WithStack(err)
		}
		if resp != nil && resp.CommitIndex > maxIndex {
			maxIndex = resp.CommitIndex
		}
	}
	return &CoordinateResponse{CommitIndex: maxIndex}, shape, nil
}

func (c *ShardedCoordinator) dispatchRawWithComposed1Retry(ctx context.Context, reqs *OperationGroup[OP]) (*CoordinateResponse, error) {
	for attempt := 0; attempt <= composed1RetryAttempts; attempt++ {
		resp, shape, err := c.dispatchRawWithFenceRetry(ctx, reqs)
		if err == nil {
			return resp, nil
		}
		if errors.Is(err, ErrTransactionOutcomeUnknown) ||
			!errors.Is(err, ErrComposed1VersionGCd) || attempt == composed1RetryAttempts || c.engine == nil {
			return resp, err
		}
		if !shape.singleRequest() || !c.canRetryRawVersionGC(reqs) {
			return resp, err
		}
		reqs.ObservedRouteVersion = c.engine.Version()
	}
	return nil, errors.WithStack(ErrInvalidRequest)
}

func (c *ShardedCoordinator) canRetryRawVersionGC(reqs *OperationGroup[OP]) bool {
	if c == nil || c.router == nil || reqs == nil || hasDelPrefixElem(reqs.Elems) {
		return false
	}
	var (
		firstGID uint64
		seen     bool
	)
	for _, elem := range reqs.Elems {
		gid, ok := c.rawElemGroupID(elem)
		if !ok {
			return false
		}
		if !seen {
			firstGID = gid
			seen = true
			continue
		}
		if gid != firstGID {
			return false
		}
	}
	return seen
}

func (c *ShardedCoordinator) rawElemGroupID(elem *Elem[OP]) (uint64, bool) {
	if elem == nil {
		return 0, false
	}
	if elem.GroupID != 0 {
		return elem.GroupID, true
	}
	return c.router.ResolveGroup(elem.Key)
}

// hasDelPrefixElem returns true if any element is a DelPrefix operation.
func hasDelPrefixElem(elems []*Elem[OP]) bool {
	for _, e := range elems {
		if e != nil && e.Op == DelPrefix {
			return true
		}
	}
	return false
}

// validateDelPrefixOnly ensures all elements are DelPrefix operations.
// Mixing DEL_PREFIX with other operations (PUT, DEL) in a single dispatch is
// not allowed because the FSM handles DEL_PREFIX exclusively.
func validateDelPrefixOnly(elems []*Elem[OP]) error {
	for _, e := range elems {
		if e != nil && e.Op != DelPrefix {
			return errors.Wrap(ErrInvalidRequest, "DEL_PREFIX cannot be mixed with other operations")
		}
	}
	return nil
}

// dispatchDelPrefixBroadcast validates and broadcasts DEL_PREFIX operations
// to every configured all-shard data group. Each element becomes a separate
// pb.Request (the FSM's extractDelPrefix processes only the first DEL_PREFIX
// mutation per request). All requests are batched into a single Commit call
// per shard group.
func (c *ShardedCoordinator) dispatchDelPrefixBroadcast(ctx context.Context, isTxn bool, elems []*Elem[OP], observedRouteVersion uint64) (*CoordinateResponse, error) {
	if isTxn {
		return nil, errors.Wrap(ErrInvalidRequest, "DEL_PREFIX not supported in transactions")
	}
	if err := validateDelPrefixOnly(elems); err != nil {
		return nil, err
	}
	if err := c.rejectWriteFencedDelPrefixes(elems); err != nil {
		return nil, err
	}

	ts, err := c.allocateTimestamp(ctx, "allocate DEL_PREFIX broadcast ts")
	if err != nil {
		return nil, err
	}
	if err := c.rejectWriteTimestampFloorDelPrefixes(elems, ts); err != nil {
		return nil, err
	}
	if err := c.rejectDelPrefixesWithoutTargetReadinessProof(ctx, elems, ts); err != nil {
		return nil, err
	}
	requests := make([]*pb.Request, 0, len(elems))
	for _, elem := range elems {
		mut := elemToMutation(elem)
		if err := c.ensureMutationWriteAllowed(mut, ts); err != nil {
			return nil, err
		}
		requests = append(requests, &pb.Request{
			IsTxn:                false,
			Phase:                pb.Phase_NONE,
			Ts:                   ts,
			Mutations:            []*pb.Mutation{mut},
			ObservedRouteVersion: observedRouteVersion,
		})
	}

	return c.broadcastToAllGroups(ctx, requests)
}

func (c *ShardedCoordinator) rejectWriteFencedPointElems(elems []*Elem[OP]) error {
	if c == nil || c.engine == nil {
		return nil
	}
	for _, elem := range elems {
		if elem == nil || elem.GroupID != 0 {
			continue
		}
		if err := c.rejectWriteFencedPointKey(elem.Key); err != nil {
			return err
		}
	}
	return nil
}

func (c *ShardedCoordinator) rejectWriteFencedPointKey(key []byte) error {
	if c.partitionResolverRecognisesPointKey(key) {
		return nil
	}
	start, end, ok := s3BucketAuxiliaryRouteRange(key)
	if ok {
		route, found := s3BucketAuxiliaryOwnerRouteFromRange(start, end, c.engine.GetIntersectingRoutes(start, end))
		if found && route.State == distribution.RouteStateWriteFenced {
			return errors.Wrapf(ErrRouteWriteFenced, "key %q route range [%q,%q)", key, start, end)
		}
		return nil
	}
	rkey := routeKey(key)
	if route, ok := c.engine.GetRoute(rkey); ok && route.State == distribution.RouteStateWriteFenced {
		return errors.Wrapf(ErrRouteWriteFenced, "key %q routeKey %q", key, rkey)
	}
	return nil
}

func (c *ShardedCoordinator) partitionResolverRecognisesPointKey(key []byte) bool {
	if c == nil || c.router == nil || c.router.partitionResolver == nil || len(key) == 0 {
		return false
	}
	if _, ok := c.router.partitionResolver.ResolveGroup(key); ok {
		return true
	}
	return c.router.partitionResolver.RecognisesPartitionedKey(key)
}

func (c *ShardedCoordinator) writeFenceBypassKeysForElems(elems []*Elem[OP]) [][]byte {
	if len(elems) == 0 {
		return nil
	}
	out := make([][]byte, 0, len(elems))
	for _, elem := range elems {
		if elem == nil || elem.Op == DelPrefix || (elem.GroupID == 0 && !c.partitionResolverClaimsPointKey(elem.Key)) {
			continue
		}
		out = append(out, bytes.Clone(elem.Key))
	}
	return out
}

func (c *ShardedCoordinator) writeFenceBypassKeysByGroup(elems []*Elem[OP]) map[uint64][][]byte {
	out := make(map[uint64][][]byte)
	for _, elem := range elems {
		if elem == nil || elem.Op == DelPrefix {
			continue
		}
		gid := elem.GroupID
		if gid == 0 {
			var ok bool
			gid, ok = c.router.ResolveGroup(elem.Key)
			if !ok || !c.partitionResolverClaimsPointKey(elem.Key) {
				continue
			}
		}
		out[gid] = append(out[gid], bytes.Clone(elem.Key))
	}
	return out
}

func (c *ShardedCoordinator) partitionResolverClaimsPointKey(key []byte) bool {
	if c == nil || c.router == nil || c.router.partitionResolver == nil || len(key) == 0 {
		return false
	}
	_, ok := c.router.partitionResolver.ResolveGroup(key)
	return ok
}

func (c *ShardedCoordinator) rejectWriteFencedDelPrefixes(elems []*Elem[OP]) error {
	if c == nil || c.engine == nil {
		return nil
	}
	for _, elem := range elems {
		if elem == nil {
			continue
		}
		start, end := routePrefixRange(elem.Key)
		for _, route := range c.engine.GetIntersectingRoutes(start, end) {
			if route.State == distribution.RouteStateWriteFenced {
				return errors.Wrapf(ErrRouteWriteFenced, "prefix %q route range [%q,%q)", elem.Key, start, end)
			}
		}
	}
	return nil
}

func (c *ShardedCoordinator) rejectDelPrefixesWithoutTargetReadinessProof(ctx context.Context, elems []*Elem[OP], commitTS uint64) error {
	shards, ok := c.store.(*ShardStore)
	if !ok || shards == nil {
		return nil
	}
	for _, elem := range elems {
		if elem == nil {
			continue
		}
		if _, err := shards.verifyPrefixDeleteRoutes(ctx, elem.Key, commitTS); err != nil {
			return errors.Wrapf(err, "prefix %q", elem.Key)
		}
	}
	return nil
}

func (c *ShardedCoordinator) rejectWriteTimestampFloorPointKey(key []byte, commitTS uint64) error {
	if c == nil || c.engine == nil || commitTS == 0 {
		return nil
	}
	if c.skipPointWriteTimestampFloor(key) {
		return nil
	}
	if err := ensureLogicalRouteWriteAllowed(c.engine, key, commitTS); err != nil {
		return err
	}
	if checked, err := c.rejectS3BucketAuxiliaryWriteTimestampFloor(key, commitTS); checked || err != nil {
		return err
	}
	return c.rejectRawRouteWriteTimestampFloor(key, commitTS)
}

func (c *ShardedCoordinator) skipPointWriteTimestampFloor(key []byte) bool {
	// Same exemption rejectWriteFencedPointKey applies, and for the same
	// reason: in partition-resolved keyspaces such as HT-FIFO SQS, routeKey
	// collapses a concrete partition key onto the global SQS route, so that
	// route's floor is not this key's floor. Applying it here rejected writes
	// the write-fence precheck deliberately lets through, and the Raft-side
	// gate already covers these keys through the resolver's own routing.
	return c.partitionResolverRecognisesPointKey(key) || isTxnInternalKey(key)
}

func (c *ShardedCoordinator) rejectS3BucketAuxiliaryWriteTimestampFloor(key []byte, commitTS uint64) (bool, error) {
	start, end, ok := s3BucketAuxiliaryRouteRange(key)
	if !ok {
		return false, nil
	}
	route, found := s3BucketAuxiliaryOwnerRouteFromRange(start, end, c.engine.GetIntersectingRoutes(start, end))
	if found && route.MinWriteTSExclusive != 0 && commitTS <= route.MinWriteTSExclusive {
		return true, errors.Join(
			errors.Wrapf(ErrRouteWriteTimestampTooLow, "key %q route range [%q,%q) commit_ts=%d floor=%d", key, start, end, commitTS, route.MinWriteTSExclusive),
			store.NewWriteConflictError(key),
		)
	}
	return true, nil
}

func (c *ShardedCoordinator) rejectRawRouteWriteTimestampFloor(key []byte, commitTS uint64) error {
	rkey := routeKey(key)
	if route, ok := c.engine.GetRoute(rkey); ok && route.MinWriteTSExclusive != 0 && commitTS <= route.MinWriteTSExclusive {
		return routeWriteTimestampFloorError(route, key, commitTS)
	}
	return nil
}

func (c *ShardedCoordinator) rejectWriteTimestampFloorDelPrefixes(elems []*Elem[OP], commitTS uint64) error {
	if c == nil || c.engine == nil || commitTS == 0 {
		return nil
	}
	for _, elem := range elems {
		if elem == nil {
			continue
		}
		if err := c.rejectWriteTimestampFloorDelPrefix(elem.Key, commitTS); err != nil {
			return err
		}
	}
	return nil
}

func (c *ShardedCoordinator) rejectWriteTimestampFloorDelPrefix(prefix []byte, commitTS uint64) error {
	start, end := routePrefixRange(prefix)
	for _, route := range c.engine.GetIntersectingRoutes(start, end) {
		if route.MinWriteTSExclusive != 0 && commitTS <= route.MinWriteTSExclusive {
			return errors.Join(
				errors.Wrapf(ErrRouteWriteTimestampTooLow, "prefix %q route range [%q,%q) commit_ts=%d floor=%d", prefix, start, end, commitTS, route.MinWriteTSExclusive),
				store.NewWriteConflictError(prefix),
			)
		}
	}
	return nil
}

// broadcastToAllGroups sends the same set of requests to every configured
// all-shard data group in parallel and returns the maximum commit index.
func (c *ShardedCoordinator) broadcastToAllGroups(ctx context.Context, requests []*pb.Request) (*CoordinateResponse, error) {
	var (
		maxIndex atomic.Uint64
		firstErr error
		errMu    sync.Mutex
		wg       sync.WaitGroup
	)
	participants, err := c.admitBroadcastRequests(ctx, requests)
	if err != nil {
		return nil, err
	}
	for _, participant := range participants {
		wg.Add(1)
		go func(participant admittedBroadcastParticipant) {
			defer wg.Done()
			r, err := participant.group.Txn.Commit(ctx, participant.requests)
			if err != nil {
				errMu.Lock()
				firstErr = c.combineBroadcastErrors(firstErr, err)
				errMu.Unlock()
				return
			}
			if r != nil {
				for {
					cur := maxIndex.Load()
					if r.CommitIndex <= cur || maxIndex.CompareAndSwap(cur, r.CommitIndex) {
						break
					}
				}
			}
		}(participant)
	}
	wg.Wait()

	if firstErr != nil {
		return nil, errors.WithStack(firstErr)
	}
	return &CoordinateResponse{CommitIndex: maxIndex.Load()}, nil
}

func (c *ShardedCoordinator) combineBroadcastErrors(first, next error) error {
	if c.operationAdmission != nil {
		return errors.Join(first, next)
	}
	if first != nil {
		return first
	}
	return next
}

func (c *ShardedCoordinator) dispatchTxn(
	ctx context.Context,
	startTS uint64,
	commitTS uint64,
	prevCommitTS uint64,
	elems []*Elem[OP],
	readKeys [][]byte,
	observedRouteVersion uint64,
	label keyviz.Label,
	callerSuppliedStartTS bool,
	requireAllParticipants bool,
	selectedPrimary []byte,
) (*CoordinateResponse, error) {
	if len(readKeys) > maxReadKeys {
		return nil, errors.WithStack(ErrInvalidRequest)
	}
	grouped, gids, err := c.groupTxnMutations(elems, label, observedRouteVersion, requireAllParticipants)
	if err != nil {
		return nil, err
	}
	bypassKeysByGroup := c.writeFenceBypassKeysByGroup(elems)
	primaryKey := transactionPrimaryKey(elems, selectedPrimary)
	if len(primaryKey) == 0 {
		return nil, errors.WithStack(ErrTxnPrimaryKeyRequired)
	}
	singleShard := len(gids) == 1 && c.allReadKeysInShard(readKeys, gids[0])
	if err := c.validateCallerSuppliedTxnStart(ctx, startTS, singleShard, callerSuppliedStartTS); err != nil {
		return nil, err
	}
	if resp, handled, err := c.maybeDispatchLeaderStampedTxn(ctx, singleShard, startTS, commitTS, prevCommitTS, primaryKey, gids, elems, readKeys, observedRouteVersion); handled {
		return resp, err
	}

	commitTS, err = c.settleTxnCommitTimestamp(ctx, startTS, commitTS, elems, grouped, bypassKeysByGroup)
	if err != nil {
		return nil, err
	}

	if singleShard {
		// Fast path: all mutations and read keys are in a single shard.
		// Use the one-phase path without allocating a grouped-read-keys map.
		// If any read key belongs to a different shard the 2PC path is required
		// so that validateReadOnlyShards can issue a linearizable read barrier,
		// preserving SSI.
		return c.dispatchSingleShardTxn(ctx, startTS, commitTS, prevCommitTS, primaryKey, gids[0], elems, readKeys, observedRouteVersion, c.writeFenceBypassKeysForElems(elems))
	}
	if err := StampGroupedMutationCommitTS(grouped, commitTS); err != nil {
		return nil, err
	}
	return c.dispatchMultiShardTxn(ctx, startTS, commitTS, prevCommitTS, primaryKey, grouped, gids, readKeys, observedRouteVersion, bypassKeysByGroup, requireAllParticipants)
}

func (c *ShardedCoordinator) groupTxnMutations(elems []*Elem[OP], label keyviz.Label, observedRouteVersion uint64, strict bool) (map[uint64][]*pb.Mutation, []uint64, error) {
	grouped, gids, err := c.groupMutations(elems, label)
	if err != nil {
		return nil, nil, err
	}
	if err := c.ensureStrictRouteVersion(observedRouteVersion, strict); err != nil {
		return nil, nil, err
	}
	return grouped, gids, nil
}

func requireAllParticipantsFlag(flags []bool) bool {
	return len(flags) > 0 && flags[0]
}

func (c *ShardedCoordinator) maybeDispatchLeaderStampedTxn(ctx context.Context, singleShard bool, startTS, commitTS, prevCommitTS uint64, primaryKey []byte, gids []uint64, elems []*Elem[OP], readKeys [][]byte, observedRouteVersion uint64) (*CoordinateResponse, bool, error) {
	if !singleShard || commitTS != 0 || ctx.Value(leaderIssuedCommitTSContextKey{}) != true {
		return nil, false, nil
	}
	resp, err := c.dispatchSingleShardTxnLeaderStamped(ctx, startTS, prevCommitTS, primaryKey, gids[0], elems, readKeys, observedRouteVersion, c.writeFenceBypassKeysForElems(elems))
	return resp, true, err
}

func (c *ShardedCoordinator) dispatchSingleShardTxnLeaderStamped(ctx context.Context, startTS, prevCommitTS uint64, primaryKey []byte, gid uint64, elems []*Elem[OP], readKeys [][]byte, observedRouteVersion uint64, writeFenceBypassKeys [][]byte) (*CoordinateResponse, error) {
	g, err := c.txnGroupForID(gid)
	if err != nil {
		return nil, err
	}
	readKeys = c.readKeysWithStagedVisibilityAliasesForGroup(gid, readKeys)
	readKeys = c.readKeysWithStagedVisibilityMutationAliasesForGroup(gid, readKeys, elems)
	if len(readKeys) > maxReadKeys {
		return nil, errors.WithStack(ErrInvalidRequest)
	}
	resp, err := g.Txn.Commit(ctx, []*pb.Request{
		onePhaseTxnRequestWithPrevCommit(startTS, 0, prevCommitTS, primaryKey, elems, readKeys, observedRouteVersion, writeFenceBypassKeys),
	})
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if resp == nil || resp.CommitTS <= startTS {
		return nil, errors.WithStack(ErrTxnCommitTSRequired)
	}
	if c.clock != nil {
		c.clock.Observe(resp.CommitTS)
	}
	return &CoordinateResponse{CommitIndex: resp.CommitIndex, CommitTS: resp.CommitTS}, nil
}

// settleTxnCommitTimestamp resolves the commit timestamp and then applies the
// two checks that depend on it: the per-element commit-ts patches have to agree
// with the settled value, and the route write floors have to admit a write at
// it. Both belong after allocation and before any dispatch, so they travel with
// the allocation rather than being repeated at each call site.
func (c *ShardedCoordinator) settleTxnCommitTimestamp(
	ctx context.Context,
	startTS uint64,
	commitTS uint64,
	elems []*Elem[OP],
	grouped map[uint64][]*pb.Mutation,
	bypassKeysByGroup map[uint64][][]byte,
) (uint64, error) {
	settled, err := c.prepareTxnCommitTimestamp(ctx, startTS, commitTS, elems)
	if err != nil {
		return 0, err
	}
	if err := ValidateElemCommitTSPatches(elems, settled); err != nil {
		return 0, err
	}
	if err := c.ensureGroupedMutationsWriteAllowedWithBypass(grouped, settled, bypassKeysByGroup); err != nil {
		return 0, err
	}
	return settled, nil
}

func (c *ShardedCoordinator) validateCallerSuppliedTxnStart(ctx context.Context, startTS uint64, singleShard, callerSupplied bool) error {
	if !callerSupplied {
		return nil
	}
	if c.consumeAppliedReadTimestampVoucher(ctx, startTS) || singleShard {
		return nil
	}
	return c.validateCrossShardReadTimestamp(ctx, startTS)
}

func (c *ShardedCoordinator) prepareTxnCommitTimestamp(ctx context.Context, startTS, commitTS uint64, elems []*Elem[OP]) (uint64, error) {
	callerSuppliedCommitTS := commitTS != 0
	resolved, err := c.resolveTxnCommitTS(ctx, startTS, commitTS)
	if err != nil {
		return 0, err
	}
	if callerSuppliedCommitTS {
		if err := c.validateCallerSuppliedTxnCommit(ctx, resolved); err != nil {
			return 0, err
		}
		if c.clock != nil {
			// Only publish caller-provided CommitTS after Phase-D validation.
			// Observe is permanent, so an invalid future commit timestamp must
			// not poison later local HLC issuance.
			c.clock.Observe(resolved)
		}
	}
	if err := ValidateElemCommitTSPatches(elems, resolved); err != nil {
		return 0, err
	}
	return resolved, nil
}

func (c *ShardedCoordinator) validateCallerSuppliedTxnCommit(ctx context.Context, commitTS uint64) error {
	validator, _, required, err := phaseDTimestampValidator(c.tsAllocator)
	if err != nil {
		return errors.Wrap(err, "caller-supplied commit timestamp validator is unavailable")
	}
	if !required {
		return nil
	}
	if err := validator.ValidateDurableTimestamp(ctx, commitTS); err != nil {
		return errors.Wrap(err, "validate caller-supplied commit timestamp")
	}
	return nil
}

func (c *ShardedCoordinator) validateCrossShardReadTimestamp(
	ctx context.Context,
	startTS uint64,
) error {
	validator, _, required, err := phaseDTimestampValidator(c.tsAllocator)
	if err != nil {
		return errors.Wrap(err, "cross-shard read timestamp validator is unavailable")
	}
	if !required {
		return nil
	}
	if err := validator.ValidateDurableTimestamp(ctx, startTS); err != nil {
		return errors.Wrap(err, "validate cross-shard read/start timestamp")
	}
	return nil
}

// dispatchMultiShardTxn runs the 2PC path. Extracted from dispatchTxn to keep
// that function under the cyclop budget after the prevCommitTS reject was
// added; the multi-shard branch already carries five linear
// error checks (groupReadKeys, prewrite, commitPrimary, abortCleanup,
// commitSecondaries) that pushed the parent over the 10-edge limit.
func (c *ShardedCoordinator) dispatchMultiShardTxn(ctx context.Context, startTS, commitTS, prevCommitTS uint64, primaryKey []byte, grouped map[uint64][]*pb.Mutation, gids []uint64, readKeys [][]byte, observedRouteVersion uint64, bypassKeysByGroup map[uint64][][]byte, requireAllParticipants ...bool) (*CoordinateResponse, error) {
	// Fail-closed when a retry carries the option-2 dedup probe key but its
	// write set / read set spans shards (codex P2 round-10 "reject retries
	// that leave the one-phase path"). The 2PC log builders only encode
	// CommitTS and would silently drop PrevCommitTS — a landed ambiguous
	// attempt would then look like an ordinary write conflict, the adapter
	// would drop pending and recompute, and the duplicate this feature is
	// meant to prevent would reappear. Surface the constraint explicitly so
	// the caller (or a future multi-shard dedup design) knows the request
	// shape is unsupported.
	if prevCommitTS != 0 {
		return nil, errors.WithStack(ErrTxnDedupRequiresSingleShard)
	}
	releaseIdentity, err := c.acquireTxnIdentity(primaryKey, startTS)
	if err != nil {
		return nil, err
	}
	// An uncertain PREPARE or failed cleanup may leave an in-flight proposal
	// or lock behind. Keep its identity reserved in this coordinator rather
	// than admitting a different attempt as an idempotent replay. A caller can
	// still retry at a fresh snapshot, which has a different identity. Without
	// a proof that every proposal and lock resolved, the reservation lasts
	// until this coordinator is discarded.
	retainIdentity := false
	defer func() {
		if retainIdentity {
			count := c.retainedTxnCount.Add(1)
			c.logger().Warn("txn identity retained after unresolved outcome",
				slog.Uint64("start_ts", startTS),
				slog.Uint64("retained_identity_count", count))
			return
		}
		releaseIdentity()
	}()

	// Group read keys by shard now. The result is passed directly to
	// prewriteTxn to avoid a second iteration inside that function. A
	// routing failure here aborts the transaction before any prewrite —
	// silently dropping unresolvable read keys would let OCC validation
	// run with an incomplete read set and break SSI.
	groupedReadKeys, err := c.groupReadKeysByShardID(readKeys)
	if err != nil {
		return nil, err
	}
	groupedReadKeys = c.groupedReadKeysWithStagedVisibilityMutationAliases(groupedReadKeys, grouped)
	if groupedReadKeyCount(groupedReadKeys) > maxReadKeys {
		return nil, errors.WithStack(ErrInvalidRequest)
	}
	prepared, unresolved, err := c.prewriteTxn(ctx, startTS, commitTS, primaryKey, grouped, gids, groupedReadKeys, observedRouteVersion, bypassKeysByGroup)
	if err != nil {
		retainIdentity = unresolved
		return nil, err
	}

	primaryGid, maxIndex, err := c.commitPrimaryTxn(ctx, startTS, primaryKey, grouped, gids, commitTS, observedRouteVersion, bypassKeysByGroup)
	if err != nil {
		if primaryCommitDefinitelyRejected(err) {
			// A deterministic apply verdict or pre-append leadership rejection
			// is a definitive non-commit. Release prepared intents even if the
			// caller has since cancelled.
			cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), verifyLeaderTimeout)
			cleaned := c.abortPreparedTxn(cleanupCtx, startTS, primaryKey, prepared, c.abortTimestamp(cleanupCtx, startTS, commitTS))
			cancel()
			retainIdentity = !cleaned
			return nil, errors.WithStack(err)
		}
		// A lost primary COMMIT response may conceal a durable commit
		// decision. Aborting prepared secondaries here can then turn one
		// committed transaction into a partial commit. Lock resolution must
		// consult the primary decision; retain the intents until it does.
		retainIdentity = true
		return nil, fmt.Errorf("%w: %w", ErrTransactionOutcomeUnknown, err)
	}

	// commitSecondaryTxns propagates ObservedRouteVersion to per-
	// secondary commits so the M3 gate fires on route shifts between
	// primary-COMMIT and secondary-COMMIT.  Such a sentinel surfaces
	// as ErrTxnSecondaryRouteShiftedAfterPrimaryCommit (NOT
	// ErrComposed1Violation — the M4 retry must not loop here; the
	// primary is already durable and re-prewriting would conflict
	// with the existing locks).  d8487672 originally tried to avoid
	// the silent-partial-commit hazard by dropping the gate; codex
	// P1 (20:30:35) correctly showed that the dropped-gate posture
	// silently lands writes on stale owners that are no longer
	// reachable by readers on the new owner.  Both directions are
	// silent partial commits; surfacing the error is the only honest
	// posture (codex P1 on d8487672 + 6202b964, PR #900).
	maxIndex, err = c.commitSecondaryTxns(ctx, startTS, primaryGid, primaryKey, grouped, gids, commitTS, maxIndex, observedRouteVersion, bypassKeysByGroup, requireAllParticipants...)
	if err != nil {
		retainIdentity = true
		return nil, errors.WithStack(err)
	}
	return &CoordinateResponse{CommitIndex: maxIndex, CommitTS: commitTS}, nil
}

func primaryCommitDefinitelyRejected(err error) bool {
	if errors.Is(err, ErrTransactionOutcomeUnknown) {
		return false
	}
	return isRawApplyVerdict(err) ||
		errors.Is(err, ErrComposed1Violation) ||
		errors.Is(err, raftengine.ErrNotLeader) ||
		errors.Is(err, raftengine.ErrLeadershipTransferInProgress)
}

func (c *ShardedCoordinator) resolveTxnCommitTS(ctx context.Context, startTS, commitTS uint64) (uint64, error) {
	if commitTS == 0 {
		next, err := c.nextTxnTSAfter(ctx, startTS)
		if err != nil {
			return 0, err
		}
		commitTS = next
	}
	if commitTS == 0 || commitTS <= startTS {
		return 0, errors.WithStack(ErrTxnCommitTSRequired)
	}
	return commitTS, nil
}

// allReadKeysInShard returns true when every key in readKeys belongs to gid.
// It performs a single O(n) pass without allocating a map, making it suitable
// for the single-shard fast path in dispatchTxn.
func (c *ShardedCoordinator) allReadKeysInShard(readKeys [][]byte, gid uint64) bool {
	for _, rk := range readKeys {
		if c.engineGroupIDForKey(rk) != gid {
			return false
		}
	}
	return true
}

func (c *ShardedCoordinator) dispatchSingleShardTxn(ctx context.Context, startTS, commitTS, prevCommitTS uint64, primaryKey []byte, gid uint64, elems []*Elem[OP], readKeys [][]byte, observedRouteVersion uint64, writeFenceBypassKeys [][]byte) (*CoordinateResponse, error) {
	g, err := c.txnGroupForID(gid)
	if err != nil {
		return nil, err
	}
	readKeys = c.readKeysWithStagedVisibilityAliasesForGroup(gid, readKeys)
	readKeys = c.readKeysWithStagedVisibilityMutationAliasesForGroup(gid, readKeys, elems)
	if len(readKeys) > maxReadKeys {
		return nil, errors.WithStack(ErrInvalidRequest)
	}
	// ReadKeys are included in the Raft log entry so the FSM validates
	// read-write conflicts atomically under applyMu. prevCommitTS, when set,
	// carries the one-phase dedup probe key for a retry that reuses a failed
	// attempt's write set.
	resp, err := g.Txn.Commit(ctx, []*pb.Request{
		onePhaseTxnRequestWithPrevCommit(startTS, commitTS, prevCommitTS, primaryKey, elems, readKeys, observedRouteVersion, writeFenceBypassKeys),
	})
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if resp == nil {
		return nil, errors.WithStack(ErrTransactionOutcomeUnknown)
	}
	return &CoordinateResponse{CommitIndex: resp.CommitIndex, CommitTS: commitTS}, nil
}

func (c *ShardedCoordinator) readKeysWithStagedVisibilityAliasesForGroup(gid uint64, readKeys [][]byte) [][]byte {
	if len(readKeys) == 0 {
		return readKeys
	}
	var out [][]byte
	for _, key := range readKeys {
		alias, ok := c.stagedVisibilityReadKeyAlias(gid, key)
		if !ok {
			continue
		}
		if out == nil {
			out = append([][]byte(nil), readKeys...)
		}
		out = append(out, alias)
	}
	if out == nil {
		return readKeys
	}
	return out
}

func (c *ShardedCoordinator) readKeysWithStagedVisibilityMutationAliasesForGroup(gid uint64, readKeys [][]byte, elems []*Elem[OP]) [][]byte {
	var out [][]byte
	for _, elem := range elems {
		if elem == nil {
			continue
		}
		alias, ok := c.stagedVisibilityReadKeyAlias(gid, elem.Key)
		if !ok {
			continue
		}
		if out == nil {
			out = append([][]byte(nil), readKeys...)
		}
		out = append(out, alias)
	}
	if out == nil {
		return readKeys
	}
	return out
}

type preparedGroup struct {
	gid  uint64
	keys []*pb.Mutation
}

// prewriteTxn reports whether an error may leave a PREPARE or lock unresolved.
// That identity must remain reserved even after the request returns.
func (c *ShardedCoordinator) prewriteTxn(ctx context.Context, startTS, commitTS uint64, primaryKey []byte, grouped map[uint64][]*pb.Mutation, gids []uint64, groupedReadKeys map[uint64][][]byte, observedRouteVersion uint64, bypassKeysByGroup map[uint64][][]byte) ([]preparedGroup, bool, error) {
	prepareMetas, err := c.prepareEvidenceMetas(ctx, primaryKey, commitTS, gids)
	if err != nil {
		return nil, false, err
	}
	prepared := make([]preparedGroup, 0, len(gids))

	for _, gid := range gids {
		g, err := c.txnGroupForID(gid)
		if err != nil {
			cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), verifyLeaderTimeout)
			cleaned := c.abortPreparedTxn(cleanupCtx, startTS, primaryKey, prepared, c.abortTimestamp(cleanupCtx, startTS, commitTS))
			cancel()
			return nil, !cleaned, err
		}
		req := &pb.Request{
			IsTxn:                true,
			Phase:                pb.Phase_PREPARE,
			Ts:                   startTS,
			Mutations:            append([]*pb.Mutation{prepareMetas[gid]}, grouped[gid]...),
			ReadKeys:             groupedReadKeys[gid],
			ObservedRouteVersion: observedRouteVersion,
			WriteFenceBypassKeys: bypassKeysByGroup[gid],
		}
		response, err := g.Txn.Commit(ctx, []*pb.Request{req})
		if err == nil && response == nil {
			err = ErrTransactionOutcomeUnknown
		}
		if err != nil {
			if errors.Is(err, ErrTransactionOutcomeUnknown) {
				return nil, true, errors.WithStack(err)
			}
			// Same WithoutCancel pattern as dispatchTxn's
			// commitPrimaryTxn-failure cleanup: a cancelled ctx is
			// the most likely cause of Commit failing here, and the
			// abort MUST still go through to release the intents we
			// already wrote on prior shards. Otherwise LockResolver
			// holds the bag.
			cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), verifyLeaderTimeout)
			cleaned := c.abortPreparedTxn(cleanupCtx, startTS, primaryKey, prepared, c.abortTimestamp(cleanupCtx, startTS, commitTS))
			cancel()
			return nil, !primaryCommitDefinitelyRejected(err) || !cleaned, errors.WithStack(err)
		}
		prepared = append(prepared, preparedGroup{gid: gid, keys: keyMutations(grouped[gid])})
	}

	// Validate read keys on read-only shards (shards that have read keys
	// but no mutations in this transaction). Without this, a concurrent
	// write to a read-only shard would go undetected.
	if err := c.validateReadOnlyShards(ctx, groupedReadKeys, gids, startTS); err != nil {
		// Same reasoning as the prepare-loop cleanup above: the
		// validate read fence may have failed because ctx
		// expired, so the abort needs detached cancellation to
		// avoid stranding intents.
		cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), verifyLeaderTimeout)
		cleaned := c.abortPreparedTxn(cleanupCtx, startTS, primaryKey, prepared, c.abortTimestamp(cleanupCtx, startTS, commitTS))
		cancel()
		return nil, !cleaned, err
	}

	return prepared, false, nil
}

func (c *ShardedCoordinator) commitPrimaryTxn(ctx context.Context, startTS uint64, primaryKey []byte, grouped map[uint64][]*pb.Mutation, gids []uint64, commitTS uint64, observedRouteVersion uint64, bypassKeysByGroup map[uint64][][]byte) (uint64, uint64, error) {
	primaryGid, ok := primaryGroupIDForKey(primaryKey, grouped, gids)
	if !ok {
		return 0, 0, errors.WithStack(ErrInvalidRequest)
	}

	g, err := c.txnGroupForID(primaryGid)
	if err != nil {
		return 0, 0, err
	}

	meta := txnMetaMutation(primaryKey, 0, commitTS)
	keys := keyMutations(grouped[primaryGid])
	req := &pb.Request{
		IsTxn:                true,
		Phase:                pb.Phase_COMMIT,
		Ts:                   startTS,
		Mutations:            append([]*pb.Mutation{meta}, keys...),
		ObservedRouteVersion: observedRouteVersion,
		WriteFenceBypassKeys: bypassKeysByGroup[primaryGid],
	}

	r, err := g.Txn.Commit(ctx, []*pb.Request{req})
	if err != nil {
		return primaryGid, 0, errors.WithStack(err)
	}
	if r == nil {
		return primaryGid, 0, errors.WithStack(ErrTransactionOutcomeUnknown)
	}
	return primaryGid, r.CommitIndex, nil
}

func primaryGroupIDForKey(primaryKey []byte, grouped map[uint64][]*pb.Mutation, gids []uint64) (uint64, bool) {
	for _, gid := range gids {
		for _, mut := range grouped[gid] {
			if mut != nil && bytes.Equal(mut.Key, primaryKey) {
				return gid, true
			}
		}
	}
	return 0, false
}

func (c *ShardedCoordinator) commitSecondaryTxns(ctx context.Context, startTS uint64, primaryGid uint64, primaryKey []byte, grouped map[uint64][]*pb.Mutation, gids []uint64, commitTS uint64, maxIndex uint64, observedRouteVersion uint64, bypassKeysByGroup map[uint64][][]byte, requireAllParticipants ...bool) (uint64, error) {
	// Secondary commits are best-effort for non-Composed-1 errors:
	// if a shard is unavailable after the primary commits, read-time
	// lock resolution will commit the remaining secondaries based on
	// the primary commit record.  Retry a few times to absorb short
	// leader-election windows and reduce lock lag.
	//
	// Composed-1 errors are an exception (codex P1 on d8487672 +
	// 6202b964, PR #900).  When the M3 gate fires on a secondary
	// commit, the route catalog has moved between primary-COMMIT and
	// this secondary-COMMIT — the prepared lock lives at the old
	// gid, the new owner per the catalog has no commit record.  We
	// CANNOT silently land the write on the stale owner (codex 20:30:35
	// — that's invisible to readers on the new owner) and we CANNOT
	// silently swallow the error (codex 20:10:32 — uncommitted
	// secondary, silent partial commit on the missing direction).
	// The only honest posture is to surface
	// ErrTxnSecondaryRouteShiftedAfterPrimaryCommit so the caller
	// knows the txn state is uncertain and can do application-level
	// recovery.  This sentinel is distinct from ErrComposed1Violation
	// so the M4 retry path does not loop here (the primary is durable
	// and re-prewriting would conflict with the existing locks).
	meta := txnMetaMutation(primaryKey, 0, commitTS)
	strict := requireAllParticipantsFlag(requireAllParticipants)
	for _, gid := range gids {
		if gid == primaryGid {
			continue
		}
		index, err := c.commitOneSecondary(ctx, gid, startTS, commitTS, primaryKey, meta,
			grouped[gid], observedRouteVersion, bypassKeysByGroup[gid], strict)
		if err != nil {
			return maxIndex, err
		}
		maxIndex = max(maxIndex, index)
	}
	return maxIndex, nil
}

func (c *ShardedCoordinator) commitOneSecondary(ctx context.Context, gid, startTS, commitTS uint64, primaryKey []byte, meta *pb.Mutation, mutations []*pb.Mutation, observedRouteVersion uint64, bypassKeys [][]byte, strict bool) (uint64, error) {
	g, ok := c.groups[gid]
	if !ok || g == nil || g.Txn == nil {
		if strict {
			return 0, errors.WithStack(ErrTransactionOutcomeUnknown)
		}
		return 0, nil
	}
	req := &pb.Request{
		IsTxn:                true,
		Phase:                pb.Phase_COMMIT,
		Ts:                   startTS,
		Mutations:            append([]*pb.Mutation{meta}, keyMutations(mutations)...),
		ObservedRouteVersion: observedRouteVersion,
		WriteFenceBypassKeys: bypassKeys,
	}
	response, err := commitSecondaryWithRetry(ctx, g, req, c.operationAdmission != nil)
	if err != nil {
		return 0, c.secondaryCommitFailure(err, gid, startTS, commitTS, primaryKey, strict)
	}
	if response == nil {
		if strict {
			return 0, errors.WithStack(ErrTransactionOutcomeUnknown)
		}
		return 0, nil
	}
	return response.CommitIndex, nil
}

func (c *ShardedCoordinator) secondaryCommitFailure(err error, gid, startTS, commitTS uint64, primaryKey []byte, strict bool) error {
	if strict || c.operationAdmission != nil {
		return fmt.Errorf("%w: %w", ErrTransactionOutcomeUnknown, err)
	}
	message := "txn secondary commit failed"
	if isComposed1RetryableError(err) {
		message = "txn secondary commit failed Composed-1 — surfacing as fatal"
	}
	c.logger().Warn(message,
		slog.Uint64("gid", gid),
		slog.String("primary_key", string(primaryKey)),
		slog.Uint64("start_ts", startTS),
		slog.Uint64("commit_ts", commitTS),
		slog.Any("err", err),
	)
	if isComposed1RetryableError(err) {
		return errors.WithStack(ErrTxnSecondaryRouteShiftedAfterPrimaryCommit)
	}
	return nil
}

func commitSecondaryWithRetry(ctx context.Context, g *ShardGroup, req *pb.Request, preserveOutcomes ...bool) (*TransactionResponse, error) {
	if g == nil || g.Txn == nil || req == nil {
		return nil, errors.WithStack(ErrInvalidRequest)
	}
	var lastErr error
	for attempt := range txnSecondaryCommitRetryAttempts {
		resp, err := g.Txn.Commit(ctx, []*pb.Request{req})
		if err == nil {
			return resp, nil
		}
		if requireAllParticipantsFlag(preserveOutcomes) && errors.Is(err, ErrTransactionOutcomeUnknown) {
			return nil, errors.WithStack(err)
		}
		lastErr = err
		if attempt+1 < txnSecondaryCommitRetryAttempts {
			time.Sleep(txnSecondaryCommitRetryBackoff * time.Duration(attempt+1))
		}
	}
	return nil, errors.WithStack(lastErr)
}

func (c *ShardedCoordinator) logger() *slog.Logger {
	if c != nil && c.log != nil {
		return c.log
	}
	return slog.Default()
}

// abortPreparedTxn returns true only when every prepared group has a terminal
// cleanup result. Failed or unissued aborts keep the identity reserved.
func (c *ShardedCoordinator) abortPreparedTxn(ctx context.Context, startTS uint64, primaryKey []byte, prepared []preparedGroup, abortTS uint64) bool {
	if len(prepared) == 0 {
		return true
	}
	if abortTS == 0 || abortTS <= startTS {
		return false
	}

	cleaned := true
	meta := txnMetaMutation(primaryKey, 0, abortTS)
	for _, pg := range prepared {
		if !c.abortPreparedGroup(ctx, startTS, primaryKey, abortTS, meta, pg) {
			cleaned = false
		}
	}
	return cleaned
}

func (c *ShardedCoordinator) abortPreparedGroup(ctx context.Context, startTS uint64, primaryKey []byte, abortTS uint64, meta *pb.Mutation, pg preparedGroup) bool {
	g, ok := c.groups[pg.gid]
	if !ok || g == nil || g.Txn == nil {
		return false
	}
	req := &pb.Request{
		IsTxn:     true,
		Phase:     pb.Phase_ABORT,
		Ts:        startTS,
		Mutations: append([]*pb.Mutation{meta}, pg.keys...),
	}
	response, err := g.Txn.Commit(ctx, []*pb.Request{req})
	if err == nil && response == nil {
		err = ErrTransactionOutcomeUnknown
	}
	if errors.Is(err, ErrTxnAlreadyCommitted) {
		return true
	}
	if err != nil {
		c.logger().Warn("txn abort failed; locks may remain until TTL expiry",
			slog.Uint64("gid", pg.gid),
			slog.String("primary_key", string(primaryKey)),
			slog.Uint64("start_ts", startTS),
			slog.Uint64("abort_ts", abortTS),
			slog.Any("err", err),
		)
		return false
	}
	return true
}

func (c *ShardedCoordinator) txnGroupForID(gid uint64) (*ShardGroup, error) {
	g, ok := c.groups[gid]
	if !ok || g == nil || g.Txn == nil {
		return nil, errors.Wrapf(ErrInvalidRequest, "unknown group %d", gid)
	}
	return g, nil
}

func (c *ShardedCoordinator) allocateTimestamp(ctx context.Context, label string) (uint64, error) {
	return c.allocateTimestampAfter(ctx, label, 0)
}

func (c *ShardedCoordinator) allocateTimestampAfter(ctx context.Context, label string, min uint64) (uint64, error) {
	group := c.defaultGroup
	if timestampGroup, ok := c.effectiveTimestampGroup(); ok {
		group = timestampGroup
	}
	return admittedOperation(ctx, c.operationAdmission, group, AdmissionAllocator, func(owned context.Context) (uint64, error) {
		return c.allocateAdmittedTimestampAfter(owned, label, min)
	})
}

func (c *ShardedCoordinator) allocateAdmittedTimestampAfter(ctx context.Context, label string, min uint64) (uint64, error) {
	if min == ^uint64(0) {
		return 0, errors.Wrap(ErrTxnCommitTSRequired, label)
	}
	if allocator, ok := resolveTimestampAllocator(c.tsAllocator); ok {
		if min > 0 {
			return nextTimestampAfterFromAllocator(ctx, allocator, min, label)
		}
		return nextTimestampFromAllocator(ctx, allocator, label)
	}
	if c.tsoCutoverState != nil && c.tsoCutoverState.PhaseDActive() {
		return 0, errors.Wrap(ErrTSOAllocatorRequired,
			"legacy HLC issuance is disabled by durable TSO phase D")
	}
	if c.clock == nil {
		return 0, errors.Wrap(ErrTSOClockNil, label)
	}
	if min > 0 {
		c.clock.Observe(min)
	}
	return nextFencedWithRecovery(ctx, c.clock, c, label)
}

// Next makes ShardedCoordinator usable as a TimestampAllocator for adapter
// helpers that need to allocate persistence-grade timestamps outside Dispatch.
func (c *ShardedCoordinator) Next(ctx context.Context) (uint64, error) {
	return c.allocateTimestamp(ctx, "allocate sharded timestamp")
}

func (c *ShardedCoordinator) NextAfter(ctx context.Context, min uint64) (uint64, error) {
	return c.allocateTimestampAfter(ctx, "allocate sharded timestamp after observed ts", min)
}

func (c *ShardedCoordinator) nextTxnTSAfter(ctx context.Context, startTS uint64) (uint64, error) {
	_, allocatorConfigured := resolveTimestampAllocator(c.tsAllocator)
	if c.clock == nil && !allocatorConfigured {
		nextTS := startTS + 1
		if nextTS == 0 {
			return 0, nil
		}
		return nextTS, nil
	}
	ts, err := c.allocateTimestampAfter(ctx, "allocate txn commit ts", startTS)
	if err != nil {
		return 0, err
	}
	if ts <= startTS {
		if c.clock != nil {
			c.clock.Observe(startTS)
		}
		ts, err = c.allocateTimestampAfter(ctx, "re-allocate txn commit ts after Observe", startTS)
		if err != nil {
			return 0, err
		}
	}
	if ts <= startTS {
		return 0, nil
	}
	return ts, nil
}

// abortTimestamp obtains the timestamp a rollback record is written under.
//
// Deriving commitTS+1 arithmetically claims a value the allocator never handed
// out. With BatchAllocator that neighbour is still inside the reserved window
// and goes to the next transaction, so the rollback record and that transaction
// would share one supposedly global timestamp.
//
// Returning zero when allocation fails leaves the rollback undone --
// abortPreparedTxn skips a zero timestamp -- and the prewrite intents wait for
// LockResolver. That is the lesser harm. Persisting the derived neighbour
// anyway would write a value the allocator never issued, and a later refill can
// hand that same value to another transaction; a warning log does not make the
// persisted timestamp safe.
func (c *ShardedCoordinator) abortTimestamp(ctx context.Context, startTS, commitTS uint64) uint64 {
	base := max(startTS, commitTS)
	ts, err := c.nextTxnTSAfter(ctx, base)
	if err == nil && ts > base {
		return ts
	}
	c.logger().WarnContext(ctx,
		"abort timestamp allocation failed; leaving intents for the lock resolver",
		"start_ts", startTS,
		"commit_ts", commitTS,
		"err", err,
	)
	return 0
}

func abortTSFrom(startTS, commitTS uint64) uint64 {
	const maxUint64 = ^uint64(0)

	// Prefer commitTS+1 when representable and strictly greater than startTS.
	if commitTS < maxUint64 {
		abortTS := commitTS + 1
		if abortTS > startTS {
			return abortTS
		}
	}

	// Fallback to startTS+1 when representable.
	if startTS < maxUint64 {
		return startTS + 1
	}

	// No representable timestamp exists that is strictly greater than startTS.
	return 0
}

func txnMetaMutation(primaryKey []byte, lockTTLms uint64, commitTS uint64) *pb.Mutation {
	return &pb.Mutation{
		Op:    pb.Op_PUT,
		Key:   []byte(txnMetaPrefix),
		Value: EncodeTxnMeta(TxnMeta{PrimaryKey: primaryKey, LockTTLms: lockTTLms, CommitTS: commitTS}),
	}
}

func (c *ShardedCoordinator) nextStartTS(ctx context.Context, elems []*Elem[OP]) (uint64, error) {
	maxTS, err := c.maxLatestCommitTS(ctx, elems)
	if err != nil {
		return 0, err
	}
	if c.clock != nil && maxTS > 0 {
		c.clock.Observe(maxTS)
	}
	_, allocatorConfigured := resolveTimestampAllocator(c.tsAllocator)
	if c.clock == nil && !allocatorConfigured {
		return maxTS + 1, nil
	}
	ts, err := c.allocateTimestampAfter(ctx, "allocate sharded startTS", maxTS)
	if err != nil {
		return 0, err
	}
	return ts, nil
}

func (c *ShardedCoordinator) maxLatestCommitTS(ctx context.Context, elems []*Elem[OP]) (uint64, error) {
	if c.store == nil {
		return 0, nil
	}

	keys := make([][]byte, 0, len(elems))
	for _, e := range elems {
		if e == nil || len(e.Key) == 0 {
			continue
		}
		keys = append(keys, e.Key)
	}

	return MaxLatestCommitTS(ctx, c.store, keys)
}

func (c *ShardedCoordinator) IsLeader() bool {
	g, ok := c.groups[c.defaultGroup]
	if !ok {
		return false
	}
	return isLeaderEngine(engineForGroup(g))
}

func (c *ShardedCoordinator) IsTimestampLeader() bool {
	if c == nil {
		return false
	}
	if groupID, ok := c.effectiveTimestampGroup(); ok {
		return isLeaderEngine(engineForGroup(c.groups[groupID]))
	}
	for _, groupID := range c.timestampBridgeCandidateGroupIDs() {
		if isLeaderEngine(engineForGroup(c.groups[groupID])) {
			return true
		}
	}
	return false
}

func (c *ShardedCoordinator) timestampBridgeCandidateGroupIDs() []uint64 {
	if c == nil {
		return nil
	}
	if c.allShardGroupsConfigured {
		ids := make([]uint64, 0, len(c.allShardGroupIDs))
		for _, groupID := range c.allShardGroupIDs {
			if groupID == 0 {
				continue
			}
			if _, ok := c.groups[groupID]; ok {
				ids = append(ids, groupID)
			}
		}
		return ids
	}
	ids := make([]uint64, 0, len(c.groups))
	for groupID := range c.groups {
		if groupID == 0 {
			continue
		}
		ids = append(ids, groupID)
	}
	slices.Sort(ids)
	return ids
}

var _ LocalLeaderGroupsCoordinator = (*ShardedCoordinator)(nil)

// LocalLeaderGroupIDs returns the configured data shard groups this process
// currently leads. Background maintenance uses this to avoid issuing
// whole-keyspace scans from every node and proxying those scans back to the
// same hot leaders. The coordinator owns the groups, so the answer is always
// known; an empty list means this process leads none of them.
func (c *ShardedCoordinator) LocalLeaderGroupIDs() ([]uint64, bool) {
	ids := c.timestampBridgeCandidateGroupIDs()
	out := make([]uint64, 0, len(ids))
	for _, gid := range ids {
		g, ok := c.groups[gid]
		if ok && isLeaderEngine(engineForGroup(g)) {
			out = append(out, gid)
		}
	}
	return out, true
}

func (c *ShardedCoordinator) invalidateTimestampWindow() {
	if c == nil {
		return
	}
	invalidateTimestampWindow(c.tsAllocator)
}

func (c *ShardedCoordinator) VerifyLeader(ctx context.Context) error {
	g, ok := c.groups[c.defaultGroup]
	if !ok {
		return errors.WithStack(ErrLeaderNotFound)
	}
	return verifyLeaderEngineCtx(ctx, engineForGroup(g))
}

func (c *ShardedCoordinator) RaftLeader() string {
	g, ok := c.groups[c.defaultGroup]
	if !ok {
		return ""
	}
	return leaderAddrFromEngine(engineForGroup(g))
}

func (c *ShardedCoordinator) LinearizableRead(ctx context.Context) (uint64, error) {
	g, ok := c.groups[c.defaultGroup]
	if !ok {
		return 0, errors.WithStack(ErrLeaderNotFound)
	}
	return linearizableReadEngineCtx(ctx, engineForGroup(g))
}

func (c *ShardedCoordinator) IsLeaderForKey(key []byte) bool {
	g, ok := c.groupForKey(key)
	if !ok {
		return false
	}
	return isLeaderEngine(engineForGroup(g))
}

// LeadershipForKey reports local leadership and Raft term for key's group.
func (c *ShardedCoordinator) LeadershipForKey(key []byte) (bool, uint64) {
	g, ok := c.groupForKey(key)
	if !ok {
		return false, 0
	}
	return leadershipForEngine(engineForGroup(g))
}

// GroupLeadership reports local leadership and Raft term for groupID.
func (c *ShardedCoordinator) GroupLeadership(groupID uint64) (bool, uint64) {
	g, ok := c.groups[groupID]
	if !ok {
		return false, 0
	}
	return leadershipForEngine(engineForGroup(g))
}

func (c *ShardedCoordinator) VerifyLeaderForKey(ctx context.Context, key []byte) error {
	g, ok := c.groupForKey(key)
	if !ok {
		return errors.WithStack(ErrLeaderNotFound)
	}
	return verifyLeaderEngineCtx(ctx, engineForGroup(g))
}

// IsLeaderForGroup reports local leadership for an already-resolved group,
// skipping the key -> route -> group derivation IsLeaderForKey performs. Read
// fencing needs this: a fence target's group is known when the target is built,
// and re-deriving it from the representative key can land on a different group
// (see ReadFenceTarget).
func (c *ShardedCoordinator) IsLeaderForGroup(groupID uint64) bool {
	g, ok := c.groups[groupID]
	if !ok || g == nil {
		return false
	}
	return isLeaderEngine(engineForGroup(g))
}

// RaftLeaderForGroup returns the Raft leader address for an already-resolved
// group, the group-keyed counterpart of RaftLeaderForKey.
func (c *ShardedCoordinator) RaftLeaderForGroup(groupID uint64) string {
	g, ok := c.groups[groupID]
	if !ok || g == nil {
		return ""
	}
	return leaderAddrFromEngine(engineForGroup(g))
}

func (c *ShardedCoordinator) RaftLeaderForKey(key []byte) string {
	g, ok := c.groupForKey(key)
	if !ok {
		return ""
	}
	return leaderAddrFromEngine(engineForGroup(g))
}

func (c *ShardedCoordinator) LinearizableReadForKey(ctx context.Context, key []byte) (uint64, error) {
	routeID, g, ok := c.routeAndGroupForKey(key)
	if !ok {
		return 0, errors.WithStack(ErrLeaderNotFound)
	}
	c.observeRead(ctx, routeID, key)
	return linearizableReadEngineCtx(ctx, engineForGroup(g))
}

// ObserveReadForKey records only on the local leader of the key's group.
func (c *ShardedCoordinator) ObserveReadForKey(ctx context.Context, key []byte) {
	if c == nil {
		return
	}
	routeID, g, ok := c.routeAndGroupForKey(key)
	if ok && isLeaderEngine(engineForGroup(g)) {
		c.observeRead(ctx, routeID, key)
	}
}

func (c *ShardedCoordinator) MarkUnattributableClientRead(routeID uint64) {
	if c != nil {
		if marker, ok := c.sampler.(keyviz.UnattributableClientReadMarker); ok {
			marker.MarkUnattributableClientRead(routeID)
		}
	}
}

// LeaseRead routes through the default group's lease. See Coordinate.LeaseRead
// for semantics.
func (c *ShardedCoordinator) LeaseRead(ctx context.Context) (uint64, error) {
	g, ok := c.groups[c.defaultGroup]
	if !ok {
		return 0, errors.WithStack(ErrLeaderNotFound)
	}
	return groupLeaseRead(ctx, g, c.leaseObserver)
}

// LeaseReadForKey performs the lease check on the shard group that owns key.
// Each group maintains its own lease since each group has independent
// leadership and term.
func (c *ShardedCoordinator) LeaseReadForKey(ctx context.Context, key []byte) (uint64, error) {
	routeID, g, ok := c.routeAndGroupForKey(key)
	if !ok {
		return 0, errors.WithStack(ErrLeaderNotFound)
	}
	c.observeRead(ctx, routeID, key)
	return groupLeaseRead(ctx, g, c.leaseObserver)
}

// LeaseReadForGroup establishes the lease freshness bound on an already-resolved
// group. Read fencing knows the group when it builds a ReadFenceTarget, and
// re-deriving it from the representative key can select a different group, so the
// fence path uses this instead of LeaseReadForKey.
func (c *ShardedCoordinator) LeaseReadForGroup(ctx context.Context, groupID uint64) (uint64, error) {
	g, ok := c.groups[groupID]
	if !ok || g == nil {
		return 0, errors.WithStack(ErrLeaderNotFound)
	}
	return groupLeaseRead(ctx, g, c.leaseObserver)
}

// LeaseReadAllGroups establishes the lease freshness bound on every configured
// all-shard data group. Multi-shard reads (Scan, GSI/whole-table Query) visit
// all intersecting data routes across all groups (see ShardStore.ScanAt), so
// fencing only the default group would let those reads sample a snapshot on a
// non-default group without the freshness bound. It fails closed on the first
// group that cannot confirm its lease, since a partially-fenced read is exactly
// the stale read this guards against. Group iteration order is deterministic
// but correctness does not depend on it because every configured group must
// succeed.
func (c *ShardedCoordinator) LeaseReadAllGroups(ctx context.Context) error {
	_, err := c.LeaseReadAllGroupsTimestamp(ctx)
	return err
}

// LeaseReadAllGroupsTimestamp fences every data-group leader and returns the
// maximum commit timestamp observed after those barriers.
func (c *ShardedCoordinator) LeaseReadAllGroupsTimestamp(ctx context.Context) (uint64, error) {
	groups, err := c.allShardGroups()
	if err != nil {
		return 0, err
	}
	var maxCommitTS uint64
	for _, g := range groups {
		result, err := groupLeaseReadResult(ctx, g, c.leaseObserver)
		if err != nil {
			return 0, errors.WithStack(err)
		}
		if result.lastCommitTS > maxCommitTS {
			maxCommitTS = result.lastCommitTS
		}
	}
	return maxCommitTS, nil
}

func (c *ShardedCoordinator) allShardGroups() ([]*ShardGroup, error) {
	if c == nil || len(c.groups) == 0 {
		return nil, errors.WithStack(ErrLeaderNotFound)
	}
	if c.allShardGroupsConfigured {
		return c.configuredAllShardGroups()
	}
	return c.ownedAllShardGroups()
}

func (c *ShardedCoordinator) configuredAllShardGroups() ([]*ShardGroup, error) {
	if len(c.allShardGroupIDs) == 0 {
		return nil, errors.WithStack(ErrLeaderNotFound)
	}
	out := make([]*ShardGroup, 0, len(c.allShardGroupIDs))
	for _, gid := range c.allShardGroupIDs {
		g, ok := c.groups[gid]
		if !ok || g == nil {
			return nil, errors.WithStack(ErrLeaderNotFound)
		}
		out = append(out, g)
	}
	return out, nil
}

func (c *ShardedCoordinator) ownedAllShardGroups() ([]*ShardGroup, error) {
	gids := slices.Sorted(maps.Keys(c.groups))
	out := make([]*ShardGroup, 0, len(gids))
	for _, gid := range gids {
		g := c.groups[gid]
		if g == nil {
			return nil, errors.WithStack(ErrLeaderNotFound)
		}
		out = append(out, g)
	}
	return out, nil
}

// observeLeaseRead forwards a hit / miss signal to observer when it
// is non-nil. Kept as a package-level helper so both ShardedCoordinator
// and any future sharded caller share one nil-safe entrypoint.
func observeLeaseRead(observer LeaseReadObserver, hit bool) {
	if observer != nil {
		observer.ObserveLeaseRead(hit)
	}
}

func shouldForwardGroupLeaseRead(g *ShardGroup, engine raftengine.Engine) bool {
	return g != nil && g.leaderRead != nil && engine != nil && engine.State() != raftengine.StateLeader
}

type leaseReadResult struct {
	appliedIndex uint64
	lastCommitTS uint64
}

func localLeaseReadResult(g *ShardGroup, appliedIndex uint64) leaseReadResult {
	result := leaseReadResult{appliedIndex: appliedIndex}
	if g != nil && g.Store != nil {
		result.lastCommitTS = g.Store.LastCommitTS()
	}
	return result
}

func handleGroupLeaseReadError(ctx context.Context, g *ShardGroup, err error) (leaseReadResult, error) {
	if g != nil && isLeadershipLossError(err) {
		g.lease.invalidate()
	}
	if g != nil && g.leaderRead != nil && isTransientLeaderError(err) {
		return g.leaderRead(ctx)
	}
	return leaseReadResult{}, err
}

func groupLeaseRead(ctx context.Context, g *ShardGroup, observer LeaseReadObserver) (uint64, error) {
	result, err := groupLeaseReadResult(ctx, g, observer)
	return result.appliedIndex, err
}

func groupLeaseReadResult(ctx context.Context, g *ShardGroup, observer LeaseReadObserver) (leaseReadResult, error) {
	engine := engineForGroup(g)
	if shouldForwardGroupLeaseRead(g, engine) {
		observeLeaseRead(observer, false)
		return g.leaderRead(ctx)
	}
	// g.lp caches the LeaseProvider assertion done once at construction
	// (NewShardedCoordinator); a nil group or an engine without the
	// capability falls through to the linearizable slow path. The nil-g
	// guard preserves engineForGroup's nil-safety since g.lp would panic
	// on a nil receiver.
	if g == nil || g.lp == nil {
		idx, err := linearizableReadEngineCtx(ctx, engine)
		return localLeaseReadResult(g, idx), err
	}
	lp := g.lp
	leaseDur := lp.LeaseDuration()
	if leaseDur <= 0 {
		idx, err := linearizableReadEngineCtx(ctx, engine)
		return localLeaseReadResult(g, idx), err
	}
	// Single monoclock.Now() sample so primary/secondary/extension
	// all see the same monotonic-raw instant. Clock-skew safety
	// delegated to engineLeaseAckValid (see Coordinate.LeaseRead).
	now := monoclock.Now()
	state := engine.State()
	if engineLeaseAckValid(state, lp.LastQuorumAck(), now, leaseDur) {
		observeLeaseRead(observer, true)
		return localLeaseReadResult(g, lp.AppliedIndex()), nil
	}
	expectedGen := g.lease.generation()
	if g.lease.valid(now) && state == raftengine.StateLeader {
		observeLeaseRead(observer, true)
		return localLeaseReadResult(g, lp.AppliedIndex()), nil
	}
	observeLeaseRead(observer, false)
	idx, err := linearizableReadEngineCtx(ctx, engine)
	if err != nil {
		return handleGroupLeaseReadError(ctx, g, err)
	}
	g.lease.extend(now.Add(leaseDur), expectedGen)
	return localLeaseReadResult(g, idx), nil
}

func (c *ShardedCoordinator) Clock() *HLC {
	return c.clock
}

// RaftMembers returns every configured Raft endpoint across all local groups.
// Endpoints, rather than node IDs, are deduplicated because one process can
// expose a distinct listener per group. The stable sort keeps capability-cache
// fingerprints deterministic despite map iteration order.
func (c *ShardedCoordinator) RaftMembers(ctx context.Context) ([]RaftMember, error) {
	if c == nil || len(c.groups) == 0 {
		return nil, errors.WithStack(ErrLeaderNotFound)
	}
	membersByEndpoint := make(map[string]RaftMember)
	for _, group := range c.groups {
		members, err := raftMembersForGroup(ctx, group)
		if err != nil {
			return nil, err
		}
		for _, member := range members {
			endpoint := member.NodeID + "\x00" + member.Address
			membersByEndpoint[endpoint] = member
		}
	}
	endpoints := make([]string, 0, len(membersByEndpoint))
	for endpoint := range membersByEndpoint {
		endpoints = append(endpoints, endpoint)
	}
	slices.Sort(endpoints)
	members := make([]RaftMember, 0, len(endpoints))
	for _, endpoint := range endpoints {
		members = append(members, membersByEndpoint[endpoint])
	}
	return members, nil
}

// RaftMembersForKey returns a stable value copy of the current configuration
// for the key's owning group. It is intentionally membership-only: callers do
// not gain access to the mutable ShardGroup or its local store.
func (c *ShardedCoordinator) RaftMembersForKey(ctx context.Context, key []byte) ([]RaftMember, error) {
	g, ok := c.groupForKey(key)
	if !ok {
		return nil, errors.WithStack(ErrLeaderNotFound)
	}
	return raftMembersForGroup(ctx, g)
}

func raftMembersForGroup(ctx context.Context, group *ShardGroup) ([]RaftMember, error) {
	if group == nil || group.Engine == nil {
		return nil, errors.WithStack(ErrLeaderNotFound)
	}
	cfg, err := group.Engine.Configuration(ctx)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	members := make([]RaftMember, 0, len(cfg.Servers))
	for _, server := range cfg.Servers {
		members = append(members, RaftMember{
			NodeID:   server.ID,
			Address:  server.Address,
			Suffrage: server.Suffrage,
		})
	}
	return members, nil
}

func (c *ShardedCoordinator) groupForKey(key []byte) (*ShardGroup, bool) {
	gid, ok := c.router.ResolveGroup(key)
	if !ok {
		return nil, false
	}
	g, ok := c.groups[gid]
	return g, ok
}

// routeAndGroupForKey is groupForKey + the resolved RouteID. Read
// entry points that observe into keyviz call this so the GetRoute
// lookup runs once instead of twice (Gemini round-1 nit on PR #661).
// Leadership-only callers (IsLeaderForKey / VerifyLeaderForKey /
// RaftLeaderForKey) keep using groupForKey because they don't need
// the route ID.
//
// The gid comes from the partition-aware router (resolver-first,
// engine-fallback) so partitioned-FIFO traffic lands on the
// operator-chosen group. RouteID is read from the engine on the
// normalized key; the resolver does not have a notion of catalog
// RouteID, so partition-resolved keys observe under the engine's
// catalog RouteID for !sqs|route|global. Partition-aware keyviz
// is a Phase 3.D follow-up.
func (c *ShardedCoordinator) routeAndGroupForKey(key []byte) (uint64, *ShardGroup, bool) {
	gid, routeID, ok := c.resolveGroupAndRouteForKey(key)
	if !ok {
		return 0, nil, false
	}
	g, ok := c.groups[gid]
	if !ok {
		return 0, nil, false
	}
	return routeID, g, true
}

func (c *ShardedCoordinator) engineGroupIDForKey(key []byte) uint64 {
	gid, _, ok := c.resolveGroupAndRouteForKey(key)
	if !ok {
		return 0
	}
	return gid
}

func (c *ShardedCoordinator) resolveGroupAndRouteForKey(key []byte) (uint64, uint64, bool) {
	if route, ok := c.s3BucketAuxiliaryOwnerRouteForKey(key); ok {
		return route.GroupID, route.RouteID, true
	}
	gid, ok := c.router.ResolveGroup(key)
	if !ok {
		return 0, 0, false
	}
	var routeID uint64
	if route, found := c.engine.GetRoute(routeKey(key)); found {
		routeID = route.RouteID
	}
	return gid, routeID, true
}

func (c *ShardedCoordinator) s3BucketAuxiliaryOwnerRouteForKey(key []byte) (distribution.Route, bool) {
	if c == nil || c.engine == nil {
		return distribution.Route{}, false
	}
	start, end, ok := s3BucketAuxiliaryRouteRange(key)
	if !ok {
		return distribution.Route{}, false
	}
	return s3BucketAuxiliaryOwnerRouteFromRange(start, end, c.engine.GetIntersectingRoutes(start, end))
}

// EngineGroupIDForKey reports the Raft group ID that owns key, or 0 when
// the key cannot be routed. Callers that batch lease checks across many
// keys use it to collapse keys sharing a group into a single lease read
// (see GroupRoutableCoordinator). It performs no I/O — only an in-memory
// router lookup — so it is safe on the read hot path.
func (c *ShardedCoordinator) EngineGroupIDForKey(key []byte) uint64 {
	return c.engineGroupIDForKey(key)
}

// ResolveOperationGroupForKey uses the same routing decision as groupMutations
// when placing a durable receipt alongside an operation effect.
func (c *ShardedCoordinator) ResolveOperationGroupForKey(key []byte) (uint64, error) {
	groupID, _, ok := c.resolveGroupAndRouteForKey(key)
	if !ok {
		return 0, errors.WithStack(ErrInvalidRequest)
	}
	return groupID, nil
}

// groupReadKeysByShardID groups txn read keys by their owning Raft
// group. Returns an error when ANY read key cannot be routed —
// silently skipping unresolvable keys would let a transaction
// commit with an incomplete OCC read-set, which breaks SSI under
// the §5 ShardRouter resolver-first dispatch (codex round-2 P1 on
// PR #715).
//
// The fail-closed semantic the resolver gained in PR 4-B-2 makes
// this path matter: a partitioned-shape read key whose queue is
// missing from --sqsFifoPartitionMap (drift / partial rollout)
// returns gid=0 from c.router.ResolveGroup. If we silently dropped
// those keys, the prewrite Raft entry would carry an empty
// ReadKeys slice for that key, the FSM's read-write conflict
// validation would never see it, and a concurrent write could
// commit alongside a stale read. Surface the routing failure as
// an error so the transaction aborts before any FSM apply.
func (c *ShardedCoordinator) groupReadKeysByShardID(readKeys [][]byte) (map[uint64][][]byte, error) {
	if len(readKeys) == 0 {
		return nil, nil
	}
	grouped := make(map[uint64][][]byte)
	for _, key := range readKeys {
		gid, _, ok := c.resolveGroupAndRouteForKey(key)
		if !ok || gid == 0 {
			return nil, errors.Wrapf(ErrInvalidRequest,
				"no route for txn read key %q — recognised-but-"+
					"unresolved partition keys must fail closed to "+
					"preserve OCC read-set integrity", key)
		}
		grouped[gid] = append(grouped[gid], key)
		if alias, ok := c.stagedVisibilityReadKeyAlias(gid, key); ok {
			grouped[gid] = append(grouped[gid], alias)
		}
	}
	return grouped, nil
}

func (c *ShardedCoordinator) groupedReadKeysWithStagedVisibilityMutationAliases(groupedReadKeys map[uint64][][]byte, groupedMutations map[uint64][]*pb.Mutation) map[uint64][][]byte {
	out := groupedReadKeys
	for gid, muts := range groupedMutations {
		for _, mut := range muts {
			if mut == nil {
				continue
			}
			alias, ok := c.stagedVisibilityReadKeyAlias(gid, mut.Key)
			if !ok {
				continue
			}
			if out == nil {
				out = make(map[uint64][][]byte)
			}
			out[gid] = append(out[gid], alias)
		}
	}
	return out
}

func groupedReadKeyCount(grouped map[uint64][][]byte) int {
	var count int
	for _, keys := range grouped {
		count += len(keys)
	}
	return count
}

func (c *ShardedCoordinator) stagedVisibilityReadKeyAlias(gid uint64, key []byte) ([]byte, bool) {
	if c == nil || c.engine == nil || len(key) == 0 {
		return nil, false
	}
	if _, _, ok := distribution.MigrationStagedDataKeyParts(key); ok {
		return nil, false
	}
	if route, ok := c.s3BucketAuxiliaryOwnerRouteForKey(key); ok {
		return stagedVisibilityReadKeyAliasForRoute(gid, key, route)
	}
	route, ok := c.engine.GetRoute(routeKey(key))
	if !ok {
		return nil, false
	}
	return stagedVisibilityReadKeyAliasForRoute(gid, key, route)
}

func stagedVisibilityReadKeyAliasForRoute(gid uint64, key []byte, route distribution.Route) ([]byte, bool) {
	if route.GroupID != gid || !routeHasStagedVisibility(route) {
		return nil, false
	}
	return distribution.MigrationStagedDataKey(route.MigrationJobID, key), true
}

// validateReadOnlyShards checks read-write conflicts on shards that have
// read keys but no mutations in this transaction. writeGIDs is the set of
// shards that already received a PREPARE with their readKeys attached.
//
// Because these shards have no mutations, we cannot send a PREPARE request
// (the FSM rejects empty mutation lists). Instead we issue a linearizable
// read barrier on each read-only shard's Raft group (ensuring the local
// FSM has applied all committed log entries) and then check LatestCommitTS
// against the local store.
//
// NOTE: This check is performed outside the FSM's applyMu lock, so there
// is a small TOCTOU window between the linearizable read barrier and the
// LatestCommitTS check. A concurrent write that commits in this window may
// go undetected. Full SSI for read-only shards in multi-shard transactions
// would require a dedicated "read-validate" FSM request phase. For
// single-shard transactions and write-shard read keys, validation is fully
// atomic under applyMu.
func (c *ShardedCoordinator) validateReadOnlyShards(ctx context.Context, groupedReadKeys map[uint64][][]byte, writeGIDs []uint64, startTS uint64) error {
	if len(groupedReadKeys) == 0 {
		return nil
	}
	writeSet := make(map[uint64]struct{}, len(writeGIDs))
	for _, gid := range writeGIDs {
		writeSet[gid] = struct{}{}
	}
	for gid, keys := range groupedReadKeys {
		if _, isWrite := writeSet[gid]; isWrite {
			continue
		}
		if err := c.validateReadKeysOnShard(ctx, gid, keys, startTS); err != nil {
			return err
		}
	}
	return nil
}

func (c *ShardedCoordinator) validateReadKeysOnShard(ctx context.Context, gid uint64, keys [][]byte, startTS uint64) error {
	g, ok := c.groups[gid]
	if !ok {
		return nil
	}
	// Linearizable read barrier: wait until the shard's FSM has applied
	// all Raft-committed entries so LatestCommitTS reflects the latest
	// committed state. Without this, a concurrent write that is committed
	// in Raft but not yet applied locally would be invisible.
	if _, err := linearizableReadEngineCtx(ctx, engineForGroup(g)); err != nil {
		return errors.WithStack(err)
	}
	for _, key := range keys {
		if err := c.verifyTargetReadinessForReadKeyOnShard(ctx, gid, g, key); err != nil {
			return err
		}
		ts, exists, err := c.latestCommitTSForReadKeyOnShard(ctx, gid, g, key)
		if err != nil {
			return errors.WithStack(err)
		}
		if exists && ts > startTS {
			return errors.WithStack(store.NewWriteConflictError(key))
		}
	}
	return nil
}

func (c *ShardedCoordinator) verifyTargetReadinessForReadKeyOnShard(ctx context.Context, gid uint64, g *ShardGroup, key []byte) error {
	view, err := readMigrationServingState(ctx, g.Store)
	if err != nil {
		return err
	}
	routeStart, routeEnd := readinessRouteRange(key, nextScanCursor(key))
	serving := &ShardStore{engine: c.engine, groups: c.groups}
	if err := serving.verifyMigrationServingFloor(ctx, 0); err != nil {
		return err
	}
	if err := serving.verifyMigrationServingRange(view, distribution.Route{GroupID: gid}, routeStart, routeEnd); err != nil {
		return err
	}
	states := view.Readiness
	if len(states) == 0 {
		return nil
	}
	if sourceReadFenceApplies(states, routeStart, routeEnd) {
		return errors.WithStack(ErrRouteCutoverPending)
	}
	routes, catalogVersion, proof := c.currentShardRoutesForRouteRange(gid, routeStart, routeEnd)
	if targetReadinessStatesSatisfied(states, routes, routeStart, routeEnd, gid, catalogVersion, proof) {
		return nil
	}
	return errors.WithStack(ErrRouteCutoverPending)
}

func (c *ShardedCoordinator) currentShardRoutesForRouteRange(gid uint64, routeStart []byte, routeEnd []byte) ([]distribution.Route, uint64, bool) {
	if c == nil || c.engine == nil {
		return nil, 0, false
	}
	snap, ok := c.engine.Current()
	if !ok {
		return nil, 0, false
	}
	routes := make([]distribution.Route, 0)
	for _, route := range snap.IntersectingRoutes(routeStart, routeEnd) {
		if route.GroupID == gid {
			routes = append(routes, route)
		}
	}
	return routes, snap.Version(), true
}

func (c *ShardedCoordinator) latestCommitTSForReadKeyOnShard(ctx context.Context, gid uint64, g *ShardGroup, key []byte) (uint64, bool, error) {
	route, ok := c.stagedVisibilityRouteForReadKey(gid, key)
	if !ok {
		liveTS, liveExists, err := g.Store.LatestCommitTS(ctx, key)
		return liveTS, liveExists, errors.WithStack(err)
	}
	// Staged before live, for the reason on getAtWithStagedVisibility.
	// Missing the version here is worse than a stale read: OCC would see no
	// commit above startTS and let the transaction commit on a read it should
	// have conflicted with.
	stagedTS, stagedExists, err := g.Store.LatestCommitTS(ctx, distribution.MigrationStagedDataKey(route.MigrationJobID, key))
	if err != nil {
		return 0, false, errors.WithStack(err)
	}
	liveTS, liveExists, err := g.Store.LatestCommitTS(ctx, key)
	if err != nil {
		return 0, false, errors.WithStack(err)
	}
	return maxStagedVisibilityLatestCommitTS(liveTS, liveExists, stagedTS, stagedExists), liveExists || stagedExists, nil
}

func (c *ShardedCoordinator) stagedVisibilityRouteForReadKey(gid uint64, key []byte) (distribution.Route, bool) {
	if c == nil || c.engine == nil {
		return distribution.Route{}, false
	}
	if _, _, ok := distribution.MigrationStagedDataKeyParts(key); ok {
		return distribution.Route{}, false
	}
	if route, ok := c.s3BucketAuxiliaryOwnerRouteForKey(key); ok {
		return route, route.GroupID == gid && routeHasStagedVisibility(route)
	}
	route, ok := c.engine.GetRoute(routeKey(key))
	return route, ok && route.GroupID == gid && routeHasStagedVisibility(route)
}

func maxStagedVisibilityLatestCommitTS(liveTS uint64, liveExists bool, stagedTS uint64, stagedExists bool) uint64 {
	if !liveExists {
		return stagedTS
	}
	if !stagedExists || liveTS > stagedTS {
		return liveTS
	}
	return stagedTS
}

var _ Coordinator = (*ShardedCoordinator)(nil)

func validateOperationGroup(reqs *OperationGroup[OP]) error {
	if reqs == nil || len(reqs.Elems) == 0 {
		return ErrInvalidRequest
	}
	for _, e := range reqs.Elems {
		if e == nil {
			return ErrInvalidRequest
		}
	}
	if len(reqs.PrimaryKey) != 0 {
		if !reqs.IsTxn {
			return ErrInvalidRequest
		}
		found := false
		for _, e := range reqs.Elems {
			if bytes.Equal(e.Key, reqs.PrimaryKey) {
				found = true
				break
			}
		}
		if !found {
			return ErrInvalidRequest
		}
	}
	return nil
}

func (c *ShardedCoordinator) requestLogs(ctx context.Context, reqs *OperationGroup[OP]) ([]*pb.Request, error) {
	if reqs.IsTxn {
		return c.txnLogs(ctx, reqs)
	}
	return c.rawLogs(ctx, reqs)
}

func (c *ShardedCoordinator) rawLogs(ctx context.Context, reqs *OperationGroup[OP]) ([]*pb.Request, error) {
	logs, _, err := c.rawLogsWithGroups(ctx, reqs)
	return logs, err
}

func (c *ShardedCoordinator) rawLogsWithGroups(ctx context.Context, reqs *OperationGroup[OP]) ([]*pb.Request, []uint64, error) {
	var observed uint64
	if c.engine != nil {
		observed = EncodeObservedRouteVersion(c.engine.Version())
	}
	grouped, gids, err := c.groupMutations(reqs.Elems, reqs.KeyVizLabel)
	if err != nil {
		return nil, nil, err
	}
	bypassKeysByGroup := c.writeFenceBypassKeysByGroup(reqs.Elems)

	logs := make([]*pb.Request, 0, len(gids))
	for _, gid := range gids {
		ts, err := c.rawLogTimestamp(ctx)
		if err != nil {
			return nil, nil, err
		}
		muts := grouped[gid]
		if ts != 0 {
			if err := c.ensureMutationsWriteAllowedWithBypass(muts, ts, bypassKeysByGroup[gid]); err != nil {
				return nil, nil, err
			}
		}
		request := &pb.Request{
			IsTxn:                false,
			Phase:                pb.Phase_NONE,
			Ts:                   ts,
			Mutations:            muts,
			ObservedRouteVersion: reqs.ObservedRouteVersion,
			WriteFenceBypassKeys: bypassKeysByGroup[gid],
		}
		if err := c.pinRawMigrationVersion(ctx, gid, request, observed); err != nil {
			return nil, nil, err
		}
		logs = append(logs, request)
	}
	return logs, gids, nil
}

func (c *ShardedCoordinator) rawLogTimestamp(ctx context.Context) (uint64, error) {
	if _, ok := resolveTimestampAllocator(c.tsAllocator); ok {
		return 0, nil
	}
	return c.allocateTimestamp(ctx, "allocate sharded raw log ts")
}

func (c *ShardedCoordinator) stampRawRequestTimestamps(ctx context.Context, reqs []*pb.Request) error {
	for _, r := range reqs {
		if r == nil || r.IsTxn || r.Ts != 0 {
			continue
		}
		ts, err := c.allocateTimestamp(ctx, "stamp sharded raw log ts")
		if err != nil {
			return err
		}
		r.Ts = ts
		if err := c.ensureMutationsWriteAllowedWithBypass(r.Mutations, r.Ts, r.GetWriteFenceBypassKeys()); err != nil {
			return err
		}
	}
	return nil
}

func (c *ShardedCoordinator) txnLogs(ctx context.Context, reqs *OperationGroup[OP]) ([]*pb.Request, error) {
	// NOTE: ShardedCoordinator implements distributed transactions directly in
	// Dispatch. txnLogs is retained for compatibility and single-shard helpers.
	if len(reqs.PrimaryKey) != 0 {
		// This legacy builder selects a primary independently per group.
		// Never silently discard an explicit transaction primary.
		return nil, errors.WithStack(ErrInvalidRequest)
	}
	grouped, gids, err := c.groupMutations(reqs.Elems, reqs.KeyVizLabel)
	if err != nil {
		return nil, err
	}
	if len(gids) != 1 {
		return nil, errors.WithStack(ErrInvalidRequest)
	}
	commitTS, err := c.resolveTxnCommitTS(ctx, reqs.StartTS, reqs.CommitTS)
	if err != nil {
		return nil, err
	}
	bypassKeysByGroup := c.writeFenceBypassKeysByGroup(reqs.Elems)
	if err := c.ensureGroupedMutationsWriteAllowedWithBypass(grouped, commitTS, bypassKeysByGroup); err != nil {
		return nil, err
	}
	if err := StampGroupedMutationCommitTS(grouped, commitTS); err != nil {
		return nil, err
	}
	logs, err := buildTxnLogs(reqs.StartTS, commitTS, grouped, gids, reqs.ObservedRouteVersion, bypassKeysByGroup)
	if err != nil {
		return nil, err
	}
	return c.bindTxnLogPrepareEvidence(ctx, logs, commitTS, gids)
}

// observeMutation: counted pre-commit, so a mutation that subsequently
// fails its Raft proposal is still recorded — the heatmap reflects
// offered load, not just committed writes (intentional for traffic
// visualisation). The early return keeps the disabled-keyviz hot
// path allocation-free. Reads have their own observeReadKey helper
// (LinearizableReadForKey / LeaseReadForKey).
func (c *ShardedCoordinator) observeMutation(routeID uint64, mut *pb.Mutation, label keyviz.Label) {
	if c == nil || c.sampler == nil || mut == nil {
		return
	}
	// Sample under the route key, not the raw storage key. routeID was resolved
	// with routeKey and the sampler's sub-buckets are laid out on catalog route
	// boundaries, which live in the normalized keyspace. Feeding the raw key
	// here bucketed adapter traffic against the wrong bounds -- Redis user key
	// "z" arrives as "!redis|str|z", which sorts before a route starting at
	// "m", so every write clamped into the first sub-bucket and autosplit chose
	// a boundary near the route start instead of the hot user key.
	c.sampler.Observe(routeID, routeKey(mut.Key), keyviz.OpWrite, len(mut.Value), c.keyVizObserveLabel(label))
}

// ObserveForwardedRequests records committed leader-side sampling evidence for
// writes that entered through a shard follower and were committed via
// Internal.Forward on this shard leader.
func (c *ShardedCoordinator) ObserveForwardedRequests(reqs []*pb.Request) {
	if c == nil || c.sampler == nil {
		return
	}
	for _, req := range reqs {
		if req == nil || !forwardedRequestRecordsUserWrites(req) {
			continue
		}
		for _, mut := range req.Mutations {
			if mut == nil || isTxnMetaKey(mut.Key) {
				continue
			}
			routeID, _, ok := c.routeAndGroupForKey(mut.Key)
			if !ok {
				continue
			}
			c.observeMutation(routeID, mut, keyviz.LabelLegacy)
		}
	}
}

// forwardedRequestRecordsUserWrites reports whether a forwarded request carries
// writes that should count as hot-key evidence.
//
// An ABORT cleanup still lists the user keys after the txn metadata so the FSM
// can clear their intents, but those writes were rolled back. Counting them
// would let a follower-routed transaction that aborts manufacture hot-key
// evidence, and the autosplit scheduler would split on cleanup traffic.
func forwardedRequestRecordsUserWrites(req *pb.Request) bool {
	return req.GetPhase() != pb.Phase_ABORT
}

// observeRead records a single linearizable / lease read against the
// route. The full key is passed (not just its length) so the sampler
// can bucket the read into the key's sub-range for the hot-key heatmap;
// the read's valueLen is 0 — the consistency check at this layer
// doesn't fetch data; the actual GetAt on the store happens further
// down the stack and isn't observed yet.
//
// Callers MUST pass an already-resolved routeID (via
// routeAndGroupForKey) so the GetRoute lookup runs once across the
// dispatch path — repeating it here just to compute routeID would
// double the per-read overhead when sampling is enabled
// (Gemini round-1 nit on PR #661).
//
// Adapter-direct read paths (Redis / DynamoDB / S3 hitting
// MVCCStore.GetAt without going through the coordinator) still
// bypass keyviz; sampling those is task B in the design's Phase 2
// follow-up.
func (c *ShardedCoordinator) observeRead(ctx context.Context, routeID uint64, key []byte) {
	if c.sampler == nil {
		return
	}
	// Normalized for the same reason observeMutation normalizes: routeID was
	// resolved through routeKey, and the sampler's sub-buckets are laid out on
	// catalog route boundaries, which live in the normalized keyspace. A raw
	// adapter key -- a DynamoDB item key, a Redis route wrapper -- sorts in a
	// different keyspace than those boundaries, so read-heavy traffic bucketed
	// against the wrong bounds and could pick a split boundary unrelated to the
	// hot logical key.
	c.sampler.Observe(routeID, routeKey(key), keyviz.OpRead, 0, c.keyVizObserveLabel(keyVizLabelFromContext(ctx)))
}

func (c *ShardedCoordinator) keyVizObserveLabel(label keyviz.Label) keyviz.Label {
	if !c.keyvizLabelsEnabled {
		return keyviz.LabelLegacy
	}
	return label
}

func (c *ShardedCoordinator) ensureGroupedMutationsWriteAllowedWithBypass(grouped map[uint64][]*pb.Mutation, commitTS uint64, bypassKeysByGroup map[uint64][][]byte) error {
	for gid, muts := range grouped {
		if err := c.ensureMutationsWriteAllowedWithBypass(muts, commitTS, bypassKeysByGroup[gid]); err != nil {
			return err
		}
	}
	return nil
}

// MutationWriteGate rejects raw mutations whose commit timestamp lands at or
// below the owning route's migration write floor. Follower-forwarded writes are
// stamped on the leader, outside the coordinator that owns the route table, so
// the leader-side RPC handler needs this to re-apply the same check.
type MutationWriteGate interface {
	EnsureMutationsWriteAllowed([]*pb.Mutation, uint64) error
}

var _ MutationWriteGate = (*ShardedCoordinator)(nil)

// EnsureMutationsWriteAllowed exposes the route-floor check to the leader-side
// Internal.Forward handler. It is the same predicate the local stamping path
// applies, so a forwarded write cannot reach Raft under a floor that a
// locally-stamped write would have been rejected by.
func (c *ShardedCoordinator) EnsureMutationsWriteAllowed(muts []*pb.Mutation, commitTS uint64) error {
	return c.ensureMutationsWriteAllowed(muts, commitTS)
}

func (c *ShardedCoordinator) ensureMutationsWriteAllowed(muts []*pb.Mutation, commitTS uint64) error {
	return c.ensureMutationsWriteAllowedWithBypass(muts, commitTS, nil)
}

func (c *ShardedCoordinator) ensureMutationsWriteAllowedWithBypass(muts []*pb.Mutation, commitTS uint64, bypassKeys [][]byte) error {
	if commitTS == 0 {
		return nil
	}
	bypass := writeFenceBypassKeySet(bypassKeys)
	for _, mut := range muts {
		if mut != nil {
			if _, ok := bypass[string(mut.Key)]; ok {
				continue
			}
		}
		if err := c.ensureMutationWriteAllowed(mut, commitTS); err != nil {
			return err
		}
	}
	return nil
}

func (c *ShardedCoordinator) ensureMutationWriteAllowed(mut *pb.Mutation, commitTS uint64) error {
	if c == nil || mut == nil || commitTS == 0 {
		return nil
	}
	switch mut.Op {
	case pb.Op_DEL_PREFIX:
		for _, route := range routesForPrefixWriteForEngine(c.engine, mut.Key) {
			if err := ensureRouteWriteAllowed(route, mut.Key, commitTS); err != nil {
				return err
			}
		}
		return nil
	case pb.Op_PUT, pb.Op_DEL:
		return c.rejectWriteTimestampFloorPointKey(mut.Key, commitTS)
	default:
		return errors.WithStack(ErrInvalidRequest)
	}
}

func (c *ShardedCoordinator) groupMutations(reqs []*Elem[OP], label keyviz.Label) (map[uint64][]*pb.Mutation, []uint64, error) {
	grouped := make(map[uint64][]*pb.Mutation)
	for _, req := range reqs {
		if req == nil {
			return nil, nil, ErrInvalidRequest
		}
		mut := elemToMutation(req)
		gid := req.GroupID
		_, routeID, routeOK := c.resolveGroupAndRouteForKey(mut.Key)
		if gid == 0 {
			resolvedGID, resolvedRouteID, ok := c.resolveGroupAndRouteForKey(mut.Key)
			if !ok {
				return nil, nil, errors.Wrapf(ErrInvalidRequest, "no route for key %q", mut.Key)
			}
			gid = resolvedGID
			routeID = resolvedRouteID
		} else if _, ok := c.groups[gid]; !ok {
			return nil, nil, errors.Wrapf(ErrInvalidRequest, "no shard group %d for key %q", gid, mut.Key)
		} else if !routeOK {
			return nil, nil, errors.Wrapf(ErrInvalidRequest, "no route for key %q", mut.Key)
		}
		if req.RequireGroupMatch && gid != req.ExpectedGroupID {
			return nil, nil, errors.WithStack(ErrTransactionOutcomeUnknown)
		}
		c.observeMutation(routeID, mut, label)
		grouped[gid] = append(grouped[gid], mut)
	}
	gids := make([]uint64, 0, len(grouped))
	for gid := range grouped {
		gids = append(gids, gid)
	}
	slices.Sort(gids)
	return grouped, gids, nil
}

func buildTxnLogs(startTS uint64, commitTS uint64, grouped map[uint64][]*pb.Mutation, gids []uint64, observedRouteVersion uint64, writeFenceBypassKeysByGroup map[uint64][][]byte) ([]*pb.Request, error) {
	logs := make([]*pb.Request, 0, len(gids)*txnPhaseCount)
	for _, gid := range gids {
		muts := grouped[gid]
		primaryKey, keys := primaryKeyAndKeyMutations(muts)
		if len(primaryKey) == 0 {
			return nil, errors.WithStack(ErrTxnPrimaryKeyRequired)
		}
		logs = append(logs,
			&pb.Request{
				IsTxn: true,
				Phase: pb.Phase_PREPARE,
				Ts:    startTS,
				Mutations: append([]*pb.Mutation{
					{Op: pb.Op_PUT, Key: []byte(txnMetaPrefix), Value: EncodeTxnMeta(TxnMeta{PrimaryKey: primaryKey, LockTTLms: defaultTxnLockTTLms, CommitTS: 0})},
				}, muts...),
				ObservedRouteVersion: observedRouteVersion,
				WriteFenceBypassKeys: writeFenceBypassKeysByGroup[gid],
			},
			&pb.Request{
				IsTxn: true,
				Phase: pb.Phase_COMMIT,
				Ts:    startTS,
				Mutations: append([]*pb.Mutation{
					{Op: pb.Op_PUT, Key: []byte(txnMetaPrefix), Value: EncodeTxnMeta(TxnMeta{PrimaryKey: primaryKey, LockTTLms: 0, CommitTS: commitTS})},
				}, keys...),
				ObservedRouteVersion: observedRouteVersion,
				WriteFenceBypassKeys: writeFenceBypassKeysByGroup[gid],
			},
		)
	}
	return logs, nil
}

func primaryKeyAndKeyMutations(muts []*pb.Mutation) ([]byte, []*pb.Mutation) {
	seen := map[string]struct{}{}
	var primary []byte
	keys := make([]*pb.Mutation, 0, len(muts))
	for _, m := range muts {
		if m == nil || len(m.Key) == 0 {
			continue
		}
		k := string(m.Key)
		if _, ok := seen[k]; ok {
			continue
		}
		seen[k] = struct{}{}
		if primary == nil || bytes.Compare(m.Key, primary) < 0 {
			primary = m.Key
		}
		keys = append(keys, &pb.Mutation{Op: pb.Op_PUT, Key: m.Key})
	}
	return primary, keys
}

// RunHLCLeaseRenewal periodically proposes a new physical ceiling to every
// shard group's Raft cluster while this node is that group's leader. This
// mirrors the single-shard Coordinate.RunHLCLeaseRenewal behaviour while
// avoiding the multi-shard gap where a non-default group leader could issue
// timestamps without renewing the shared HLC's Raft-backed ceiling.
//
// RunHLCLeaseRenewal blocks until ctx is cancelled; call it in a goroutine.
func (c *ShardedCoordinator) RunHLCLeaseRenewal(ctx context.Context) {
	if ctx == nil {
		ctx = context.Background()
	}
	var children sync.WaitGroup
	defer children.Wait()
	if len(c.groups) == 0 {
		c.logger().WarnContext(ctx, "hlc lease renewal: no shard groups configured")
		return
	}
	// Use a Timer rather than a Ticker so the next renewal is scheduled
	// relative to launching the previous round. Each per-group proposal has
	// its own timeout and goroutine, so a slow Raft group cannot delay
	// renewal for other groups.
	timer := time.NewTimer(hlcRenewalInterval)
	defer timer.Stop()
	for {
		select {
		case <-timer.C:
			if c.hlcRenewalBlocked != nil && c.hlcRenewalBlocked() {
				timer.Reset(hlcRenewalInterval)
				continue
			}
			done := c.renewHLCLeases(ctx)
			children.Add(1)
			go func() {
				defer children.Done()
				<-done
			}()
			if activation := c.activateCommitTSFencesAsync(ctx); activation != nil {
				children.Add(1)
				go func() {
					defer children.Done()
					<-activation
				}()
			}
			timer.Reset(hlcRenewalInterval)
		case <-ctx.Done():
			return
		}
	}
}

func (c *ShardedCoordinator) ProposeHLCLease(ctx context.Context, ceilingMs int64) error {
	if ctx == nil {
		ctx = context.Background()
	}
	var firstErr error
	for _, gid := range c.timestampLeaseRenewalGroupIDs() {
		group := c.groups[gid]
		if group == nil || group.Engine == nil || group.Engine.State() != raftengine.StateLeader {
			continue
		}
		if err := c.proposeHLCLeaseForGroup(ctx, gid, group, ceilingMs); err != nil {
			if c.operationAdmission != nil {
				return errors.Wrapf(err, "hlc lease renewal group %d", gid)
			}
			if firstErr == nil {
				firstErr = errors.Wrapf(err, "hlc lease renewal group %d", gid)
			}
			continue
		}
		return nil
	}
	if firstErr != nil {
		return firstErr
	}
	return errors.WithStack(ErrLeaderNotFound)
}

func (c *ShardedCoordinator) timestampLeaseRenewalGroupIDs() []uint64 {
	if c == nil {
		return nil
	}
	if groupID, ok := c.effectiveTimestampGroup(); ok {
		return []uint64{groupID}
	}
	return c.timestampBridgeCandidateGroupIDs()
}

// renewHLCLeases starts one renewal proposal for every shard group this node
// currently leads. A group with an older renewal still in flight is skipped for
// this tick so slow Raft proposals cannot stack up behind write-heavy traffic;
// other led groups continue renewing independently. The returned channel closes
// when the launched proposals finish; the outer renewal loop joins it before
// returning so proposal owners cannot outlive the loop.
func (c *ShardedCoordinator) renewHLCLeases(ctx context.Context) <-chan struct{} {
	if ctx == nil {
		ctx = context.Background()
	}
	done := make(chan struct{})
	var wg sync.WaitGroup
	for gid, group := range c.groups {
		if !c.shouldRenewHLCGroup(gid, group) {
			continue
		}
		if !c.startHLCLeaseRenewal(gid) {
			continue
		}
		wg.Add(1)
		go func(gid uint64, group *ShardGroup) {
			defer wg.Done()
			defer c.finishHLCLeaseRenewal(gid)
			pctx, cancel := context.WithTimeout(ctx, hlcRenewalProposalTimeout)
			defer cancel()
			c.renewHLCLease(pctx, gid, group)
		}(gid, group)
	}
	go func() {
		wg.Wait()
		close(done)
	}()
	return done
}

func (c *ShardedCoordinator) shouldRenewHLCGroup(gid uint64, group *ShardGroup) bool {
	if c.tsoCutoverState != nil && c.tsoCutoverState.PhaseDActive() {
		timestampGroup, ok := c.effectiveTimestampGroup()
		// With no timestamp group to fall back on, retiring every data group
		// would leave nothing renewing any ceiling at all. Keep renewing rather
		// than expiring the whole cluster.
		if ok && gid != timestampGroup {
			return false
		}
	}
	return shardGroupAcceptingWrites(group)
}

func (c *ShardedCoordinator) startHLCLeaseRenewal(gid uint64) bool {
	c.hlcRenewalMu.Lock()
	defer c.hlcRenewalMu.Unlock()
	if c.hlcRenewalInFlight == nil {
		c.hlcRenewalInFlight = make(map[uint64]struct{})
	}
	if _, ok := c.hlcRenewalInFlight[gid]; ok {
		return false
	}
	c.hlcRenewalInFlight[gid] = struct{}{}
	return true
}

func (c *ShardedCoordinator) finishHLCLeaseRenewal(gid uint64) {
	c.hlcRenewalMu.Lock()
	defer c.hlcRenewalMu.Unlock()
	delete(c.hlcRenewalInFlight, gid)
}

// renewHLCLease proposes a fresh physical ceiling on one shard
// group and, on a successful (quorum-acked) propose, warms that group's
// read lease.
//
// The lease-extension base (start) and the invalidation generation are
// sampled BEFORE the propose so the warm-up mirrors leaseRefreshingTxn's
// success branch exactly: the window can only be SHORTER than the true
// safety window, and a leader-loss callback that fires during the
// propose advances the generation so extend refuses to resurrect a
// stale lease. The propose is the SAME quorum confirmation a client
// write goes through, so warming on its success cannot widen the
// lease-read freshness window beyond what a write on this group would.
// This is the background warm-up that flattens the read-only
// lease-expiry sawtooth for the default group on idle-write workloads;
// the lease window/duration semantics are unchanged.
//
// On a leadership-loss propose error the group lease is invalidated
// eagerly, mirroring leaseRefreshingTxn's error branch exactly: when
// Propose returns the loss before the async RegisterLeaderLossCallback
// fires, a stale-warm lease must not survive on a non-leader node for
// the callback latency window. Non-leadership errors (no quorum,
// validation) are NOT leadership signals and must not tear down a warm
// lease -- doing so would force every read onto the slow path.
func (c *ShardedCoordinator) RecoverHLCLease(ctx context.Context) error {
	if c == nil || c.clock == nil {
		return errors.WithStack(errHLCLeaseRecoveryUnavailable)
	}
	c.hlcRecoveryMu.Lock()
	defer c.hlcRecoveryMu.Unlock()
	if !hlcCeilingExhausted(c.clock) {
		return nil
	}
	if c.hlcRenewalBlocked != nil && c.hlcRenewalBlocked() {
		return errors.WithStack(errHLCLeaseRecoveryBlocked)
	}
	targets := c.hlcLeaseRecoveryTargets()
	if len(targets) == 0 {
		return errors.WithStack(errHLCLeaseRecoveryUnavailable)
	}
	rctx, cancel := hlcRecoveryContext(ctx)
	defer cancel()
	return c.recoverHLCLeaseTargets(rctx, targets, hlcRecoveryCeiling(c.clock))
}

func (c *ShardedCoordinator) recoverHLCLeaseTargets(ctx context.Context, targets []hlcLeaseRecoveryTarget, ceilingMs int64) error {
	errCh := make(chan error, len(targets))
	var wg sync.WaitGroup
	var recoveryErr error
	for _, target := range targets {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := c.proposeHLCLeaseForGroup(ctx, target.gid, target.group, ceilingMs); err != nil {
				errCh <- errors.Wrapf(err, "recover hlc lease group %d", target.gid)
			}
		}()
	}
	wg.Wait()
	close(errCh)
	for err := range errCh {
		if c.operationAdmission != nil {
			recoveryErr = errors.Join(recoveryErr, err)
		} else {
			recoveryErr = combineHLCRecoveryErrors(recoveryErr, err)
		}
	}
	if c.operationAdmission != nil && recoveryErr != nil {
		return recoveryErr
	}
	if !hlcCeilingExhausted(c.clock) {
		return nil
	}
	return hlcRecoveryFailedError(recoveryErr)
}

func combineHLCRecoveryErrors(first error, next error) error {
	if first == nil {
		return next
	}
	return errors.Wrap(secondary.CombineErrors(first, next), "combine hlc recovery errors")
}

func hlcRecoveryFailedError(recoveryErr error) error {
	expiredErr := errors.Wrap(ErrCeilingExpired, "recover hlc lease did not advance ceiling")
	if recoveryErr != nil {
		return errors.Wrap(secondary.CombineErrors(expiredErr, recoveryErr), "recover hlc lease failed")
	}
	return expiredErr
}

type hlcLeaseRecoveryTarget struct {
	gid   uint64
	group *ShardGroup
}

func (c *ShardedCoordinator) hlcLeaseRecoveryTargets() []hlcLeaseRecoveryTarget {
	if c == nil {
		return nil
	}
	if timestampGroup, ok := c.effectiveTimestampGroup(); ok {
		group := c.groups[timestampGroup]
		if !shardGroupAcceptingWrites(group) {
			return nil
		}
		return []hlcLeaseRecoveryTarget{{gid: timestampGroup, group: group}}
	}
	ids := c.timestampBridgeCandidateGroupIDs()
	targets := make([]hlcLeaseRecoveryTarget, 0, len(ids))
	for _, gid := range ids {
		group := c.groups[gid]
		if shardGroupAcceptingWrites(group) {
			targets = append(targets, hlcLeaseRecoveryTarget{gid: gid, group: group})
		}
	}
	return targets
}

func shardGroupAcceptingWrites(group *ShardGroup) bool {
	return group != nil && group.Engine != nil && isLeaderAcceptingWrites(group.Engine)
}

func (c *ShardedCoordinator) renewHLCLease(ctx context.Context, gid uint64, group *ShardGroup) {
	ceilingMs := time.Now().UnixMilli() + hlcPhysicalWindowMs
	if err := c.proposeHLCLeaseForGroup(ctx, gid, group, ceilingMs); err != nil {
		c.logger().WarnContext(ctx, "hlc lease renewal failed",
			slog.Uint64("group_id", gid),
			slog.Int64("ceiling_ms", ceilingMs),
			slog.Any("err", err),
		)
	}
}

func (c *ShardedCoordinator) proposeHLCLeaseForGroup(ctx context.Context, gid uint64, group *ShardGroup, ceilingMs int64) error {
	start := monoclock.Now()
	expectedGen := group.lease.generation()
	// Route through the ShardGroup's wrap-aware proposer chain — NOT a
	// direct group.Engine.Propose — so the Stage 6E-2c dynamic wrap
	// applies. Without this, an HLC lease-renewal entry committed
	// post-cutover at `index > raftEnvelopeCutoverIndex` would land
	// cleartext and trip the §6.3 strict-> unwrap on every replica's
	// apply loop (codex P2 round-1).
	if _, err := admittedOperation(ctx, c.operationAdmission, gid, AdmissionHLC, func(owned context.Context) (*raftengine.ProposalResult, error) {
		return group.Proposer().Propose(owned, marshalHLCLeaseRenew(ceilingMs))
	}); err != nil {
		if isLeadershipLossError(err) {
			group.lease.invalidate()
		}
		return errors.WithStack(err)
	}
	if lp, ok := group.Engine.(raftengine.LeaseProvider); ok {
		group.lease.extend(start.Add(lp.LeaseDuration()), expectedGen)
	}
	return nil
}

func keyMutations(muts []*pb.Mutation) []*pb.Mutation {
	out := make([]*pb.Mutation, 0, len(muts))
	seen := map[string]struct{}{}
	for _, m := range muts {
		if m == nil || len(m.Key) == 0 {
			continue
		}
		k := string(m.Key)
		if _, ok := seen[k]; ok {
			continue
		}
		seen[k] = struct{}{}
		out = append(out, &pb.Mutation{Op: pb.Op_PUT, Key: m.Key})
	}
	return out
}
