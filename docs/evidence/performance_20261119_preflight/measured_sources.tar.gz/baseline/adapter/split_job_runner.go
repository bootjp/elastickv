package adapter

import (
	"bytes"
	"context"
	"encoding/binary"
	"io"
	"math"
	"sort"
	"time"

	"github.com/bootjp/elastickv/distribution"
	"github.com/bootjp/elastickv/kv"
	pb "github.com/bootjp/elastickv/proto"
	"github.com/bootjp/elastickv/store"
	"github.com/cockroachdb/errors"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
)

const (
	defaultSplitMigrationChunkBytes        = 1 << 20
	defaultSplitMigrationMaxScannedBytes   = 4 << 20
	defaultSplitMigrationLockProbeLimit    = 1024
	defaultSplitMigrationReadFenceGrace    = 30 * time.Second
	defaultSplitMigrationVoterProbeTimeout = 500 * time.Millisecond
	defaultSplitMigrationAttemptTimeout    = 2 * time.Second
	splitCleanupCursorVersion              = byte(1)
	splitVoterAckCursorVersion             = byte(1)
	splitVoterAckConfigurationVersion      = byte(2)
	splitCleanupCursorHeaderBytes          = 5
	splitJobHistoryLimit                   = 1000
	splitJobHistoryDeleteBatchLimit        = 1000
	splitJobHistoryTTL                     = 7 * 24 * time.Hour
	splitJobHistoryGCInterval              = time.Minute
)

var (
	splitCleanupDoneCursor                  = []byte{splitCleanupCursorVersion, 0xff, 0xff, 0xff, 0xff}
	splitSourceCleanupDoneCursor            = []byte{2, 0xff, 0xff, 0xff, 0xff}
	errSplitMigrationVoterBarrierIncomplete = errors.New("split migration voter barrier incomplete")
)

type splitVoterAck struct {
	id                 string
	address            string
	acked              bool
	configurationIndex uint64
}

func splitMigrationVoterBarrierIncompleteError(jobID uint64, kind pb.MigrationStateProbeKind) error {
	return errors.Wrapf(errSplitMigrationVoterBarrierIncomplete, "job_id=%d kind=%s", jobID, kind.String())
}

func (s *DistributionServer) syncSplitMigrationVoterBarrier(
	ctx context.Context,
	groupID uint64,
	existing []byte,
	fallback SplitMigrationClient,
	req *pb.ProbeMigrationStateRequest,
) ([]byte, bool, error) {
	voters, err := s.splitMigrationVoters(ctx, groupID, fallback)
	if err != nil {
		return nil, false, err
	}
	if _, err := decodeSplitVoterAckCursor(existing); err != nil {
		return nil, false, err
	}
	acks := make([]splitVoterAck, 0, len(voters))
	complete := true
	for _, voter := range voters {
		ack := probeSplitMigrationVoter(ctx, voter, req)
		complete = complete && ack.acked
		acks = append(acks, ack)
	}
	if req.GetRequireConfigurationIndex() && splitCleanupAckConfiguration(acks) == 0 {
		complete = false
	}
	return encodeSplitVoterAckCursor(acks), complete, nil
}

func probeSplitMigrationVoter(ctx context.Context, voter SplitMigrationVoter, req *pb.ProbeMigrationStateRequest) splitVoterAck {
	attempt, cancel := context.WithTimeout(ctx, defaultSplitMigrationVoterProbeTimeout)
	defer cancel()
	resp, err := voter.Client.ProbeMigrationState(attempt, req)
	index := resp.GetAppliedConfigurationIndex()
	acked := err == nil && resp.GetReady()
	if req.GetRequireConfigurationIndex() && (index == 0 ||
		(req.GetExpectedConfigurationIndex() != 0 && index != req.GetExpectedConfigurationIndex())) {
		acked = false
	}
	return splitVoterAck{id: voter.ID, address: voter.Address, acked: acked, configurationIndex: index}
}

func (s *DistributionServer) splitMigrationVoters(ctx context.Context, groupID uint64, fallback SplitMigrationClient) ([]SplitMigrationVoter, error) {
	if s.splitMigrationVoterFactory == nil {
		if fallback == nil {
			return nil, errors.New("split migration voter factory is not configured")
		}
		return []SplitMigrationVoter{{ID: "leader", Address: "leader", Client: fallback}}, nil
	}
	voters, err := s.splitMigrationVoterFactory(ctx, groupID)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if len(voters) == 0 {
		return nil, errors.New("split migration voter set is empty")
	}
	if err := validateSplitMigrationVoters(voters); err != nil {
		return nil, err
	}
	return voters, nil
}

func validateSplitMigrationVoters(voters []SplitMigrationVoter) error {
	sort.Slice(voters, func(i, j int) bool {
		if voters[i].ID == voters[j].ID {
			return voters[i].Address < voters[j].Address
		}
		return voters[i].ID < voters[j].ID
	})
	for index, voter := range voters {
		if voter.ID == "" || voter.Address == "" || voter.Client == nil {
			return errors.New("split migration voter is incomplete")
		}
		if index > 0 && voter.ID == voters[index-1].ID {
			return errors.New("split migration voter id is duplicated")
		}
	}
	return nil
}

func encodeSplitVoterAckCursor(acks []splitVoterAck) []byte {
	version := splitVoterAckCursorVersion
	for _, ack := range acks {
		if ack.configurationIndex != 0 {
			version = splitVoterAckConfigurationVersion
		}
	}
	out := []byte{version}
	out = binary.AppendUvarint(out, uint64(len(acks)))
	for _, ack := range acks {
		out = binary.AppendUvarint(out, uint64(len(ack.id)))
		out = append(out, ack.id...)
		out = binary.AppendUvarint(out, uint64(len(ack.address)))
		out = append(out, ack.address...)
		if ack.acked {
			out = append(out, 1)
		} else {
			out = append(out, 0)
		}
		if version == splitVoterAckConfigurationVersion {
			out = binary.AppendUvarint(out, ack.configurationIndex)
		}
	}
	return out
}

func decodeSplitVoterAckCursor(raw []byte) ([]splitVoterAck, error) {
	if len(raw) == 0 {
		return nil, nil
	}
	version := raw[0]
	if version != splitVoterAckCursorVersion && version != splitVoterAckConfigurationVersion {
		return nil, errors.New("invalid split voter ack cursor version")
	}
	raw = raw[1:]
	count, rest, err := consumeSplitCursorUvarint(raw)
	if err != nil {
		return nil, err
	}
	raw = rest
	if count > uint64(len(raw)) {
		return nil, errors.New("split voter ack cursor count exceeds payload")
	}
	acks := make([]splitVoterAck, 0, count)
	for range count {
		ack, next, err := consumeSplitVoterAck(raw, version)
		if err != nil {
			return nil, err
		}
		raw = next
		acks = append(acks, ack)
	}
	if len(raw) != 0 {
		return nil, errors.New("split voter ack cursor has trailing bytes")
	}
	return acks, nil
}

func consumeSplitVoterAck(raw []byte, version byte) (splitVoterAck, []byte, error) {
	id, next, err := consumeSplitCursorString(raw)
	if err != nil {
		return splitVoterAck{}, nil, err
	}
	address, next, err := consumeSplitCursorString(next)
	if err != nil || len(next) == 0 || next[0] > 1 {
		return splitVoterAck{}, nil, errors.New("invalid split voter ack cursor entry")
	}
	ack := splitVoterAck{id: id, address: address, acked: next[0] == 1}
	next = next[1:]
	if version == splitVoterAckConfigurationVersion {
		ack.configurationIndex, next, err = consumeSplitCursorUvarint(next)
	}
	return ack, next, err
}

func consumeSplitCursorString(raw []byte) (string, []byte, error) {
	size, rest, err := consumeSplitCursorUvarint(raw)
	if err != nil || size > uint64(len(rest)) {
		return "", nil, errors.New("invalid split voter ack cursor string")
	}
	return string(rest[:size]), rest[size:], nil
}

func consumeSplitCursorUvarint(raw []byte) (uint64, []byte, error) {
	value, size := binary.Uvarint(raw)
	if size <= 0 {
		return 0, nil, errors.New("invalid split voter ack cursor integer")
	}
	return value, raw[size:], nil
}

func (s *DistributionServer) runSplitJobPhase(ctx context.Context, job distribution.SplitJob) error {
	if err := s.verifySplitJobCleanupDispatch(ctx, job); err != nil {
		return err
	}
	if s.splitMigrationClientFactory == nil {
		return errors.New("split migration client factory is not configured")
	}
	if err := s.verifySplitJobMigrationRange(ctx, job); err != nil {
		return err
	}
	job, err := s.backfillSplitJobSourceGroup(ctx, job)
	if err != nil {
		return err
	}
	if splitJobTransferNamespaceRequired(job.Phase) && s.MigrationPartitionRuntimeConfigured(job.SourceGroupID) {
		if err := s.ensureSplitJobNamespaceAdmission(ctx, job); err != nil {
			return err
		}
	}
	if job.Phase == distribution.SplitJobPhaseBackfill || job.Phase == distribution.SplitJobPhaseDeltaCopy {
		return s.runSplitJobCopyPhase(ctx, job)
	}
	return s.runSplitJobControlPhase(ctx, job)
}

func (s *DistributionServer) verifySplitJobMigrationRange(ctx context.Context, job distribution.SplitJob) error {
	// Recovery must remain possible for jobs admitted by an older binary.
	if job.Phase == distribution.SplitJobPhaseAbandoning || job.Phase == distribution.SplitJobPhaseCleanup {
		return nil
	}
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return err
	}
	_, routeEnd, found := splitJobSourceRouteState(snapshot.Routes, job)
	if !found {
		return errors.WithStack(distribution.ErrMigrationSourceRouteChanged)
	}
	if err := distribution.ValidateSplitMigrationRouteRange(job.SplitKey, routeEnd); err != nil {
		return splitMigrationRangeStatusError(err)
	}
	return nil
}

// backfillSplitJobSourceGroup records SourceGroupID on a job that predates the
// field, using current routes or retained catalog ancestry.
//
// InitializeSplitJobPlan fills the field for every job it creates, but it runs
// only at plan time: a job persisted by an earlier binary decodes as zero and is
// never re-planned, so nothing ever populates it.
//
// That matters because the field is the last-resort handle
// splitJobSourceRouteState falls back to, and it is needed in exactly the state
// where the route shape stops answering -- once FENCE has replaced the parent
// AND the source child has been split again (which SplitRange permits, the new
// split being disjoint from the moving range), the grandchildren no longer name
// the original parent and the parent itself is gone. A legacy job that reached
// that state could never resolve its source again: CLEANUP failed with
// ErrMigrationSourceRouteChanged on every attempt and held the job, its guards
// and its retention pin indefinitely.
//
// The historical fallback also repairs jobs already in that degraded state.
// The write is a no-op once the field is set, and is skipped for phases that
// will never read it.
func (s *DistributionServer) backfillSplitJobSourceGroup(
	ctx context.Context,
	job distribution.SplitJob,
) (distribution.SplitJob, error) {
	if job.SourceGroupID != 0 || !splitJobPhaseNeedsSourceGroup(job.Phase) {
		return job, nil
	}
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return job, err
	}
	groupID, needed, err := s.resolveLegacySplitJobSourceGroup(ctx, job, snapshot.Routes)
	if err != nil {
		return job, err
	}
	if !needed {
		return job, nil
	}
	if err := s.updateSplitJobViaCoordinator(ctx, job.JobID,
		func(current distribution.SplitJob) (distribution.SplitJob, error) {
			if current.SourceGroupID != 0 {
				return current, nil
			}
			next := distribution.CloneSplitJob(current)
			next.SourceGroupID = groupID
			next.UpdatedAtMs = time.Now().UnixMilli()
			return next, nil
		}); err != nil {
		return job, err
	}
	job.SourceGroupID = groupID
	return job, nil
}

func (s *DistributionServer) resolveLegacySplitJobSourceGroup(ctx context.Context, job distribution.SplitJob, routes []distribution.RouteDescriptor) (uint64, bool, error) {
	if groupID, needed := splitJobSourceGroupBackfill(routes, job); needed {
		return groupID, true, nil
	}
	groupID, found, historyErr := s.legacySplitJobSourceGroup(ctx, job)
	if found {
		return groupID, true, nil
	}
	groupID, found, err := s.discoverSplitJobSourceGroup(ctx, job, routes)
	if err != nil {
		return 0, false, err
	}
	if found {
		return groupID, true, nil
	}
	return 0, false, historyErr
}

// A current predecessor may itself have migrated. Recover the original owner
// from catalog ancestry instead of guessing from its present-day group.
func (s *DistributionServer) legacySplitJobSourceGroup(ctx context.Context, job distribution.SplitJob) (uint64, bool, error) {
	var lastErr error
	for _, ts := range []uint64{job.SnapshotTS, job.FenceTS} {
		if ts == 0 {
			continue
		}
		snapshot, err := s.loadCatalogSnapshotAt(ctx, ts)
		if err != nil {
			lastErr = err
			continue
		}
		if groupID, needed := splitJobSourceGroupBackfill(snapshot.Routes, job); needed {
			return groupID, true, nil
		}
	}
	return 0, false, lastErr
}

func (s *DistributionServer) discoverSplitJobSourceGroup(ctx context.Context, job distribution.SplitJob, routes []distribution.RouteDescriptor) (uint64, bool, error) {
	if s.splitMigrationClientFactory == nil {
		return 0, false, nil
	}
	for _, route := range routes {
		if route.ParentRouteID == job.SourceRouteID && bytes.Equal(route.Start, job.SplitKey) {
			return s.probeSplitJobSourceGroups(ctx, job, route.End)
		}
	}
	return 0, false, nil
}

func (s *DistributionServer) probeSplitJobSourceGroups(ctx context.Context, job distribution.SplitJob, routeEnd []byte) (uint64, bool, error) {
	var owner uint64
	for groupID := range s.knownRaftGroups {
		ready, err := s.probeSplitJobSourceGroup(ctx, job, groupID, routeEnd)
		if err != nil {
			return 0, false, err
		}
		if !ready {
			continue
		}
		if owner != 0 {
			return 0, false, errors.New("multiple groups report a source guard for the migration job")
		}
		owner = groupID
	}
	return owner, owner != 0, nil
}

func (s *DistributionServer) probeSplitJobSourceGroup(ctx context.Context, job distribution.SplitJob, groupID uint64, routeEnd []byte) (bool, error) {
	attemptCtx, cancel := context.WithTimeout(ctx, defaultSplitMigrationVoterProbeTimeout)
	defer cancel()
	source, err := s.splitJobSourceClient(attemptCtx, job, groupID)
	if err != nil {
		return false, errors.WithStack(err)
	}
	if source == nil {
		return false, errors.New("split migration source discovery client is nil")
	}
	resp, err := source.ProbeMigrationState(attemptCtx, &pb.ProbeMigrationStateRequest{
		JobId: job.JobID, Kind: pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_SOURCE_GUARD_PRESENT,
		RouteStart: job.SplitKey, RouteEnd: routeEnd,
	})
	if err != nil {
		return false, errors.WithStack(err)
	}
	return resp.GetReady(), nil
}

// splitJobSourceGroupBackfill decides whether job needs its SourceGroupID
// recorded, and which group to record.
//
// Kept separate from the catalog write so the decision is testable without a
// live catalog or coordinator: every case that must NOT write -- the field
// already set, a phase that will never read it, a route shape that cannot
// answer -- is a pure-function case.
func splitJobSourceGroupBackfill(
	routes []distribution.RouteDescriptor,
	job distribution.SplitJob,
) (uint64, bool) {
	if job.SourceGroupID != 0 || !splitJobPhaseNeedsSourceGroup(job.Phase) {
		return 0, false
	}
	groupID, _, ok := splitJobSourceRouteState(routes, job)
	if !ok || groupID == 0 {
		// The shape cannot answer either. Leave the job alone and let the phase
		// surface the real error rather than masking it as a backfill failure.
		return 0, false
	}
	return groupID, true
}

// splitJobPhaseNeedsSourceGroup reports whether a job in this phase can still
// reach a source-side operation, and therefore whether it is worth recording the
// source group for it. Terminal and unplanned phases never read the field.
func splitJobPhaseNeedsSourceGroup(phase distribution.SplitJobPhase) bool {
	switch phase {
	case distribution.SplitJobPhasePlanned,
		distribution.SplitJobPhaseBackfill,
		distribution.SplitJobPhaseDeltaCopy,
		distribution.SplitJobPhaseFence,
		distribution.SplitJobPhaseCutover,
		distribution.SplitJobPhaseCleanup,
		distribution.SplitJobPhaseAbandoning:
		return true
	case distribution.SplitJobPhaseNone,
		distribution.SplitJobPhaseDone,
		distribution.SplitJobPhaseFailed,
		distribution.SplitJobPhaseAbandoned:
		return false
	}
	return false
}

func (s *DistributionServer) runSplitJobCopyPhase(ctx context.Context, job distribution.SplitJob) error {
	if job.Phase == distribution.SplitJobPhaseBackfill {
		return s.copySplitJobPhase(ctx, job, distribution.SplitJobExportPhaseBackfill, 0, job.SnapshotTS)
	}
	ready, err := s.preflightSplitJobTransfer(ctx, job)
	if err != nil || !ready {
		return err
	}
	return s.copySplitJobPhase(ctx, job, distribution.SplitJobExportPhaseDeltaCopy, job.DeltaFloor, job.FenceTS)
}

func (s *DistributionServer) runSplitJobControlPhase(ctx context.Context, job distribution.SplitJob) error {
	switch job.Phase {
	case distribution.SplitJobPhasePlanned:
		return s.beginSplitJobBackfill(ctx, job)
	case distribution.SplitJobPhaseFence:
		return s.finalizeSplitJobFence(ctx, job)
	case distribution.SplitJobPhaseCutover:
		return s.cutoverSplitJob(ctx, job)
	case distribution.SplitJobPhaseCleanup:
		return s.cleanupSplitJob(ctx, job)
	case distribution.SplitJobPhaseAbandoning:
		return s.abandonSplitJob(ctx, job)
	case distribution.SplitJobPhaseNone,
		distribution.SplitJobPhaseBackfill,
		distribution.SplitJobPhaseDeltaCopy,
		distribution.SplitJobPhaseDone,
		distribution.SplitJobPhaseFailed,
		distribution.SplitJobPhaseAbandoned:
		return nil
	}
	return errors.New("split job phase is not runnable")
}

func (s *DistributionServer) cleanupSplitJob(ctx context.Context, job distribution.SplitJob) error {
	if err := s.verifySplitJobCleanupCutover(ctx, job); err != nil {
		return err
	}
	return s.cleanupVerifiedSplitJob(ctx, job)
}

func (s *DistributionServer) cleanupVerifiedSplitJob(ctx context.Context, job distribution.SplitJob) error {
	if !job.TargetPromotionDone {
		_, target, _, err := s.splitJobMigrationClients(ctx, job)
		if err != nil {
			return err
		}
		if err := s.applySplitOwnership(ctx, job, job.TargetGroupID, target, pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_OWNERSHIP_ACQUIRE); err != nil {
			return err
		}
		return s.promoteSplitJobTargetAndComplete(ctx, job)
	}
	if !bytes.Equal(job.TargetClearedDescriptorAckCursor, splitCleanupDoneCursor) {
		if err := s.cleanupSplitJobTargetProofs(ctx, job); err != nil {
			return err
		}
		return nil
	}
	if complete, err := s.refreshSplitJobSourceCleanupBarriers(ctx, job); err != nil || !complete {
		return err
	}
	if !bytes.Equal(job.Cursor, splitSourceCleanupDoneCursor) {
		return s.cleanupSplitJobSourceData(ctx, job)
	}
	if job.SourceRetentionPinTS != math.MaxUint64 {
		return s.cleanupSplitJobSourceProofs(ctx, job)
	}
	return s.finishSplitJobHistory(ctx, job, distribution.SplitJobPhaseDone)
}

func (s *DistributionServer) verifySplitJobCleanupCutover(ctx context.Context, job distribution.SplitJob) error {
	snapshot, err := s.loadCommittedMigrationCatalog(ctx)
	if err != nil {
		return err
	}
	return verifySplitJobCleanupSnapshot(job, snapshot)
}

// Validate before capability recovery or source discovery can dispatch RPCs.
func (s *DistributionServer) verifySplitJobCleanupDispatch(ctx context.Context, job distribution.SplitJob) error {
	if job.Phase != distribution.SplitJobPhaseCleanup {
		return nil
	}
	snapshot, err := s.loadCommittedMigrationCatalog(ctx)
	if err != nil {
		return err
	}
	current, found, err := s.catalog.SplitJobAt(ctx, job.JobID, snapshot.ReadTS)
	if err != nil {
		return splitJobCatalogStatusError(err)
	}
	if !found || !distribution.SplitJobsEquivalent(current, job) {
		return errors.WithStack(distribution.ErrCatalogSplitJobConflict)
	}
	return verifySplitJobCleanupSnapshot(current, snapshot)
}

func verifySplitJobCleanupSnapshot(job distribution.SplitJob, snapshot distribution.CatalogSnapshot) error {
	if !validSplitJobCleanupWitness(job, snapshot.Version) {
		return errors.New("split cleanup lacks a valid cutover witness")
	}
	if _, found := findRouteByID(snapshot.Routes, job.SourceRouteID); found {
		return errors.New("split cleanup source route has not been cut over")
	}
	for _, route := range snapshot.Routes {
		if splitJobCleanupTargetAttests(route, job) {
			return nil
		}
	}
	return errors.New("split cleanup target descriptor does not attest the cutover")
}

func validSplitJobCleanupWitness(job distribution.SplitJob, catalogVersion uint64) bool {
	return job.CutoverVersion != 0 && job.CutoverVersion <= catalogVersion &&
		job.FenceTS != 0 && job.FenceTS != math.MaxUint64 && job.FenceTS >= job.SnapshotTS &&
		job.SourceGroupID != 0 && job.SourceGroupID != job.TargetGroupID
}

func splitJobCleanupTargetAttests(route distribution.RouteDescriptor, job distribution.SplitJob) bool {
	if !splitJobCleanupTargetIdentity(route, job) {
		return false
	}
	if job.TargetPromotionDone {
		return !route.StagedVisibilityActive && route.MigrationJobID == 0
	}
	return route.StagedVisibilityActive && route.MigrationJobID == job.JobID
}

func splitJobCleanupTargetIdentity(route distribution.RouteDescriptor, job distribution.SplitJob) bool {
	return route.ParentRouteID == job.SourceRouteID && bytes.Equal(route.Start, job.SplitKey) &&
		route.GroupID == job.TargetGroupID && route.State == distribution.RouteStateActive && route.MinWriteTSExclusive == job.FenceTS
}

func (s *DistributionServer) splitJobMigrationClients(ctx context.Context, job distribution.SplitJob) (SplitMigrationClient, SplitMigrationClient, []byte, error) {
	if s.splitMigrationClientFactory == nil {
		return nil, nil, nil, errors.New("split migration client factory is not configured")
	}
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return nil, nil, nil, err
	}
	sourceGroupID, routeEnd, ok := splitJobSourceRouteState(snapshot.Routes, job)
	if !ok {
		return nil, nil, nil, errors.WithStack(distribution.ErrMigrationSourceRouteChanged)
	}
	source, target, err := s.splitMigrationClientFactory(ctx, job, sourceGroupID)
	if err != nil {
		return nil, nil, nil, errors.WithStack(err)
	}
	if source == nil || target == nil {
		return nil, nil, nil, errors.New("split migration source or target client is nil")
	}
	return source, target, routeEnd, nil
}

func (s *DistributionServer) cleanupSplitJobTargetProofs(ctx context.Context, job distribution.SplitJob) error {
	_, target, routeEnd, err := s.splitJobMigrationClients(ctx, job)
	if err != nil {
		return err
	}
	descriptorCursor, descriptorComplete, err := s.syncSplitMigrationVoterBarrier(ctx, job.TargetGroupID, job.TargetClearedDescriptorAckCursor, target, &pb.ProbeMigrationStateRequest{
		JobId:                  job.JobID,
		Kind:                   pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_TARGET_DESCRIPTOR_CLEARED,
		RouteStart:             job.SplitKey,
		RouteEnd:               routeEnd,
		ExpectedCatalogVersion: job.CutoverVersion,
		ExpectedGroupId:        job.TargetGroupID,
		MinWriteTsExclusive:    job.FenceTS,
	})
	if err != nil {
		return err
	}
	if !descriptorComplete {
		return s.persistSplitJobTargetCleanupCursor(ctx, job.JobID, descriptorCursor)
	}
	if err := s.applySplitOwnership(ctx, job, job.TargetGroupID, target, pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_OWNERSHIP_CLEAR); err != nil {
		return errors.WithStack(err)
	}
	_, metadataComplete, err := s.syncSplitMigrationVoterBarrier(ctx, job.TargetGroupID, nil, target, &pb.ProbeMigrationStateRequest{
		JobId: job.JobID,
		Kind:  pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_METADATA_CLEARED,
	})
	if err != nil {
		return err
	}
	if !metadataComplete {
		return splitMigrationVoterBarrierIncompleteError(job.JobID, pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_METADATA_CLEARED)
	}
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseCleanup && current.TargetPromotionDone {
			current.TargetClearedDescriptorAckCursor = distribution.CloneBytes(splitCleanupDoneCursor)
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func (s *DistributionServer) persistSplitJobTargetCleanupCursor(ctx context.Context, jobID uint64, cursor []byte) error {
	return s.updateSplitJobViaCoordinator(ctx, jobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseCleanup {
			current.TargetClearedDescriptorAckCursor = distribution.CloneBytes(cursor)
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func (s *DistributionServer) ackSplitJobSourceRouteRemoval(ctx context.Context, job distribution.SplitJob) (bool, error) {
	source, _, routeEnd, err := s.splitJobMigrationClients(ctx, job)
	if err != nil {
		return false, err
	}
	sourceGroupID, err := s.splitJobSourceGroupID(ctx, job)
	if err != nil {
		return false, err
	}
	cursor, complete, err := s.syncSplitMigrationVoterBarrier(ctx, sourceGroupID, reusableSplitCleanupAckCursor(job.SourceCutoverAckCursor), source, &pb.ProbeMigrationStateRequest{
		JobId:                     job.JobID,
		Kind:                      pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_SOURCE_ROUTE_REMOVED,
		RouteStart:                job.SplitKey,
		RouteEnd:                  routeEnd,
		ExpectedCatalogVersion:    job.CutoverVersion,
		ExpectedGroupId:           job.TargetGroupID,
		RequireConfigurationIndex: true,
	})
	if err != nil {
		return false, err
	}
	if bytes.Equal(cursor, job.SourceCutoverAckCursor) {
		return complete, nil
	}
	err = s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseCleanup {
			current.SourceCutoverAckCursor = distribution.CloneBytes(cursor)
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
	return complete, err
}

func (s *DistributionServer) ackSplitJobSourceReadDrain(ctx context.Context, job distribution.SplitJob) (bool, error) {
	configurationIndex, err := splitCleanupCursorConfiguration(job.SourceCutoverAckCursor)
	if err != nil {
		return false, err
	}
	source, _, _, err := s.splitJobMigrationClients(ctx, job)
	if err != nil {
		return false, err
	}
	sourceGroupID, err := s.splitJobSourceGroupID(ctx, job)
	if err != nil {
		return false, err
	}
	notBefore := int64(job.PromotionCompletedTS>>kv.HLCLogicalBits) + defaultSplitMigrationReadFenceGrace.Milliseconds() //nolint:gosec // HLC physical millis fit int64.
	cursor, complete, err := s.syncSplitMigrationVoterBarrier(ctx, sourceGroupID, reusableSplitCleanupAckCursor(job.SourceReadDrainCursor), source, &pb.ProbeMigrationStateRequest{
		JobId:                      job.JobID,
		Kind:                       pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_SOURCE_READ_DRAINED,
		ReadDrainNotBeforeMs:       notBefore,
		ReadDrainMinTs:             job.PromotionCompletedTS,
		RequireConfigurationIndex:  true,
		ExpectedConfigurationIndex: configurationIndex,
	})
	if err != nil {
		return false, err
	}
	if bytes.Equal(cursor, job.SourceReadDrainCursor) {
		return complete, nil
	}
	err = s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseCleanup {
			current.SourceReadDrainCursor = distribution.CloneBytes(cursor)
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
	return complete, err
}

func reusableSplitCleanupAckCursor(cursor []byte) []byte {
	if bytes.Equal(cursor, splitCleanupDoneCursor) {
		return nil
	}
	return cursor
}

func (s *DistributionServer) refreshSplitJobSourceCleanupBarriers(ctx context.Context, job distribution.SplitJob) (bool, error) {
	complete, err := s.ackSplitJobSourceRouteRemoval(ctx, job)
	if err != nil || !complete {
		return false, err
	}
	// Route ACK publication may have replaced a legacy cursor or observed a
	// new configuration. Bind the read-drain ACK to that exact durable proof.
	job, found, err := s.catalog.SplitJob(ctx, job.JobID)
	if err != nil || !found {
		return false, errors.Wrap(errSplitMigrationVoterBarrierIncomplete, "source cleanup job proof unavailable")
	}
	return s.ackSplitJobSourceReadDrain(ctx, job)
}

func (s *DistributionServer) splitJobSourceGroupID(ctx context.Context, job distribution.SplitJob) (uint64, error) {
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return 0, err
	}
	groupID, _, ok := splitJobSourceRouteState(snapshot.Routes, job)
	if !ok {
		return 0, errors.WithStack(distribution.ErrMigrationSourceRouteChanged)
	}
	return groupID, nil
}

func (s *DistributionServer) cleanupSplitJobSourceData(ctx context.Context, job distribution.SplitJob) error {
	source, _, routeEnd, err := s.splitJobMigrationClients(ctx, job)
	if err != nil {
		return err
	}
	brackets, err := distribution.PlanCleanupBrackets(job.SplitKey, routeEnd)
	if err != nil {
		return errors.WithStack(err)
	}
	index, cursor, done, err := decodeSplitSourceCleanupCursor(job.Cursor, len(brackets))
	if err != nil || done {
		return err
	}
	bracket := brackets[index]
	req := splitMigrationCleanupRequest(job, routeEnd, bracket, cursor, job.FenceTS)
	if err := s.bindSplitSourceCleanup(ctx, job, source, routeEnd, req); err != nil {
		return err
	}
	resp, err := cleanupSplitMigration(ctx, source, req)
	if err != nil {
		return errors.WithStack(err)
	}
	encoded, err := nextSplitCleanupCursor(resp, cursor, index, len(brackets))
	if err != nil {
		return err
	}
	encoded = splitSourceCleanupCursor(encoded)
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseCleanup && bytes.Equal(current.Cursor, job.Cursor) {
			current.Cursor = encoded
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func splitSourceCleanupCursor(encoded []byte) []byte {
	if bytes.Equal(encoded, splitCleanupDoneCursor) {
		return distribution.CloneBytes(splitSourceCleanupDoneCursor)
	}
	return encoded
}

func decodeSplitSourceCleanupCursor(raw []byte, bracketCount int) (int, []byte, bool, error) {
	if bytes.Equal(raw, splitSourceCleanupDoneCursor) {
		return bracketCount, nil, true, nil
	}
	if bytes.Equal(raw, splitCleanupDoneCursor) {
		// A live job completed the old plan before seals had a cleanup bracket.
		return bracketCount - 1, nil, false, nil
	}
	return decodeSplitCleanupCursor(raw, bracketCount)
}

func nextSplitCleanupCursor(resp *pb.CleanupMigrationResponse, cursor []byte, index, bracketCount int) ([]byte, error) {
	if !resp.GetDone() {
		next := resp.GetNextCursor()
		if len(next) == 0 || bytes.Equal(next, cursor) {
			return nil, errors.New("split migration source cleanup made no cursor progress")
		}
		return encodeSplitCleanupCursor(index, next, false), nil
	}
	nextIndex := index + 1
	return encodeSplitCleanupCursor(nextIndex, nil, nextIndex >= bracketCount), nil
}

func splitMigrationCleanupRequest(job distribution.SplitJob, routeEnd []byte, bracket distribution.MigrationBracket, cursor []byte, maxCommitTS uint64) *pb.CleanupMigrationRequest {
	return &pb.CleanupMigrationRequest{
		JobId:                 job.JobID,
		Mode:                  pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_VERSIONS,
		RangeStart:            bracket.Start,
		RangeEnd:              bracket.End,
		Cursor:                cursor,
		MaxCommitTs:           maxCommitTS,
		MaxVersions:           defaultSplitPromotionMaxVersions,
		MaxBytes:              defaultSplitPromotionMaxBytes,
		MaxScannedBytes:       defaultSplitPromotionMaxScanned,
		KeyFamily:             bracket.Family,
		RouteStart:            job.SplitKey,
		RouteEnd:              routeEnd,
		ExcludeKnownInternal:  bracket.ExcludeKnownInternal,
		ExcludePrefixes:       bracket.ExcludePrefixes,
		RequiresRouteKeyCheck: bracket.RequiresRouteKeyCheck,
		RequiresDecodedS3:     bracket.RequiresDecodedS3,
	}
}

func (s *DistributionServer) cleanupSplitJobSourceProofs(ctx context.Context, job distribution.SplitJob) error {
	complete, err := s.refreshSplitJobSourceCleanupBarriers(ctx, job)
	if err != nil {
		return err
	}
	if !complete {
		return errors.WithStack(errSplitMigrationVoterBarrierIncomplete)
	}
	if err := s.cleanupSplitJobSourceMetadata(ctx, job); err != nil {
		return err
	}
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseCleanup {
			current.SourceRetentionPinTS = math.MaxUint64
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func encodeSplitCleanupCursor(index int, cursor []byte, done bool) []byte {
	if done {
		return distribution.CloneBytes(splitCleanupDoneCursor)
	}
	out := make([]byte, splitCleanupCursorHeaderBytes+len(cursor))
	out[0] = splitCleanupCursorVersion
	binary.BigEndian.PutUint32(out[1:], uint32(index)) //nolint:gosec // bracket count is bounded.
	copy(out[splitCleanupCursorHeaderBytes:], cursor)
	return out
}

func decodeSplitCleanupCursor(raw []byte, bracketCount int) (int, []byte, bool, error) {
	if len(raw) == 0 {
		return 0, nil, bracketCount == 0, nil
	}
	if bytes.Equal(raw, splitCleanupDoneCursor) {
		return bracketCount, nil, true, nil
	}
	if len(raw) < splitCleanupCursorHeaderBytes || raw[0] != splitCleanupCursorVersion {
		return 0, nil, false, errors.New("invalid split cleanup cursor")
	}
	index := int(binary.BigEndian.Uint32(raw[1:splitCleanupCursorHeaderBytes]))
	if index < 0 || index >= bracketCount {
		return 0, nil, false, errors.New("split cleanup cursor bracket is out of range")
	}
	return index, distribution.CloneBytes(raw[splitCleanupCursorHeaderBytes:]), false, nil
}

func (s *DistributionServer) abandonSplitJob(ctx context.Context, job distribution.SplitJob) error {
	// Publish the actual rollback descriptor while retaining the durable source
	// guard. Only then replace that guard with OWNER evidence. Target cleanup
	// is deliberately later and may remain unavailable indefinitely.
	if !bytes.Equal(job.SourceCutoverAckCursor, splitCleanupDoneCursor) {
		if err := s.prepareSplitOwnershipRollback(ctx, job); err != nil {
			return err
		}
		if err := s.rollbackAbandonedSplitJobFence(ctx, job); err != nil {
			return err
		}
		return s.cleanupAbandonedSplitJobSource(ctx, job)
	}
	if !bytes.Equal(job.TargetClearedDescriptorAckCursor, splitCleanupDoneCursor) {
		return s.cleanupAbandonedSplitJobTarget(ctx, job)
	}
	return s.finishSplitJobHistory(ctx, job, distribution.SplitJobPhaseAbandoned)
}

func (s *DistributionServer) cleanupAbandonedSplitJobTarget(ctx context.Context, job distribution.SplitJob) error {
	_, target, _, err := s.splitJobMigrationClients(ctx, job)
	if err != nil {
		return err
	}
	_, cursor, done, err := decodeSplitCleanupCursor(job.TargetClearedDescriptorAckCursor, 1)
	if err != nil {
		return err
	}
	if !done {
		complete, err := s.cleanupAbandonedSplitJobTargetVersions(ctx, target, job, cursor)
		if err != nil || !complete {
			return err
		}
	}
	if err := s.applySplitOwnership(ctx, job, job.TargetGroupID, target, pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_OWNERSHIP_CLEAR); err != nil {
		return errors.WithStack(err)
	}
	_, metadataComplete, err := s.syncSplitMigrationVoterBarrier(ctx, job.TargetGroupID, nil, target, &pb.ProbeMigrationStateRequest{
		JobId: job.JobID,
		Kind:  pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_METADATA_CLEARED,
	})
	if err != nil {
		return err
	}
	if !metadataComplete {
		return splitMigrationVoterBarrierIncompleteError(job.JobID, pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_METADATA_CLEARED)
	}
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseAbandoning {
			current.TargetClearedDescriptorAckCursor = distribution.CloneBytes(splitCleanupDoneCursor)
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func (s *DistributionServer) cleanupAbandonedSplitJobTargetVersions(
	ctx context.Context,
	target SplitMigrationClient,
	job distribution.SplitJob,
	cursor []byte,
) (bool, error) {
	prefix := distribution.MigrationStagedDataKeyPrefix(job.JobID)
	resp, err := cleanupSplitMigration(ctx, target, &pb.CleanupMigrationRequest{
		JobId:           job.JobID,
		Mode:            pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_VERSIONS,
		RangeStart:      prefix,
		RangeEnd:        store.PrefixScanEnd(prefix),
		Cursor:          cursor,
		MaxCommitTs:     math.MaxUint64,
		MaxVersions:     defaultSplitPromotionMaxVersions,
		MaxBytes:        defaultSplitPromotionMaxBytes,
		MaxScannedBytes: defaultSplitPromotionMaxScanned,
		KeyFamily:       distribution.MigrationFamilyUser,
	})
	if err != nil {
		return false, errors.WithStack(err)
	}
	if resp.GetDone() {
		return true, nil
	}
	if len(resp.GetNextCursor()) == 0 || bytes.Equal(resp.GetNextCursor(), cursor) {
		return false, errors.New("split migration abandon cleanup made no cursor progress")
	}
	encoded := encodeSplitCleanupCursor(0, resp.GetNextCursor(), false)
	err = s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseAbandoning && bytes.Equal(current.TargetClearedDescriptorAckCursor, job.TargetClearedDescriptorAckCursor) {
			current.TargetClearedDescriptorAckCursor = encoded
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
	return false, err
}

func (s *DistributionServer) cleanupAbandonedSplitJobSource(ctx context.Context, job distribution.SplitJob) error {
	if err := s.cleanupSplitJobSourceMetadata(ctx, job); err != nil {
		return err
	}
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseAbandoning {
			current.SourceCutoverAckCursor = distribution.CloneBytes(splitCleanupDoneCursor)
			current.SourceRetentionPinTS = math.MaxUint64
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func (s *DistributionServer) cleanupSplitJobSourceMetadata(ctx context.Context, job distribution.SplitJob) error {
	sourceGroupID, err := s.splitJobSourceGroupID(ctx, job)
	if err != nil {
		return err
	}
	source, err := s.splitJobSourceClient(ctx, job, sourceGroupID)
	if err != nil {
		return err
	}
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return err
	}
	_, routeEnd, ok := splitJobSourceRouteState(snapshot.Routes, job)
	if !ok {
		return errors.WithStack(distribution.ErrMigrationSourceRouteChanged)
	}
	req := &pb.CleanupMigrationRequest{
		JobId: job.JobID,
		Mode:  pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_METADATA,
	}
	if err := s.bindSplitSourceCleanup(ctx, job, source, routeEnd, req); err != nil {
		return err
	}
	if err := s.applySplitOwnership(ctx, job, sourceGroupID, source, pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_OWNERSHIP_CLEAR, req.GetExpectedConfigurationIndex()); err != nil {
		return errors.WithStack(err)
	}
	_, metadataComplete, err := s.syncSplitMigrationVoterBarrier(ctx, sourceGroupID, nil, source, &pb.ProbeMigrationStateRequest{
		JobId: job.JobID,
		Kind:  pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_METADATA_CLEARED,
	})
	if err != nil {
		return err
	}
	if !metadataComplete {
		return splitMigrationVoterBarrierIncompleteError(job.JobID, pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_METADATA_CLEARED)
	}
	return nil
}

func (s *DistributionServer) splitJobSourceClient(ctx context.Context, job distribution.SplitJob, groupID uint64) (SplitMigrationClient, error) {
	var client SplitMigrationClient
	var err error
	switch {
	case s.splitMigrationGroupFactory != nil:
		client, err = s.splitMigrationGroupFactory(ctx, groupID)
	case s.splitMigrationClientFactory != nil:
		// Preserve existing embedders, including source discovery candidates.
		client, _, err = s.splitMigrationClientFactory(ctx, job, groupID)
	default:
		return nil, errors.New("split migration client factory is not configured")
	}
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if client == nil {
		return nil, errors.New("split migration source client is nil")
	}
	return client, nil
}

func (s *DistributionServer) rollbackAbandonedSplitJobFence(ctx context.Context, job distribution.SplitJob) error {
	snapshot, err := s.loadCommittedMigrationCatalog(ctx)
	if err != nil {
		return err
	}
	fenced := splitOwnershipRollbackRoute(snapshot.Routes, job)
	if fenced == nil {
		return errors.WithStack(distribution.ErrMigrationSourceRouteChanged)
	}
	floor := max(initialMigrationRetentionPinTS, job.SnapshotTS, job.FenceTS)
	if fenced.State == distribution.RouteStateActive && fenced.MinWriteTSExclusive >= floor {
		return nil
	}
	if snapshot.Version == math.MaxUint64 {
		return errors.New("split migration catalog version overflow")
	}
	fenced.State = distribution.RouteStateActive
	fenced.MinWriteTSExclusive = max(fenced.MinWriteTSExclusive, floor)
	encoded, err := distribution.EncodeRouteDescriptorForCatalogWrite(*fenced, s.catalog.AllowsRouteDescriptorV2Writes())
	if err != nil {
		return errors.WithStack(err)
	}
	nextVersion := snapshot.Version + 1
	if err := s.commitAbandonedSplitJobFenceRollback(ctx, snapshot, *fenced, encoded, nextVersion); err != nil {
		return err
	}
	loaded, err := s.loadCatalogSnapshotAtLeastVersion(ctx, nextVersion)
	if err != nil {
		return err
	}
	return s.applyEngineSnapshot(loaded)
}

func abandonedSplitJobFencedRoute(routes []distribution.RouteDescriptor, job distribution.SplitJob) *distribution.RouteDescriptor {
	for i := range routes {
		route := &routes[i]
		if route.ParentRouteID == job.SourceRouteID && bytes.Equal(route.Start, job.SplitKey) && route.State == distribution.RouteStateWriteFenced {
			return route
		}
	}
	return nil
}

func (s *DistributionServer) commitAbandonedSplitJobFenceRollback(
	ctx context.Context,
	snapshot distribution.CatalogSnapshot,
	fenced distribution.RouteDescriptor,
	encoded []byte,
	nextVersion uint64,
) error {
	if _, err := s.coordinator.Dispatch(ctx, &kv.OperationGroup[kv.OP]{
		Elems: []*kv.Elem[kv.OP]{
			{Op: kv.Put, Key: distribution.CatalogRouteKey(fenced.RouteID), Value: encoded},
			{Op: kv.Put, Key: distribution.CatalogVersionKey(), Value: distribution.EncodeCatalogVersion(nextVersion)},
		},
		IsTxn:   true,
		StartTS: snapshot.ReadTS,
		ReadKeys: [][]byte{
			distribution.CatalogRouteKey(fenced.RouteID),
			distribution.CatalogVersionKey(),
		},
	}); err != nil {
		return splitJobCoordinatorStatusError(err)
	}
	return nil
}

func (s *DistributionServer) finishSplitJobHistory(ctx context.Context, job distribution.SplitJob, terminalPhase distribution.SplitJobPhase) error {
	current, readTS, err := s.catalog.LiveSplitJobForUpdate(ctx, job.JobID)
	if err != nil {
		return splitJobCatalogStatusError(err)
	}
	if current.Phase != job.Phase {
		return nil
	}
	nowMs := time.Now().UnixMilli()
	next := distribution.CloneSplitJob(current)
	next.Phase = terminalPhase
	next.RetryPhase = distribution.SplitJobPhaseNone
	next.AbandonFromPhase = distribution.SplitJobPhaseNone
	next.TerminalAtMs = nowMs
	next.UpdatedAtMs = nowMs
	encoded, err := distribution.EncodeSplitJob(next)
	if err != nil {
		return splitJobCatalogStatusError(err)
	}
	liveKey := distribution.CatalogSplitJobKey(job.JobID)
	historyKey := distribution.CatalogSplitJobHistoryKey(nowMs, job.JobID)
	if _, err := s.coordinator.Dispatch(ctx, &kv.OperationGroup[kv.OP]{
		Elems: []*kv.Elem[kv.OP]{
			{Op: kv.Put, Key: historyKey, Value: encoded},
			{Op: kv.Del, Key: liveKey},
		},
		IsTxn:    true,
		StartTS:  readTS,
		ReadKeys: [][]byte{liveKey, historyKey},
	}); err != nil {
		return splitJobCoordinatorStatusError(err)
	}
	return nil
}

func (s *DistributionServer) gcSplitJobHistory(ctx context.Context, jobs []distribution.SplitJob, now time.Time) error {
	s.mu.Lock()
	if !s.splitJobHistoryGCLast.IsZero() && now.Sub(s.splitJobHistoryGCLast) < splitJobHistoryGCInterval {
		s.mu.Unlock()
		return nil
	}
	s.mu.Unlock()

	keys := splitJobHistoryGCKeys(jobs, now)
	if len(keys) > 0 {
		snapshot, err := s.loadCatalogSnapshot(ctx)
		if err != nil {
			return err
		}
		elems := make([]*kv.Elem[kv.OP], 0, len(keys))
		for _, key := range keys {
			elems = append(elems, &kv.Elem[kv.OP]{Op: kv.Del, Key: key})
		}
		if _, err := s.coordinator.Dispatch(ctx, &kv.OperationGroup[kv.OP]{
			Elems:    elems,
			IsTxn:    true,
			StartTS:  snapshot.ReadTS,
			ReadKeys: keys,
		}); err != nil {
			return splitJobCoordinatorStatusError(err)
		}
	}
	s.mu.Lock()
	s.splitJobHistoryGCLast = now
	s.mu.Unlock()
	return nil
}

func splitJobHistoryGCKeys(jobs []distribution.SplitJob, now time.Time) [][]byte {
	history := make([]distribution.SplitJob, 0, len(jobs))
	for _, job := range jobs {
		if (job.Phase == distribution.SplitJobPhaseDone || job.Phase == distribution.SplitJobPhaseAbandoned) && job.TerminalAtMs > 0 {
			history = append(history, job)
		}
	}
	sort.Slice(history, func(i, j int) bool {
		if history[i].TerminalAtMs == history[j].TerminalAtMs {
			return history[i].JobID < history[j].JobID
		}
		return history[i].TerminalAtMs < history[j].TerminalAtMs
	})
	cutoff := now.Add(-splitJobHistoryTTL).UnixMilli()
	excess := len(history) - splitJobHistoryLimit
	keys := make([][]byte, 0, min(len(history), splitJobHistoryDeleteBatchLimit))
	for i, job := range history {
		if job.TerminalAtMs >= cutoff && i >= excess {
			continue
		}
		keys = append(keys, distribution.CatalogSplitJobHistoryKey(job.TerminalAtMs, job.JobID))
		if len(keys) == splitJobHistoryDeleteBatchLimit {
			break
		}
	}
	return keys
}

// splitJobSourceRouteState resolves the group that still holds the source side
// of the split, plus the end of the moved range. The live route shape is
// preferred so a job written before source_group_id existed still resolves;
// the job's own recorded source group is the last resort, for the case where
// neither shape survives: once the source child is split again -- which
// SplitRange permits, the new split being disjoint from the moving range --
// its grandchildren no longer name the original parent, and that parent is
// itself already gone. Without the recorded group, cleanup would fail with
// ErrMigrationSourceRouteChanged on every attempt after cutover and keep the
// job live with its guards and retention pin held.
func splitJobSourceRouteState(
	routes []distribution.RouteDescriptor,
	job distribution.SplitJob,
) (uint64, []byte, bool) {
	sourceGroupID, routeEnd, ok := splitJobSourceSibling(routes, job)
	if ok {
		return sourceGroupID, routeEnd, true
	}
	if parent, found := findRouteByID(routes, job.SourceRouteID); found {
		return parent.GroupID, distribution.CloneBytes(parent.End), true
	}
	if job.SourceGroupID != 0 {
		return job.SourceGroupID, routeEnd, true
	}
	return 0, nil, false
}

func splitJobSourceSibling(routes []distribution.RouteDescriptor, job distribution.SplitJob) (uint64, []byte, bool) {
	var sourceGroupID uint64
	var routeEnd []byte
	for _, route := range routes {
		if route.ParentRouteID != job.SourceRouteID {
			continue
		}
		if bytes.Equal(route.Start, job.SplitKey) {
			routeEnd = distribution.CloneBytes(route.End)
			continue
		}
		if bytes.Equal(route.End, job.SplitKey) {
			sourceGroupID = route.GroupID
		}
	}
	return sourceGroupID, routeEnd, sourceGroupID != 0
}

func (s *DistributionServer) beginSplitJobBackfill(ctx context.Context, job distribution.SplitJob) error {
	job, err := s.prepareSplitJobWorkingSource(ctx, job)
	if err != nil {
		return err
	}
	parent, source, err := s.loadSplitBackfillSource(ctx, job)
	if err != nil {
		return err
	}
	ackCursor, complete, err := s.armSplitJobSourceTracker(ctx, job, parent, source)
	if err != nil {
		return err
	}
	if !complete {
		return s.persistSplitJobBackfillAck(ctx, job.JobID, ackCursor)
	}
	witness, err := s.ensureSplitJobTransferPhase(ctx, job, source, ackCursor)
	if err != nil {
		return err
	}
	// PREPARE entries predating the tracker may still carry large values.
	// Let them commit without imposing a retroactive limit, then choose the
	// snapshot so backfill detects every such row before any source fence.
	pending, err := splitJobPendingLocks(ctx, source, job.SplitKey, parent.End)
	if err != nil || pending {
		return err
	}
	return s.openSplitJobBackfill(ctx, job, source, witness)
}

func (s *DistributionServer) loadSplitBackfillSource(ctx context.Context, job distribution.SplitJob) (distribution.RouteDescriptor, SplitMigrationClient, error) {
	_, parent, err := s.splitJobSourceRoute(ctx, job)
	if err != nil {
		return parent, nil, err
	}
	source, err := s.splitJobSourceClient(ctx, job, parent.GroupID)
	if err != nil {
		return parent, nil, errors.WithStack(err)
	}
	if source == nil {
		return parent, nil, errors.New("split migration source client is nil")
	}
	return parent, source, s.verifySplitOwnershipRuntimes(ctx, job, parent.GroupID, source)
}

const initialMigrationRetentionPinTS = uint64(1)

func (s *DistributionServer) armSplitJobSourceTracker(
	ctx context.Context,
	job distribution.SplitJob,
	parent distribution.RouteDescriptor,
	source SplitMigrationClient,
) ([]byte, bool, error) {
	return s.armSplitSourceOwnership(ctx, job, parent.GroupID, source)
}

func (s *DistributionServer) persistSplitJobBackfillAck(ctx context.Context, jobID uint64, ackCursor []byte) error {
	return s.updateSplitJobViaCoordinator(ctx, jobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhasePlanned {
			current.FenceAckCursor = ackCursor
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func (s *DistributionServer) openSplitJobBackfill(ctx context.Context, job distribution.SplitJob, source SplitMigrationClient, witness *splitTransferAdmissionWitness) error {
	if err := s.revalidateSplitTransferAdmission(ctx, witness); err != nil {
		return err
	}
	issued, err := issueSplitMigrationTimestamp(ctx, source)
	if err != nil {
		return errors.WithStack(err)
	}
	snapshotTS := issued.GetTimestamp()
	if snapshotTS == 0 || snapshotTS <= issued.GetLastCommitTs() {
		return errors.New("split migration source issued an invalid snapshot timestamp")
	}
	if err := s.revalidateSplitTransferAdmission(ctx, witness); err != nil {
		return err
	}
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase != distribution.SplitJobPhasePlanned {
			return current, nil
		}
		current.Phase = distribution.SplitJobPhaseBackfill
		current.SnapshotTS = snapshotTS
		current.WriteTrackerArmed = true
		current.SourceRetentionPinTS = initialMigrationRetentionPinTS
		current.FenceAckCursor = nil
		current.UpdatedAtMs = time.Now().UnixMilli()
		return current, nil
	})
}

func (s *DistributionServer) copySplitJobPhase(
	ctx context.Context,
	job distribution.SplitJob,
	exportPhase distribution.SplitJobExportPhase,
	minCommitTS uint64,
	maxCommitTS uint64,
) error {
	if maxCommitTS == 0 {
		return errors.New("split migration copy upper timestamp is zero")
	}
	sourceRoute, witness, err := s.splitCopySourceAdmission(ctx, job)
	if err != nil {
		return err
	}
	brackets, err := distribution.PlanExportBrackets(job.SplitKey, sourceRoute.End)
	if err != nil {
		return errors.WithStack(err)
	}
	progressIndex, bracket, ok := nextSplitJobBracket(job, brackets, exportPhase)
	if !ok {
		if err := s.revalidateSplitTransferAdmission(ctx, witness); err != nil {
			return err
		}
		return s.advanceCompletedCopyPhase(ctx, job, exportPhase)
	}
	source, target, err := s.splitCopyClients(ctx, job, sourceRoute.GroupID)
	if err != nil {
		return err
	}
	if err := s.revalidateSplitTransferAdmission(ctx, witness); err != nil {
		return err
	}
	progress := job.BracketProgress[progressIndex]
	attemptCtx, cancel := context.WithTimeout(ctx, defaultSplitMigrationAttemptTimeout)
	defer cancel()
	stream, err := source.ExportRangeVersions(attemptCtx, &pb.ExportRangeVersionsRequest{
		RangeStart:           bracket.Start,
		RangeEnd:             bracket.End,
		MaxCommitTs:          maxCommitTS,
		MinCommitTs:          minCommitTS,
		Cursor:               progress.Cursor,
		ChunkBytes:           defaultSplitMigrationChunkBytes,
		RouteStart:           job.SplitKey,
		RouteEnd:             sourceRoute.End,
		MaxScannedBytes:      defaultSplitMigrationMaxScannedBytes,
		KeyFamily:            bracket.Family,
		ExcludeKnownInternal: bracket.ExcludeKnownInternal,
		ExcludePrefixes:      bracket.ExcludePrefixes,
	})
	if err != nil {
		return errors.WithStack(migrationSourceExportError(err))
	}
	return s.copySplitJobStream(ctx, job, progressIndex, bracket, progress, stream, target)
}

func (s *DistributionServer) splitCopySourceAdmission(ctx context.Context, job distribution.SplitJob) (distribution.RouteDescriptor, *splitTransferAdmissionWitness, error) {
	_, route, err := s.splitJobSourceRoute(ctx, job)
	if err != nil {
		return route, nil, err
	}
	witness, err := s.ensureSplitJobTransferPhase(ctx, job, nil, nil)
	return route, witness, err
}

func (s *DistributionServer) splitCopyClients(ctx context.Context, job distribution.SplitJob, groupID uint64) (SplitMigrationClient, SplitMigrationClient, error) {
	source, target, err := s.splitMigrationClientFactory(ctx, job, groupID)
	if err != nil {
		return nil, nil, errors.WithStack(err)
	}
	if source == nil || target == nil {
		return nil, nil, errors.New("split migration source or target client is nil")
	}
	return source, target, nil
}

func (s *DistributionServer) copySplitJobStream(
	ctx context.Context,
	job distribution.SplitJob,
	progressIndex int,
	bracket distribution.MigrationBracket,
	progress distribution.SplitJobBracketProgress,
	stream grpc.ServerStreamingClient[pb.ExportRangeVersionsResponse],
	target SplitMigrationClient,
) error {
	for {
		resp, recvErr := stream.Recv()
		if errors.Is(recvErr, io.EOF) {
			return nil
		}
		if recvErr != nil {
			return errors.WithStack(migrationSourceExportError(recvErr))
		}
		nextCursor := distribution.CloneBytes(resp.GetNextCursor())
		batchSeq := progress.LastAckedBatchSeq + 1
		ackedCursor, duplicate, err := importSplitJobChunk(ctx, target, job, bracket, batchSeq, resp.GetVersions(), nextCursor)
		if err != nil {
			return err
		}
		if duplicate {
			// The target already holds this batch durably from an attempt whose
			// progress this runner never persisted. Its acknowledgement is the
			// authority on where the copy stands: the source keeps taking writes
			// while the copy runs, so a replayed chunk can end on a different
			// boundary, and demanding the boundary match would fail the job on
			// every retry. Adopt the acknowledged cursor and re-export from it --
			// the rest of this stream is cut relative to a boundary the target
			// never accepted.
			return s.adoptDuplicateImportAck(ctx, job, progressIndex, progress, batchSeq, ackedCursor)
		}
		progress.Cursor = nextCursor
		progress.Done = resp.GetDone()
		progress.AcceptedRows += uint64(len(resp.GetVersions()))
		progress.LastAckedBatchSeq = batchSeq
		for _, version := range resp.GetVersions() {
			if version.GetCommitTs() > job.MaxImportedTS {
				job.MaxImportedTS = version.GetCommitTs()
			}
		}
		job.BracketProgress[progressIndex] = progress
		job.Cursor = nextCursor
		job.UpdatedAtMs = time.Now().UnixMilli()
		if err := s.persistSplitJobCopyProgress(ctx, job); err != nil {
			return err
		}
		if progress.Done {
			return nil
		}
	}
}

func cleanupSplitMigration(ctx context.Context, client SplitMigrationClient, req *pb.CleanupMigrationRequest) (*pb.CleanupMigrationResponse, error) {
	attemptCtx, cancel := context.WithTimeout(ctx, defaultSplitMigrationAttemptTimeout)
	defer cancel()
	resp, err := client.CleanupMigration(attemptCtx, req)
	return resp, errors.WithStack(err)
}

// importSplitJobChunk hands one exported chunk to the target and returns the
// cursor the target durably holds. duplicate marks an acknowledgement the
// target had already recorded for this batch sequence, in which case the
// acknowledged cursor is its own and need not match the one just sent.
func importSplitJobChunk(
	ctx context.Context,
	target SplitMigrationClient,
	job distribution.SplitJob,
	bracket distribution.MigrationBracket,
	batchSeq uint64,
	versions []*pb.MVCCVersion,
	nextCursor []byte,
) ([]byte, bool, error) {
	attemptCtx, cancel := context.WithTimeout(ctx, defaultSplitMigrationAttemptTimeout)
	defer cancel()
	resp, err := target.ImportRangeVersions(attemptCtx, &pb.ImportRangeVersionsRequest{
		JobId:     job.JobID,
		Versions:  versions,
		Cursor:    nextCursor,
		BracketId: bracket.BracketID,
		BatchSeq:  batchSeq,
	})
	if err != nil {
		return nil, false, errors.WithStack(err)
	}
	if resp.GetDuplicate() {
		return resp.GetAckedCursor(), true, nil
	}
	if !bytes.Equal(resp.GetAckedCursor(), nextCursor) {
		return nil, false, errors.New("split migration import acknowledged a different cursor")
	}
	return resp.GetAckedCursor(), false, nil
}

// adoptDuplicateImportAck records the target's durable acknowledgement for a
// batch the runner re-sent after losing its own progress. Only the cursor and
// the batch sequence advance: the rows were applied by the earlier attempt, and
// this runner never observed which of them the target actually accepted, so
// AcceptedRows and MaxImportedTS stay where they are rather than counting rows
// twice. Done is likewise left alone -- the replayed export's end-of-range
// answer describes a chunk the target did not take.
func (s *DistributionServer) adoptDuplicateImportAck(
	ctx context.Context,
	job distribution.SplitJob,
	progressIndex int,
	progress distribution.SplitJobBracketProgress,
	batchSeq uint64,
	ackedCursor []byte,
) error {
	adopted := distribution.CloneBytes(ackedCursor)
	progress.Cursor = adopted
	progress.LastAckedBatchSeq = batchSeq
	job.BracketProgress[progressIndex] = progress
	job.Cursor = adopted
	job.UpdatedAtMs = time.Now().UnixMilli()
	return s.persistSplitJobCopyProgress(ctx, job)
}

func nextSplitJobBracket(
	job distribution.SplitJob,
	brackets []distribution.MigrationBracket,
	exportPhase distribution.SplitJobExportPhase,
) (int, distribution.MigrationBracket, bool) {
	byID := make(map[uint64]distribution.MigrationBracket, len(brackets))
	for _, bracket := range brackets {
		byID[bracket.BracketID] = bracket
	}
	for i, progress := range job.BracketProgress {
		if progress.ExportPhase != exportPhase || progress.Done {
			continue
		}
		bracket, found := byID[progress.BracketID]
		if found && bracket.Family == progress.Family {
			return i, bracket, true
		}
	}
	return 0, distribution.MigrationBracket{}, false
}

func (s *DistributionServer) persistSplitJobCopyProgress(ctx context.Context, next distribution.SplitJob) error {
	return s.updateSplitJobViaCoordinator(ctx, next.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase != next.Phase {
			return current, nil
		}
		return distribution.CloneSplitJob(next), nil
	})
}

func (s *DistributionServer) advanceCompletedCopyPhase(ctx context.Context, job distribution.SplitJob, phase distribution.SplitJobExportPhase) error {
	switch phase {
	case distribution.SplitJobExportPhaseBackfill:
		return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
			if current.Phase == distribution.SplitJobPhaseBackfill {
				current.Phase = distribution.SplitJobPhaseFence
				current.UpdatedAtMs = time.Now().UnixMilli()
			}
			return current, nil
		})
	case distribution.SplitJobExportPhaseDeltaCopy:
		return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
			if current.Phase == distribution.SplitJobPhaseDeltaCopy {
				current.Phase = distribution.SplitJobPhaseCutover
				current.UpdatedAtMs = time.Now().UnixMilli()
			}
			return current, nil
		})
	case distribution.SplitJobExportPhaseNone:
		return errors.New("unknown split migration export phase")
	}
	return errors.New("unknown split migration export phase")
}

func (s *DistributionServer) finalizeSplitJobFence(ctx context.Context, job distribution.SplitJob) error {
	snapshot, sourceRoute, ready, err := s.prepareSplitJobCatalogFence(ctx, job)
	if err != nil || !ready {
		return err
	}
	source, minAdmittedTS, ackCursor, complete, err := s.drainedSplitJobFenceBarrier(ctx, job, snapshot, sourceRoute)
	if err != nil {
		return err
	}
	if !complete {
		return s.persistSplitJobFenceAck(ctx, job.JobID, ackCursor)
	}
	witness, err := s.ensureSplitJobTransferPhase(ctx, job, source, nil)
	if err != nil {
		return err
	}
	issued, err := issueSplitMigrationTimestamp(ctx, source)
	if err != nil {
		return errors.WithStack(err)
	}
	if issued.GetTimestamp() == 0 || issued.GetTimestamp() <= issued.GetLastCommitTs() {
		return errors.New("split migration source issued an invalid fence timestamp")
	}
	if err := s.revalidateSplitTransferAdmission(ctx, witness); err != nil {
		return err
	}
	return s.commitSplitJobFenceState(ctx, job, snapshot.Version, minAdmittedTS, ackCursor, issued.GetTimestamp())
}

func (s *DistributionServer) prepareSplitJobCatalogFence(ctx context.Context, job distribution.SplitJob) (distribution.CatalogSnapshot, distribution.RouteDescriptor, bool, error) {
	ready, err := s.preflightSplitJobTransfer(ctx, job)
	if err != nil || !ready {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, false, err
	}
	snapshot, route, err := s.splitJobSourceRoute(ctx, job)
	if err != nil {
		return snapshot, route, false, err
	}
	if _, err := s.ensureSplitJobTransferPhase(ctx, job, nil, nil); err != nil {
		return snapshot, route, false, err
	}
	snapshot, route, err = s.ensureSplitJobCatalogFence(ctx, job, snapshot, route)
	return snapshot, route, err == nil, err
}

func (s *DistributionServer) drainedSplitJobFenceBarrier(
	ctx context.Context,
	job distribution.SplitJob,
	snapshot distribution.CatalogSnapshot,
	sourceRoute distribution.RouteDescriptor,
) (SplitMigrationClient, uint64, []byte, bool, error) {
	source, minimum, cursor, complete, err := s.applySplitJobFenceBarrier(ctx, job, snapshot, sourceRoute)
	if err != nil || !complete {
		return source, minimum, cursor, complete, err
	}
	pending, err := splitJobPendingLocks(ctx, source, job.SplitKey, sourceRoute.End)
	if err != nil {
		return nil, 0, nil, false, err
	}
	if pending {
		return source, minimum, cursor, false, nil
	}
	// Reapplying the identical Raft control preserves and reads the tracker
	// minimum after every pre-fence transaction has released its lock.
	return s.applySplitJobFenceBarrier(ctx, job, snapshot, sourceRoute)
}

func (s *DistributionServer) applySplitJobFenceBarrier(
	ctx context.Context,
	job distribution.SplitJob,
	snapshot distribution.CatalogSnapshot,
	sourceRoute distribution.RouteDescriptor,
) (SplitMigrationClient, uint64, []byte, bool, error) {
	source, err := s.splitJobSourceClient(ctx, job, sourceRoute.GroupID)
	if err != nil {
		return nil, 0, nil, false, errors.WithStack(err)
	}
	minAdmittedTS, err := applySplitMigrationControl(
		ctx,
		source,
		job,
		sourceRoute.End,
		snapshot.Version,
		job.SnapshotTS,
		true,
		false,
		true,
		1,
	)
	if err != nil {
		return nil, 0, nil, false, err
	}
	ackCursor, complete, err := s.syncSplitMigrationVoterBarrier(ctx, sourceRoute.GroupID, job.FenceAckCursor, source, &pb.ProbeMigrationStateRequest{
		JobId:                  job.JobID,
		Kind:                   pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_CONTROL_APPLIED,
		RouteStart:             job.SplitKey,
		RouteEnd:               sourceRoute.End,
		ExpectedCatalogVersion: snapshot.Version,
		MigrationJobId:         job.JobID,
		MinWriteTsExclusive:    job.SnapshotTS,
		SourceWriteFence:       true,
		TrackWrites:            true,
		RetentionPinTs:         1,
	})
	if err != nil {
		return nil, 0, nil, false, err
	}
	return source, minAdmittedTS, ackCursor, complete, nil
}

func (s *DistributionServer) persistSplitJobFenceAck(ctx context.Context, jobID uint64, ackCursor []byte) error {
	return s.updateSplitJobViaCoordinator(ctx, jobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == distribution.SplitJobPhaseFence {
			current.FenceAckCursor = distribution.CloneBytes(ackCursor)
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
}

func (s *DistributionServer) commitSplitJobFenceState(ctx context.Context, job distribution.SplitJob, fenceCatalogVersion, minAdmittedTS uint64, ackCursor []byte, fenceTS uint64) error {
	deltaFloor := job.SnapshotTS
	if minAdmittedTS > 0 && minAdmittedTS-1 < deltaFloor {
		deltaFloor = minAdmittedTS - 1
	}
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase != distribution.SplitJobPhaseFence {
			return current, nil
		}
		current.Phase = distribution.SplitJobPhaseDeltaCopy
		current.PostFenceDrainCompleted = true
		current.SnapshotMinAdmittedTS = minAdmittedTS
		current.DeltaFloor = deltaFloor
		current.FenceTS = fenceTS
		current.FenceCatalogVersion = fenceCatalogVersion
		current.FenceAckCursor = distribution.CloneBytes(ackCursor)
		current.SourceRetentionPinTS = 1
		for i := range current.BracketProgress {
			current.BracketProgress[i].ExportPhase = distribution.SplitJobExportPhaseDeltaCopy
			current.BracketProgress[i].Cursor = nil
			current.BracketProgress[i].Done = false
			current.BracketProgress[i].ScannedBytes = 0
			current.BracketProgress[i].AcceptedRows = 0
		}
		current.UpdatedAtMs = time.Now().UnixMilli()
		return current, nil
	})
}

func (s *DistributionServer) ensureSplitJobCatalogFence(
	ctx context.Context,
	job distribution.SplitJob,
	snapshot distribution.CatalogSnapshot,
	sourceRoute distribution.RouteDescriptor,
) (distribution.CatalogSnapshot, distribution.RouteDescriptor, error) {
	if job.WorkingSourceRouteID != 0 {
		return s.fenceSplitWorkingSource(ctx, job, snapshot, sourceRoute)
	}
	if sourceRoute.RouteID != job.SourceRouteID {
		return snapshot, sourceRoute, nil
	}
	current, found, err := s.catalog.SplitJobAt(ctx, job.JobID, snapshot.ReadTS)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, errors.WithStack(err)
	}
	if !found || current.Phase != distribution.SplitJobPhaseFence {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, errors.WithStack(store.ErrWriteConflict)
	}
	leftID, rightID, err := s.allocateChildRouteIDs(ctx, snapshot.ReadTS, snapshot.Routes)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, err
	}
	left, right := splitCatalogRoutes(sourceRoute, job.SplitKey, leftID, rightID, job.FenceTS)
	right.State = distribution.RouteStateWriteFenced
	// The catalog write goes through the coordinator, so it needs a real read
	// timestamp token rather than the bare snapshot.ReadTS: the dispatch below
	// consumes its voucher. Pinned at the snapshot the fence was planned from.
	readTimestamp, err := kv.BeginReadTimestampThrough(
		ctx,
		s.coordinator,
		snapshot.ReadTS,
		"split job catalog fence: begin read timestamp",
	)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, grpcStatusErrorf(
			codes.Internal, "begin split job fence snapshot: %v", err)
	}
	snapshot, err = s.saveSplitResultViaCoordinator(ctx, readTimestamp, snapshot.Version, sourceRoute.RouteID, [][]byte{distribution.CatalogSplitJobKey(job.JobID)}, left, right)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, err
	}
	if err := s.applyEngineSnapshot(snapshot); err != nil {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, err
	}
	return snapshot, right, nil
}

func splitJobPendingLocks(ctx context.Context, source SplitMigrationClient, routeStart []byte, routeEnd []byte) (bool, error) {
	attemptCtx, cancel := context.WithTimeout(ctx, defaultSplitMigrationAttemptTimeout)
	defer cancel()
	resp, err := source.ProbeMigrationLocks(attemptCtx, &pb.ProbeMigrationLocksRequest{
		RouteStart: routeStart,
		RouteEnd:   routeEnd,
		Limit:      defaultSplitMigrationLockProbeLimit,
	})
	if err != nil {
		return false, errors.WithStack(err)
	}
	return resp.GetPendingCount() != 0, nil
}

func (s *DistributionServer) cutoverSplitJob(ctx context.Context, job distribution.SplitJob) error {
	snapshot, sourceRoute, err := s.splitJobSourceRoute(ctx, job)
	if err != nil {
		return err
	}
	if snapshot.Version == math.MaxUint64 {
		return errors.New("split migration catalog version overflow")
	}
	expectedVersion := snapshot.Version + 1
	if job.CutoverVersion == 0 || job.CutoverVersion != expectedVersion {
		return s.armSplitJobCutoverWitness(ctx, job, expectedVersion)
	}
	targetCursor, sourceCursor, targetComplete, sourceComplete, err := s.applySplitJobCutoverBarriers(ctx, job, sourceRoute, expectedVersion)
	if err != nil {
		return err
	}
	if splitJobCutoverBarrierPending(job, targetComplete, sourceComplete) {
		return s.persistSplitJobCutoverAcks(ctx, job.JobID, targetCursor, sourceCursor, targetComplete, sourceComplete)
	}
	return s.commitSplitJobCutover(ctx, snapshot, sourceRoute, job, expectedVersion)
}

func (s *DistributionServer) applySplitJobCutoverBarriers(
	ctx context.Context,
	job distribution.SplitJob,
	sourceRoute distribution.RouteDescriptor,
	expectedVersion uint64,
) ([]byte, []byte, bool, bool, error) {
	source, target, err := s.splitMigrationClientFactory(ctx, job, sourceRoute.GroupID)
	if err != nil {
		return nil, nil, false, false, errors.WithStack(err)
	}
	if _, err := applySplitMigrationControl(ctx, target, job, sourceRoute.End, expectedVersion, job.FenceTS, false, false, false, 0); err != nil {
		return nil, nil, false, false, err
	}
	if _, err := applySplitMigrationControl(ctx, source, job, sourceRoute.End, expectedVersion, job.FenceTS, true, true, job.WriteTrackerArmed, 1); err != nil {
		return nil, nil, false, false, err
	}
	targetCursor, targetComplete, err := s.syncSplitMigrationVoterBarrier(ctx, job.TargetGroupID, job.TargetStagedReadinessAckCursor, target, &pb.ProbeMigrationStateRequest{
		JobId:                  job.JobID,
		Kind:                   pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_CONTROL_APPLIED,
		RouteStart:             job.SplitKey,
		RouteEnd:               sourceRoute.End,
		ExpectedCatalogVersion: expectedVersion,
		MigrationJobId:         job.JobID,
		MinWriteTsExclusive:    job.FenceTS,
	})
	if err != nil {
		return nil, nil, false, false, err
	}
	sourceCursor, sourceComplete, err := s.syncSplitMigrationVoterBarrier(ctx, sourceRoute.GroupID, job.SourceCutoverReadFenceAckCursor, source, &pb.ProbeMigrationStateRequest{
		JobId:                  job.JobID,
		Kind:                   pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_CONTROL_APPLIED,
		RouteStart:             job.SplitKey,
		RouteEnd:               sourceRoute.End,
		ExpectedCatalogVersion: expectedVersion,
		MigrationJobId:         job.JobID,
		MinWriteTsExclusive:    job.FenceTS,
		SourceWriteFence:       true,
		SourceReadFence:        true,
		TrackWrites:            job.WriteTrackerArmed,
		RetentionPinTs:         1,
	})
	if err != nil {
		return nil, nil, false, false, err
	}
	return targetCursor, sourceCursor, targetComplete, sourceComplete, nil
}

func splitJobCutoverBarrierPending(job distribution.SplitJob, targetComplete, sourceComplete bool) bool {
	return !targetComplete || !sourceComplete ||
		job.TargetStagedReadinessState != distribution.SplitJobBarrierArmed ||
		job.CutoverReadFenceState != distribution.SplitJobBarrierArmed
}

func (s *DistributionServer) armSplitJobCutoverWitness(ctx context.Context, job distribution.SplitJob, expectedVersion uint64) error {
	return s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase != distribution.SplitJobPhaseCutover {
			return current, nil
		}
		current.CutoverVersion = expectedVersion
		current.CutoverReadFenceState = distribution.SplitJobBarrierArming
		current.TargetStagedReadinessState = distribution.SplitJobBarrierArming
		current.SourceCutoverReadFenceAckCursor = nil
		current.TargetStagedReadinessAckCursor = nil
		current.UpdatedAtMs = time.Now().UnixMilli()
		return current, nil
	})
}

func (s *DistributionServer) persistSplitJobCutoverAcks(
	ctx context.Context,
	jobID uint64,
	targetCursor []byte,
	sourceCursor []byte,
	targetComplete bool,
	sourceComplete bool,
) error {
	return s.updateSplitJobViaCoordinator(ctx, jobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase != distribution.SplitJobPhaseCutover {
			return current, nil
		}
		current.TargetStagedReadinessAckCursor = distribution.CloneBytes(targetCursor)
		current.SourceCutoverReadFenceAckCursor = distribution.CloneBytes(sourceCursor)
		current.TargetStagedReadinessState = distribution.SplitJobBarrierArming
		if targetComplete {
			current.TargetStagedReadinessState = distribution.SplitJobBarrierArmed
		}
		current.CutoverReadFenceState = distribution.SplitJobBarrierArming
		if sourceComplete {
			current.CutoverReadFenceState = distribution.SplitJobBarrierArmed
		}
		current.UpdatedAtMs = time.Now().UnixMilli()
		return current, nil
	})
}

func applySplitMigrationControl(
	ctx context.Context,
	client SplitMigrationClient,
	job distribution.SplitJob,
	routeEnd []byte,
	expectedVersion uint64,
	minWriteTS uint64,
	sourceWriteFence bool,
	sourceReadFence bool,
	trackWrites bool,
	retentionPinTS uint64,
) (uint64, error) {
	if client == nil {
		return 0, errors.New("split migration control client is nil")
	}
	resp, err := applySplitMigrationControlRequest(ctx, client, splitMigrationControlRequest(
		job,
		routeEnd,
		expectedVersion,
		minWriteTS,
		sourceWriteFence,
		sourceReadFence,
		trackWrites,
		retentionPinTS,
	))
	if err != nil {
		return 0, errors.WithStack(err)
	}
	return resp.GetMinAdmittedTs(), nil
}

func applySplitMigrationControlRequest(ctx context.Context, client SplitMigrationClient, req *pb.TargetStagedReadinessRequest) (*pb.TargetStagedReadinessResponse, error) {
	attemptCtx, cancel := context.WithTimeout(ctx, defaultSplitMigrationAttemptTimeout)
	defer cancel()
	resp, err := client.ApplyTargetStagedReadiness(attemptCtx, req)
	return resp, errors.WithStack(err)
}

func issueSplitMigrationTimestamp(ctx context.Context, client SplitMigrationClient) (*pb.IssueMigrationTimestampResponse, error) {
	attemptCtx, cancel := context.WithTimeout(ctx, defaultSplitMigrationAttemptTimeout)
	defer cancel()
	resp, err := client.IssueMigrationTimestamp(attemptCtx, &pb.IssueMigrationTimestampRequest{})
	return resp, errors.WithStack(err)
}

func splitMigrationControlRequest(
	job distribution.SplitJob,
	routeEnd []byte,
	expectedVersion uint64,
	minWriteTS uint64,
	sourceWriteFence bool,
	sourceReadFence bool,
	trackWrites bool,
	retentionPinTS uint64,
) *pb.TargetStagedReadinessRequest {
	return &pb.TargetStagedReadinessRequest{
		JobId:                  job.JobID,
		RouteStart:             job.SplitKey,
		RouteEnd:               routeEnd,
		ExpectedCutoverVersion: expectedVersion,
		MigrationJobId:         job.JobID,
		MinWriteTsExclusive:    minWriteTS,
		Armed:                  true,
		SourceWriteFence:       sourceWriteFence,
		SourceReadFence:        sourceReadFence,
		RetentionPinTs:         retentionPinTS,
		TrackWrites:            trackWrites,
	}
}

func probeMigrationControlRequest(req *pb.TargetStagedReadinessRequest) *pb.ProbeMigrationStateRequest {
	return &pb.ProbeMigrationStateRequest{
		JobId:                  req.GetJobId(),
		Kind:                   pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_CONTROL_APPLIED,
		RouteStart:             distribution.CloneBytes(req.GetRouteStart()),
		RouteEnd:               distribution.CloneBytes(req.GetRouteEnd()),
		ExpectedCatalogVersion: req.GetExpectedCutoverVersion(),
		MigrationJobId:         req.GetMigrationJobId(),
		MinWriteTsExclusive:    req.GetMinWriteTsExclusive(),
		SourceWriteFence:       req.GetSourceWriteFence(),
		SourceReadFence:        req.GetSourceReadFence(),
		TrackWrites:            req.GetTrackWrites(),
		RetentionPinTs:         req.GetRetentionPinTs(),
	}
}

func splitJobCapabilityRegressionRequiresFailClosed(job distribution.SplitJob) bool {
	return splitJobCapabilityRegressionSourceGuardRequired(job) ||
		splitJobCapabilityRegressionTargetGuardRequired(job)
}

func splitJobCapabilityRegressionSourceGuardRequired(job distribution.SplitJob) bool {
	switch job.Phase {
	case distribution.SplitJobPhasePlanned:
		return job.WriteTrackerArmed ||
			job.SnapshotTS != 0 ||
			job.SourceRetentionPinTS != 0 ||
			len(job.FenceAckCursor) != 0
	case distribution.SplitJobPhaseBackfill,
		distribution.SplitJobPhaseFence,
		distribution.SplitJobPhaseDeltaCopy,
		distribution.SplitJobPhaseCutover:
		return true
	case distribution.SplitJobPhaseCleanup:
		return job.SourceRetentionPinTS != math.MaxUint64
	case distribution.SplitJobPhaseNone,
		distribution.SplitJobPhaseDone,
		distribution.SplitJobPhaseFailed,
		distribution.SplitJobPhaseAbandoning,
		distribution.SplitJobPhaseAbandoned:
		return false
	}
	return false
}

func splitJobCapabilityRegressionTargetGuardRequired(job distribution.SplitJob) bool {
	switch job.Phase {
	case distribution.SplitJobPhasePlanned:
		return job.WriteTrackerArmed ||
			job.SnapshotTS != 0 ||
			job.SourceRetentionPinTS != 0 ||
			len(job.FenceAckCursor) != 0
	case distribution.SplitJobPhaseBackfill,
		distribution.SplitJobPhaseFence,
		distribution.SplitJobPhaseDeltaCopy,
		distribution.SplitJobPhaseCutover:
		return true
	case distribution.SplitJobPhaseCleanup:
		return !bytes.Equal(job.TargetClearedDescriptorAckCursor, splitCleanupDoneCursor)
	case distribution.SplitJobPhaseNone,
		distribution.SplitJobPhaseDone,
		distribution.SplitJobPhaseFailed,
		distribution.SplitJobPhaseAbandoning,
		distribution.SplitJobPhaseAbandoned:
		return false
	}
	return false
}

type splitJobMigrationControlTargets struct {
	snapshot      distribution.CatalogSnapshot
	sourceGroupID uint64
	routeEnd      []byte
	source        SplitMigrationClient
	target        SplitMigrationClient
}

func (s *DistributionServer) splitJobCapabilityControlTargets(ctx context.Context, job distribution.SplitJob) (splitJobMigrationControlTargets, error) {
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return splitJobMigrationControlTargets{}, err
	}
	sourceGroupID, routeEnd, ok := splitJobSourceRouteState(snapshot.Routes, job)
	if !ok {
		return splitJobMigrationControlTargets{}, errors.WithStack(distribution.ErrMigrationSourceRouteChanged)
	}
	source, target, err := s.splitMigrationClientFactory(ctx, job, sourceGroupID)
	if err != nil {
		return splitJobMigrationControlTargets{}, errors.WithStack(err)
	}
	if source == nil || target == nil {
		return splitJobMigrationControlTargets{}, errors.New("split migration source or target client is nil")
	}
	return splitJobMigrationControlTargets{
		snapshot:      snapshot,
		sourceGroupID: sourceGroupID,
		routeEnd:      routeEnd,
		source:        source,
		target:        target,
	}, nil
}

func (s *DistributionServer) ensureSplitJobCapabilityRegressionFailClosed(ctx context.Context, job distribution.SplitJob) (bool, error) {
	targets, err := s.splitJobCapabilityControlTargets(ctx, job)
	if err != nil {
		return false, err
	}
	expectedVersion := splitJobCapabilityRegressionExpectedVersion(job, targets.snapshot.Version)
	minWriteTS := splitJobCapabilityRegressionMinWriteTS(job)
	retentionPinTS := splitJobCapabilityRegressionRetentionPinTS(job)
	sourceComplete := true
	if splitJobCapabilityRegressionSourceGuardRequired(job) {
		sourceReq := splitMigrationControlRequest(job, targets.routeEnd, expectedVersion, minWriteTS, true, true, true, retentionPinTS)
		var err error
		sourceComplete, err = s.applyAndProbeSplitMigrationControl(ctx, targets.sourceGroupID, targets.source, sourceReq)
		if err != nil {
			return false, err
		}
	}
	targetComplete := true
	if splitJobCapabilityRegressionTargetGuardRequired(job) {
		targetReq := splitMigrationControlRequest(job, targets.routeEnd, expectedVersion, minWriteTS, false, false, false, 0)
		var err error
		targetComplete, err = s.applyAndProbeSplitMigrationControl(ctx, job.TargetGroupID, targets.target, targetReq)
		if err != nil {
			return false, err
		}
	}
	return sourceComplete && targetComplete, nil
}

func (s *DistributionServer) restoreSplitJobCapabilityRegressionGuards(ctx context.Context, job distribution.SplitJob) (bool, error) {
	targets, err := s.splitJobCapabilityControlTargets(ctx, job)
	if err != nil {
		return false, err
	}
	if splitJobCapabilityRegressionSourceGuardRequired(job) {
		sourceReq, ok := splitJobNormalSourceControlRequest(job, targets.routeEnd, targets.snapshot.Version)
		if ok {
			complete, err := s.applyAndProbeSplitMigrationControl(ctx, targets.sourceGroupID, targets.source, sourceReq)
			if err != nil || !complete {
				return complete, err
			}
		}
	}
	if splitJobCapabilityRegressionTargetGuardRequired(job) {
		targetReq, ok := splitJobNormalTargetControlRequest(job, targets.routeEnd)
		if ok {
			complete, err := s.applyAndProbeSplitMigrationControl(ctx, job.TargetGroupID, targets.target, targetReq)
			if err != nil || !complete {
				return complete, err
			}
		}
	}
	return true, nil
}

func (s *DistributionServer) applyAndProbeSplitMigrationControl(
	ctx context.Context,
	groupID uint64,
	client SplitMigrationClient,
	req *pb.TargetStagedReadinessRequest,
) (bool, error) {
	if client == nil {
		return false, errors.New("split migration control client is nil")
	}
	if _, err := applySplitMigrationControlRequest(ctx, client, req); err != nil {
		return false, errors.WithStack(err)
	}
	_, complete, err := s.syncSplitMigrationVoterBarrier(ctx, groupID, nil, client, probeMigrationControlRequest(req))
	return complete, err
}

func splitJobCapabilityRegressionExpectedVersion(job distribution.SplitJob, snapshotVersion uint64) uint64 {
	switch {
	case job.CutoverVersion != 0:
		return job.CutoverVersion
	case job.FenceCatalogVersion != 0:
		return job.FenceCatalogVersion
	case snapshotVersion < math.MaxUint64:
		return snapshotVersion + 1
	default:
		return snapshotVersion
	}
}

func splitJobCapabilityRegressionMinWriteTS(job distribution.SplitJob) uint64 {
	switch {
	case job.FenceTS != 0:
		return job.FenceTS
	case job.SnapshotTS != 0:
		return job.SnapshotTS
	default:
		return initialMigrationRetentionPinTS
	}
}

func splitJobCapabilityRegressionRetentionPinTS(job distribution.SplitJob) uint64 {
	if job.SourceRetentionPinTS != 0 && job.SourceRetentionPinTS != math.MaxUint64 {
		return job.SourceRetentionPinTS
	}
	return initialMigrationRetentionPinTS
}

func splitJobNormalSourceControlRequest(job distribution.SplitJob, routeEnd []byte, snapshotVersion uint64) (*pb.TargetStagedReadinessRequest, bool) {
	switch job.Phase {
	case distribution.SplitJobPhasePlanned, distribution.SplitJobPhaseBackfill:
		return splitMigrationControlRequest(
			job,
			routeEnd,
			splitJobCapabilityRegressionExpectedVersion(job, snapshotVersion),
			initialMigrationRetentionPinTS,
			false,
			false,
			true,
			initialMigrationRetentionPinTS,
		), true
	case distribution.SplitJobPhaseFence, distribution.SplitJobPhaseDeltaCopy:
		expectedVersion := job.FenceCatalogVersion
		if expectedVersion == 0 {
			expectedVersion = splitJobCapabilityRegressionExpectedVersion(job, snapshotVersion)
		}
		return splitMigrationControlRequest(job, routeEnd, expectedVersion, job.SnapshotTS, true, false, true, initialMigrationRetentionPinTS), true
	case distribution.SplitJobPhaseCutover, distribution.SplitJobPhaseCleanup:
		if job.FenceTS == 0 || job.CutoverVersion == 0 {
			return nil, false
		}
		return splitMigrationControlRequest(job, routeEnd, job.CutoverVersion, job.FenceTS, true, true, false, initialMigrationRetentionPinTS), true
	case distribution.SplitJobPhaseNone,
		distribution.SplitJobPhaseDone,
		distribution.SplitJobPhaseFailed,
		distribution.SplitJobPhaseAbandoning,
		distribution.SplitJobPhaseAbandoned:
		return nil, false
	}
	return nil, false
}

func splitJobNormalTargetControlRequest(job distribution.SplitJob, routeEnd []byte) (*pb.TargetStagedReadinessRequest, bool) {
	if job.CutoverVersion == 0 || job.FenceTS == 0 {
		return nil, false
	}
	switch job.Phase {
	case distribution.SplitJobPhaseCutover, distribution.SplitJobPhaseCleanup:
		return splitMigrationControlRequest(job, routeEnd, job.CutoverVersion, job.FenceTS, false, false, false, 0), true
	case distribution.SplitJobPhaseNone,
		distribution.SplitJobPhasePlanned,
		distribution.SplitJobPhaseBackfill,
		distribution.SplitJobPhaseFence,
		distribution.SplitJobPhaseDeltaCopy,
		distribution.SplitJobPhaseDone,
		distribution.SplitJobPhaseFailed,
		distribution.SplitJobPhaseAbandoning,
		distribution.SplitJobPhaseAbandoned:
		return nil, false
	}
	return nil, false
}

func (s *DistributionServer) splitJobSourceRoute(
	ctx context.Context,
	job distribution.SplitJob,
) (distribution.CatalogSnapshot, distribution.RouteDescriptor, error) {
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, err
	}
	if parent, found := findRouteByID(snapshot.Routes, sourceLookupRouteID(job)); found {
		return snapshot, parent, nil
	}
	for _, route := range snapshot.Routes {
		if route.ParentRouteID == job.SourceRouteID && bytes.Equal(route.Start, job.SplitKey) {
			return snapshot, distribution.CloneRouteDescriptor(route), nil
		}
	}
	return distribution.CatalogSnapshot{}, distribution.RouteDescriptor{}, splitJobCatalogStatusError(distribution.ErrMigrationSourceRouteChanged)
}

func (s *DistributionServer) commitSplitJobCutover(
	ctx context.Context,
	snapshot distribution.CatalogSnapshot,
	right distribution.RouteDescriptor,
	job distribution.SplitJob,
	nextVersion uint64,
) error {
	right.GroupID = job.TargetGroupID
	right.State = distribution.RouteStateActive
	right.StagedVisibilityActive = true
	right.MigrationJobID = job.JobID
	right.MinWriteTSExclusive = job.FenceTS
	encodedRoute, err := distribution.EncodeRouteDescriptorForCatalogWrite(right, s.catalog.AllowsRouteDescriptorV2Writes())
	if err != nil {
		return errors.WithStack(err)
	}
	nextJob := distribution.CloneSplitJob(job)
	nextJob.Phase = distribution.SplitJobPhaseCleanup
	nextJob.CutoverVersion = nextVersion
	nextJob.CutoverReadFenceState = distribution.SplitJobBarrierArmed
	nextJob.TargetStagedReadinessState = distribution.SplitJobBarrierArmed
	nextJob.Cursor = nil
	nextJob.UpdatedAtMs = time.Now().UnixMilli()
	encodedJob, err := distribution.EncodeSplitJob(nextJob)
	if err != nil {
		return errors.WithStack(err)
	}
	versionKey := distribution.CatalogVersionKey()
	routeKey := distribution.CatalogRouteKey(right.RouteID)
	jobKey := distribution.CatalogSplitJobKey(job.JobID)
	deltaOps, err := s.catalogDeltaMutationOps(ctx, snapshot.ReadTS, distribution.CatalogDelta{
		PreviousVersion: snapshot.Version,
		Version:         nextVersion,
		Mutations:       []distribution.CatalogRouteMutation{{Op: distribution.CatalogMutationUpsert, RouteID: right.RouteID, Route: right}},
	})
	if err != nil {
		return err
	}
	ops := []*kv.Elem[kv.OP]{
		{Op: kv.Put, Key: routeKey, Value: encodedRoute},
		{Op: kv.Put, Key: versionKey, Value: distribution.EncodeCatalogVersion(nextVersion)},
		{Op: kv.Put, Key: jobKey, Value: encodedJob},
	}
	ops = append(ops, deltaOps...)
	if _, err := s.coordinator.Dispatch(ctx, &kv.OperationGroup[kv.OP]{
		Elems:    ops,
		IsTxn:    true,
		StartTS:  snapshot.ReadTS,
		ReadKeys: [][]byte{routeKey, versionKey, jobKey, distribution.CatalogDeltaKey(nextVersion), distribution.CatalogDeltaFloorKey()},
	}); err != nil {
		if errors.Is(err, kv.ErrTransactionOutcomeUnknown) {
			return grpcStatusError(codes.Unknown, kv.ErrTransactionOutcomeUnknown.Error())
		}
		if errors.Is(err, store.ErrWriteConflict) {
			return grpcStatusError(codes.Aborted, errDistributionCatalogConflict.Error())
		}
		return errors.WithStack(err)
	}
	updated, err := s.loadCatalogSnapshotAtLeastVersion(ctx, nextVersion)
	if err != nil {
		return err
	}
	return s.applyEngineSnapshot(updated)
}
