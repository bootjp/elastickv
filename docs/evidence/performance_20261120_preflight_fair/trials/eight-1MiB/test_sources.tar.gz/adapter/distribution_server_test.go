package adapter

import (
	"bytes"
	"context"
	"encoding/binary"
	stderrors "errors"
	"io"
	"math"
	"net"
	"sync/atomic"
	"testing"
	"time"

	"github.com/bootjp/elastickv/distribution"
	"github.com/bootjp/elastickv/internal/fskeys"
	"github.com/bootjp/elastickv/internal/raftengine"
	"github.com/bootjp/elastickv/internal/raftengine/raftenginetest"
	"github.com/bootjp/elastickv/internal/s3keys"
	"github.com/bootjp/elastickv/internal/testutil"
	"github.com/bootjp/elastickv/kv"
	pb "github.com/bootjp/elastickv/proto"
	"github.com/bootjp/elastickv/store"
	"github.com/cockroachdb/errors"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func TestDistributionServerGetRoute_HitAndMiss(t *testing.T) {
	t.Parallel()

	engine := distribution.NewEngine()
	engine.UpdateRoute([]byte("a"), []byte("m"), 1)
	engine.UpdateRoute([]byte("m"), nil, 2)

	s := NewDistributionServer(engine, nil)
	ctx := context.Background()

	hit, err := s.GetRoute(ctx, &pb.GetRouteRequest{Key: []byte("b")})
	require.NoError(t, err)
	require.Equal(t, []byte("a"), hit.Start)
	require.Equal(t, []byte("m"), hit.End)
	require.Equal(t, uint64(1), hit.RaftGroupId)

	miss, err := s.GetRoute(ctx, &pb.GetRouteRequest{Key: []byte("0")})
	require.NoError(t, err)
	require.Equal(t, uint64(0), miss.RaftGroupId)
	require.Nil(t, miss.Start)
	require.Nil(t, miss.End)
}

func TestDistributionServerGetRoute_NormalizesFilesystemChunkKeys(t *testing.T) {
	t.Parallel()

	home := uint64(11)
	inode := uint64(22)
	routeKey := fskeys.ChunkRouteKey(home, inode)
	engine := distribution.NewEngine()
	engine.UpdateRoute([]byte(""), routeKey, 1)
	engine.UpdateRoute(routeKey, nil, 2)

	s := NewDistributionServer(engine, nil)
	resp, err := s.GetRoute(context.Background(), &pb.GetRouteRequest{
		Key: fskeys.ChunkKey(home, inode, 99),
	})
	require.NoError(t, err)
	require.Equal(t, routeKey, resp.Start)
	require.Equal(t, uint64(2), resp.RaftGroupId)
}

func TestDistributionServerGetRoute_NormalizesS3BucketAuxiliaryKeys(t *testing.T) {
	t.Parallel()

	bucket := "bucket-a"
	routeKey := s3keys.RoutePrefixForBucketAnyGeneration(bucket)
	engine := distribution.NewEngine()
	engine.UpdateRoute([]byte(""), routeKey, 1)
	engine.UpdateRoute(routeKey, nil, 2)

	s := NewDistributionServer(engine, nil)
	for _, key := range [][]byte{
		s3keys.BucketMetaKey(bucket),
		s3keys.BucketGenerationKey(bucket),
	} {
		resp, err := s.GetRoute(context.Background(), &pb.GetRouteRequest{Key: key})
		require.NoError(t, err)
		require.Equal(t, routeKey, resp.Start)
		require.Equal(t, uint64(2), resp.RaftGroupId)
	}
}

func TestDistributionServerRouteReadsHonorStartupGate(t *testing.T) {
	t.Parallel()

	engine := distribution.NewEngine()
	require.NoError(t, engine.ApplySnapshot(distribution.CatalogSnapshot{
		Version: 1,
		Routes: []distribution.RouteDescriptor{
			{RouteID: 1, Start: []byte("a"), End: nil, GroupID: 1, State: distribution.RouteStateActive},
		},
	}))
	catalog := distribution.NewCatalogStore(store.NewMVCCStore())
	_, err := catalog.Save(context.Background(), 0, []distribution.RouteDescriptor{
		{RouteID: 1, Start: []byte("a"), End: nil, GroupID: 1, State: distribution.RouteStateActive},
	})
	require.NoError(t, err)

	blocked := true
	s := NewDistributionServer(engine, catalog, WithDistributionReadGate(func() bool { return blocked }))

	_, err = s.GetRoute(context.Background(), &pb.GetRouteRequest{Key: []byte("a")})
	require.Error(t, err)
	require.Equal(t, codes.Unavailable, status.Code(err))

	_, err = s.ListRoutes(context.Background(), &pb.ListRoutesRequest{})
	require.Error(t, err)
	require.Equal(t, codes.Unavailable, status.Code(err))

	_, err = s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{
		Key:            []byte("a"),
		CatalogVersion: engine.Version(),
	})
	require.Error(t, err)
	require.Equal(t, codes.Unavailable, status.Code(err))

	_, err = s.GetIntersectingRoutes(context.Background(), &pb.GetIntersectingRoutesRequest{
		Start:          []byte("a"),
		End:            []byte("z"),
		CatalogVersion: engine.Version(),
	})
	require.Error(t, err)
	require.Equal(t, codes.Unavailable, status.Code(err))

	blocked = false
	_, err = s.GetRoute(context.Background(), &pb.GetRouteRequest{Key: []byte("a")})
	require.NoError(t, err)
	_, err = s.ListRoutes(context.Background(), &pb.ListRoutesRequest{})
	require.NoError(t, err)
	_, err = s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{
		Key:            []byte("a"),
		CatalogVersion: engine.Version(),
	})
	require.NoError(t, err)
	_, err = s.GetIntersectingRoutes(context.Background(), &pb.GetIntersectingRoutesRequest{
		Start:          []byte("a"),
		End:            []byte("z"),
		CatalogVersion: engine.Version(),
	})
	require.NoError(t, err)
}

func TestDistributionServerGetTimestamp_IsMonotonic(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), nil)
	ctx := context.Background()

	first, err := s.GetTimestamp(ctx, &pb.GetTimestampRequest{})
	require.NoError(t, err)

	second, err := s.GetTimestamp(ctx, &pb.GetTimestampRequest{})
	require.NoError(t, err)

	require.Greater(t, second.Timestamp, first.Timestamp)
}

func TestDistributionServerGetTimestamp_UsesDedicatedBatchAllocator(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{base: 101, leader: true}
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
	)
	resp, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{
		Count:        8,
		MinTimestamp: 100,
	})
	require.NoError(t, err)
	require.Equal(t, uint64(101), resp.GetTimestamp())
	require.True(t, resp.GetCommittedByDedicatedTso())
	require.Equal(t, 8, alloc.count)
	require.Equal(t, uint64(100), alloc.min)
}

func TestDistributionServerGetTimestamp_CommitsCutoverAndReturnsPriorFloor(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{base: 501, previousFloor: 499, leader: true}
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
	)
	resp, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{
		Count:           1,
		MinTimestamp:    500,
		ActivateCutover: true,
	})
	require.NoError(t, err)
	require.True(t, alloc.activate)
	require.True(t, resp.GetCutoverActive())
	require.Equal(t, uint64(499), resp.GetPreviousAllocationFloor())
}

type bandDistributionAllocator struct {
	*distributionTSOAllocator
	reservations []kv.TSOPhysicalBandReservation
}

func (a *bandDistributionAllocator) ReservePhysicalBandAfter(_ context.Context, _ int, _ uint64) (kv.TSOPhysicalBandReservation, error) {
	r := a.reservations[0]
	a.reservations = a.reservations[1:]
	return r, nil
}

func TestDistributionServerPhysicalBandWireContract(t *testing.T) {
	bandEnd := uint64(10<<16 | 0xffff)
	base := uint64(10 << 16)
	alloc := &bandDistributionAllocator{distributionTSOAllocator: &distributionTSOAllocator{leader: true},
		reservations: []kv.TSOPhysicalBandReservation{
			{Base: base, Count: 2, CommittedBandEnd: bandEnd},
			{Base: base + 11, Count: 2, CommittedBandEnd: bandEnd, PreviousIssuedCursor: base + 1},
		}}
	s := NewDistributionServer(distribution.NewEngine(), nil, WithDistributionTimestampAllocator(alloc))
	req := &pb.GetTimestampRequest{Count: 2, ReservationProtocolVersion: kv.TSOPhysicalBandProtocolVersion}
	_, err := s.GetTimestamp(t.Context(), req)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.Len(t, alloc.reservations, 2)
	s.physicalBandGate = func(context.Context) error { return errors.New("private peer identity") }
	_, err = s.GetTimestamp(t.Context(), req)
	require.Equal(t, codes.PermissionDenied, status.Code(err))
	require.NotContains(t, err.Error(), "private peer identity")
	require.Len(t, alloc.reservations, 2)
	s.physicalBandGate = func(context.Context) error { return nil }
	first, err := s.GetTimestamp(t.Context(), req)
	require.NoError(t, err)
	require.Equal(t, kv.TSOPhysicalBandProtocolVersion, first.GetReservationProtocolVersion())
	require.Equal(t, bandEnd, first.GetCommittedBandEnd())
	require.Zero(t, first.GetPreviousIssuedCursor())
	req.MinTimestamp = base + 10
	second, err := s.GetTimestamp(t.Context(), req)
	require.NoError(t, err)
	require.Equal(t, base+1, second.GetPreviousIssuedCursor())
	require.Equal(t, base+11, second.GetTimestamp())
	for _, version := range []uint32{2, 99} {
		req.ReservationProtocolVersion = version
		_, err = s.GetTimestamp(t.Context(), req)
		require.Equal(t, codes.InvalidArgument, status.Code(err))
	}
	req.ReservationProtocolVersion = kv.TSOPhysicalBandProtocolVersion
	req.ActivatePhaseD = true
	_, err = s.GetTimestamp(t.Context(), req)
	require.Equal(t, codes.InvalidArgument, status.Code(err))
}

func TestDistributionServerGetTimestamp_CommitsPhaseDAndReturnsFloor(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{base: 501, previousFloor: 499, leader: true}
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
	)
	resp, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{
		Count:           1,
		MinTimestamp:    500,
		ActivateCutover: true,
		ActivatePhaseD:  true,
	})
	require.NoError(t, err)
	require.True(t, alloc.activate)
	require.True(t, alloc.activatePhaseD)
	require.True(t, resp.GetCutoverActive())
	require.True(t, resp.GetPhaseDActive())
	require.Equal(t, uint64(499), resp.GetPhaseDFloor())
}

func TestDistributionServerGetTimestamp_RejectsPhaseDWithoutCutover(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(&distributionTSOAllocator{leader: true}),
	)
	_, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{ActivatePhaseD: true})
	require.Equal(t, codes.InvalidArgument, status.Code(err))
}

func TestDistributionServerValidateTimestamp(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{
		base:        501,
		leader:      true,
		phaseD:      true,
		phaseDFloor: 499,
	}
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
	)
	resp, err := s.ValidateTimestamp(context.Background(), &pb.ValidateTimestampRequest{Timestamp: 500})
	require.NoError(t, err)
	require.True(t, resp.GetValid())
	require.True(t, resp.GetPhaseDActive())
	require.Equal(t, uint64(499), resp.GetPhaseDFloor())
	require.Equal(t, uint64(501), resp.GetAllocationFloor())

	_, err = s.ValidateTimestamp(context.Background(), &pb.ValidateTimestampRequest{Timestamp: 499})
	require.Equal(t, codes.OutOfRange, status.Code(err))
}

type pendingResolutionAllocator struct {
	*distributionTSOAllocator
	pendingFloor uint64
}

func (a *pendingResolutionAllocator) ValidateDurableTimestamp(ctx context.Context, timestamp uint64) error {
	if !a.phaseD {
		return kv.ErrTSOPhaseDInactive
	}
	return a.distributionTSOAllocator.ValidateDurableTimestamp(ctx, timestamp)
}

func (a *pendingResolutionAllocator) ValidateLegacyResolutionTimestamps(_ context.Context, start, commit uint64) error {
	if a.phaseD {
		return kv.ErrTSOPhaseDInactive
	}
	if start == 0 || start >= commit || (a.pendingFloor != 0 && commit > a.pendingFloor) {
		return kv.ErrTSOTimestampInvalid
	}
	return nil
}

func TestDistributionServerPendingLegacyResolutionMode(t *testing.T) {
	t.Parallel()
	alloc := &pendingResolutionAllocator{distributionTSOAllocator: &distributionTSOAllocator{leader: true}, pendingFloor: 100}
	s := NewDistributionServer(distribution.NewEngine(), nil, WithDistributionTimestampAllocator(alloc))
	ctx := context.Background()
	resp, err := s.ValidateTimestamp(ctx, &pb.ValidateTimestampRequest{Timestamp: 100, StartTimestamp: 50, LegacyResolution: true})
	require.NoError(t, err)
	require.True(t, resp.GetValid())
	require.True(t, resp.GetLegacyResolutionValidated())
	require.False(t, resp.GetPhaseDActive())
	for _, req := range []*pb.ValidateTimestampRequest{
		{Timestamp: 100, LegacyResolution: true},
		{Timestamp: 100, StartTimestamp: 100, LegacyResolution: true},
		{Timestamp: 101, StartTimestamp: 50, LegacyResolution: true},
		{Timestamp: 100, StartTimestamp: 50},
	} {
		_, err := s.ValidateTimestamp(ctx, req)
		require.Equal(t, codes.InvalidArgument, status.Code(err))
	}
	_, err = s.ValidateTimestamp(ctx, &pb.ValidateTimestampRequest{Timestamp: 100})
	require.Error(t, err, "ordinary validation must remain closed before M7")
	alloc.pendingFloor = 0
	resp, err = s.ValidateTimestamp(ctx, &pb.ValidateTimestampRequest{Timestamp: 101, StartTimestamp: 50, LegacyResolution: true})
	require.NoError(t, err, "pre-pending drain must admit existing resolutions above the future barrier")
	require.True(t, resp.GetLegacyResolutionValidated())
	alloc.phaseD = true
	_, err = s.ValidateTimestamp(ctx, &pb.ValidateTimestampRequest{Timestamp: 100, StartTimestamp: 50, LegacyResolution: true})
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
}

func TestDistributionServerPendingLegacyResolutionRoutedWrappers(t *testing.T) {
	t.Parallel()
	alloc := &pendingResolutionAllocator{distributionTSOAllocator: &distributionTSOAllocator{leader: true}, pendingFloor: 100}
	addr := serveDistributionTestServer(t, NewDistributionServer(distribution.NewEngine(), nil, WithDistributionTimestampAllocator(alloc)))
	routed, err := kv.NewLeaderRoutedTSOAllocator(&distributionTSOAllocator{}, distributionLeaderView(addr))
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, routed.Close()) })
	batch, err := kv.NewBatchAllocator(routed, 2)
	require.NoError(t, err)
	dynamic := kv.NewDynamicTimestampAllocator(batch)
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	require.ErrorIs(t, dynamic.ValidateDurableTimestamp(ctx, 100), kv.ErrTSOPhaseDInactive)
	require.NoError(t, dynamic.ValidateLegacyResolutionTimestamps(ctx, 50, 100))
	require.NoError(t, ctx.Err(), "inactive must not consume the retry budget before resolution")
	require.Error(t, batch.ValidateLegacyResolutionTimestamps(context.Background(), 50, 101))
}

func TestDistributionServerPendingLegacyResolutionRejectsUnsupportedAllocator(t *testing.T) {
	t.Parallel()
	s := NewDistributionServer(distribution.NewEngine(), nil, WithDistributionTimestampAllocator(&distributionTSOAllocator{}))
	_, err := s.ValidateTimestamp(context.Background(), &pb.ValidateTimestampRequest{Timestamp: 100, StartTimestamp: 50, LegacyResolution: true})
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
}

func TestDistributionServerValidateTimestamp_LeaderRoutedRPC(t *testing.T) {
	t.Parallel()
	serverAlloc := &distributionTSOAllocator{
		base:        701,
		leader:      true,
		phaseD:      true,
		phaseDFloor: 699,
	}
	addr := serveDistributionTestServer(t, NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(serverAlloc),
	))
	routed, err := kv.NewLeaderRoutedTSOAllocator(
		&distributionTSOAllocator{leader: false},
		distributionLeaderView(addr),
	)
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, routed.Close()) })

	require.NoError(t, routed.ValidateDurableTimestamp(context.Background(), 700))
	err = routed.ValidateDurableTimestamp(context.Background(), 699)
	require.ErrorIs(t, err, kv.ErrTSOTimestampInvalid)
	require.ErrorIs(t, err, kv.ErrTSOTimestampPrePhaseD)
}

func TestDistributionServerGetTimestamp_RejectsFollower(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{err: kv.ErrTSONotLeader}
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
	)
	_, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{Count: 1})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
}

func TestDistributionServerGetTimestamp_RejectsUnsupportedBatch(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), nil)
	_, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{Count: 2})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))

	_, err = s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{Count: uint32(kv.MaxTSOBatchSize + 1)})
	require.Error(t, err)
	require.Equal(t, codes.InvalidArgument, status.Code(err))
}

func TestDistributionServerGetTimestamp_RejectsMinimumWithoutReservationMetadata(t *testing.T) {
	t.Parallel()

	allocator := &distributionTSOAllocator{base: 101, leader: true}
	server := NewDistributionServer(distribution.NewEngine(), nil,
		WithDistributionTimestampAllocator(&batchOnlyDistributionTSOAllocator{delegate: allocator}))

	_, err := server.GetTimestamp(context.Background(), &pb.GetTimestampRequest{MinTimestamp: 100})
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
}

func TestDistributionServerGetTimestamp_LeaderRoutedRPC(t *testing.T) {
	t.Parallel()
	serverAlloc := &distributionTSOAllocator{base: 501, leader: true}
	addr := serveDistributionTestServer(t, NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(serverAlloc),
	))

	local := &distributionTSOAllocator{leader: false}
	routed, err := kv.NewLeaderRoutedTSOAllocator(local, distributionLeaderView(addr))
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, routed.Close()) })

	base, err := routed.NextBatchAfter(context.Background(), 4, 500)
	require.NoError(t, err)
	require.Equal(t, uint64(501), base)
	require.Equal(t, 4, serverAlloc.count)
	require.Equal(t, uint64(500), serverAlloc.min)
}

func TestDistributionServerGetTimestamp_LeaderRoutedRejectsLegacyServer(t *testing.T) {
	t.Parallel()
	addr := serveDistributionTestServer(t, NewDistributionServer(distribution.NewEngine(), nil))
	local := &distributionTSOAllocator{leader: false}
	routed, err := kv.NewLeaderRoutedTSOAllocator(local, distributionLeaderView(addr))
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, routed.Close()) })

	ctx, cancel := context.WithTimeout(context.Background(), 75*time.Millisecond)
	defer cancel()
	_, err = routed.NextBatch(ctx, 4)
	requireDeadlineExceeded(t, err)
}

// requireDeadlineExceeded asserts the call failed because its deadline expired,
// accepting either representation the deadline can take.
//
// Which one comes back is a timing detail, not a behavioural difference: if the
// context expires before the RPC is handed to gRPC the error IS
// context.DeadlineExceeded, but if the RPC is already in flight gRPC returns a
// status error with codes.DeadlineExceeded instead — and a gRPC status error
// does not satisfy errors.Is(context.DeadlineExceeded). Asserting only the
// first made this test fail about 1.5% of the time (measured 3 failures in 200
// runs) whenever the deadline happened to land on the far side of that
// boundary.
func requireDeadlineExceeded(t *testing.T, err error) {
	t.Helper()

	require.Error(t, err, "the call must fail once its deadline expires")
	if errors.Is(err, context.DeadlineExceeded) {
		return
	}
	require.Equal(t, codes.DeadlineExceeded, status.Code(err),
		"want a deadline failure in either representation, got %v", err)
}

func TestDistributionServerGetTimestamp_LeaderRoutedActivatesCutover(t *testing.T) {
	t.Parallel()
	serverAlloc := &distributionTSOAllocator{base: 701, previousFloor: 699, leader: true}
	addr := serveDistributionTestServer(t, NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(serverAlloc),
	))

	local := &distributionTSOAllocator{leader: false}
	routed, err := kv.NewLeaderRoutedTSOAllocator(
		local,
		distributionLeaderView(addr),
		kv.WithTSOCutoverActivation(),
	)
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, routed.Close()) })

	base, err := routed.Next(context.Background())
	require.NoError(t, err)
	require.Equal(t, uint64(701), base)
	require.True(t, serverAlloc.activate)
}

func serveDistributionTestServer(t *testing.T, server pb.DistributionServer) string {
	t.Helper()
	listener, err := new(net.ListenConfig).Listen(context.Background(), "tcp", "127.0.0.1:0")
	require.NoError(t, err)
	grpcServer := grpc.NewServer()
	pb.RegisterDistributionServer(grpcServer, server)
	serveErr := make(chan error, 1)
	go func() { serveErr <- grpcServer.Serve(listener) }()
	t.Cleanup(func() {
		grpcServer.Stop()
		_ = listener.Close()
		err := <-serveErr
		if err != nil {
			require.ErrorIs(t, err, grpc.ErrServerStopped)
		}
	})
	return listener.Addr().String()
}

type legacyIgnoringTimestampValidationServer struct {
	pb.UnimplementedDistributionServer
}

func (legacyIgnoringTimestampValidationServer) ValidateTimestamp(context.Context, *pb.ValidateTimestampRequest) (*pb.ValidateTimestampResponse, error) {
	return &pb.ValidateTimestampResponse{Valid: true, PhaseDActive: true}, nil
}

func TestDistributionServerPendingLegacyResolutionRejectsOldModeIgnoringServer(t *testing.T) {
	t.Parallel()
	addr := serveDistributionTestServer(t, legacyIgnoringTimestampValidationServer{})
	routed, err := kv.NewLeaderRoutedTSOAllocator(&distributionTSOAllocator{}, distributionLeaderView(addr))
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, routed.Close()) })
	require.ErrorIs(t, routed.ValidateLegacyResolutionTimestamps(context.Background(), 50, 100), kv.ErrTSOProtocolUnsupported)
}

func TestNewDistributionServer_DefaultCatalogReloadRetryPolicy(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), distribution.NewCatalogStore(store.NewMVCCStore()))
	require.Equal(t, defaultCatalogReloadRetryAttempts, s.reloadRetry.attempts)
	require.Equal(t, defaultCatalogReloadRetryInterval, s.reloadRetry.interval)
}

func TestDistributionServerListRoutes_ReadsDurableCatalog(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	catalog := distribution.NewCatalogStore(store.NewMVCCStore(), distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:                2,
			Start:                  []byte("m"),
			End:                    nil,
			GroupID:                2,
			State:                  distribution.RouteStateWriteFenced,
			ParentRouteID:          1,
			StagedVisibilityActive: true,
			MigrationJobID:         42,
			MinWriteTSExclusive:    99,
			SplitAtHLC:             100,
		},
		{
			RouteID:       1,
			Start:         []byte(""),
			End:           []byte("m"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	s := NewDistributionServer(distribution.NewEngine(), catalog)
	resp, err := s.ListRoutes(ctx, &pb.ListRoutesRequest{})
	require.NoError(t, err)

	require.Equal(t, saved.Version, resp.CatalogVersion)
	require.Len(t, resp.Routes, 2)
	require.Equal(t, uint64(1), resp.Routes[0].RouteId)
	require.Equal(t, []byte(""), resp.Routes[0].Start)
	require.Equal(t, []byte("m"), resp.Routes[0].End)
	require.Equal(t, uint64(1), resp.Routes[0].RaftGroupId)
	require.Equal(t, pb.RouteState_ROUTE_STATE_ACTIVE, resp.Routes[0].State)
	require.Equal(t, uint64(2), resp.Routes[1].RouteId)
	require.Nil(t, resp.Routes[1].End)
	require.Equal(t, pb.RouteState_ROUTE_STATE_WRITE_FENCED, resp.Routes[1].State)
	require.True(t, resp.Routes[1].StagedVisibilityActive)
	require.Equal(t, uint64(42), resp.Routes[1].MigrationJobId)
	require.Equal(t, uint64(99), resp.Routes[1].MinWriteTsExclusive)
	require.Equal(t, uint64(100), resp.Routes[1].SplitAtHlc)
}

func TestDistributionServerListRoutes_RequiresCatalog(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), nil)
	_, err := s.ListRoutes(context.Background(), &pb.ListRoutesRequest{})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.ErrorContains(t, err, errDistributionCatalogNotConfigured.Error())
}

func TestDistributionServerGetRouteOwnership_UsesExactVersionSnapshot(t *testing.T) {
	t.Parallel()

	engine := distribution.NewEngine()
	require.NoError(t, engine.ApplySnapshot(distribution.CatalogSnapshot{
		Version: 7,
		Routes: []distribution.RouteDescriptor{
			{RouteID: 1, Start: []byte("a"), End: []byte("m"), GroupID: 1, State: distribution.RouteStateActive},
			{
				RouteID:                2,
				Start:                  []byte("m"),
				End:                    nil,
				GroupID:                2,
				State:                  distribution.RouteStateMigratingTarget,
				StagedVisibilityActive: true,
				MigrationJobID:         44,
				MinWriteTSExclusive:    55,
			},
		},
	}))

	s := NewDistributionServer(engine, nil)
	resp, err := s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{
		Key:            []byte("t"),
		CatalogVersion: 7,
	})
	require.NoError(t, err)
	require.True(t, resp.Found)
	require.Equal(t, uint64(7), resp.CatalogVersion)
	require.Equal(t, uint64(2), resp.Route.RouteId)
	require.Equal(t, uint64(2), resp.Route.RaftGroupId)
	require.Equal(t, pb.RouteState_ROUTE_STATE_MIGRATING_TARGET, resp.Route.State)
	require.True(t, resp.Route.StagedVisibilityActive)
	require.Equal(t, uint64(44), resp.Route.MigrationJobId)
	require.Equal(t, uint64(55), resp.Route.MinWriteTsExclusive)

	miss, err := s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{
		Key:            []byte("0"),
		CatalogVersion: 7,
	})
	require.NoError(t, err)
	require.False(t, miss.Found)
	require.Equal(t, uint64(7), miss.CatalogVersion)
	require.Nil(t, miss.Route)
}

func TestDistributionServerGetIntersectingRoutes_UsesExactVersionSnapshot(t *testing.T) {
	t.Parallel()

	engine := distribution.NewEngine()
	require.NoError(t, engine.ApplySnapshot(distribution.CatalogSnapshot{
		Version: 9,
		Routes: []distribution.RouteDescriptor{
			{RouteID: 1, Start: []byte(""), End: []byte("g"), GroupID: 1, State: distribution.RouteStateActive},
			{RouteID: 2, Start: []byte("g"), End: []byte("m"), GroupID: 2, State: distribution.RouteStateWriteFenced},
			{RouteID: 3, Start: []byte("m"), End: nil, GroupID: 3, State: distribution.RouteStateActive},
		},
	}))

	s := NewDistributionServer(engine, nil)
	resp, err := s.GetIntersectingRoutes(context.Background(), &pb.GetIntersectingRoutesRequest{
		Start:          []byte("f"),
		End:            []byte("z"),
		CatalogVersion: 9,
	})
	require.NoError(t, err)
	require.Equal(t, uint64(9), resp.CatalogVersion)
	require.Len(t, resp.Routes, 3)
	require.Equal(t, []uint64{1, 2, 3}, []uint64{resp.Routes[0].RouteId, resp.Routes[1].RouteId, resp.Routes[2].RouteId})

	rightOpen, err := s.GetIntersectingRoutes(context.Background(), &pb.GetIntersectingRoutesRequest{
		Start:          []byte("m"),
		End:            nil,
		CatalogVersion: 9,
	})
	require.NoError(t, err)
	require.Len(t, rightOpen.Routes, 1)
	require.Equal(t, uint64(3), rightOpen.Routes[0].RouteId)
}

func TestDistributionServerOwnershipRPCs_RejectUnknownCatalogVersion(t *testing.T) {
	t.Parallel()

	engine := distribution.NewEngine()
	require.NoError(t, engine.ApplySnapshot(distribution.CatalogSnapshot{
		Version: 1,
		Routes: []distribution.RouteDescriptor{
			{RouteID: 1, Start: []byte(""), End: nil, GroupID: 1, State: distribution.RouteStateActive},
		},
	}))

	s := NewDistributionServer(engine, nil)
	_, err := s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{
		Key:            []byte("a"),
		CatalogVersion: 2,
	})
	require.Error(t, err)
	require.Equal(t, codes.NotFound, status.Code(err))
	require.ErrorContains(t, err, errDistributionCatalogVersionNotFound.Error())

	_, err = s.GetIntersectingRoutes(context.Background(), &pb.GetIntersectingRoutesRequest{
		Start:          []byte(""),
		CatalogVersion: 2,
	})
	require.Error(t, err)
	require.Equal(t, codes.NotFound, status.Code(err))
	require.ErrorContains(t, err, errDistributionCatalogVersionNotFound.Error())
}

func TestDistributionServerOwnershipRPCs_RequireEngine(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(nil, nil)
	_, err := s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{CatalogVersion: 1})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.ErrorContains(t, err, errDistributionEngineNotConfigured.Error())

	_, err = s.GetIntersectingRoutes(context.Background(), &pb.GetIntersectingRoutesRequest{CatalogVersion: 1})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.ErrorContains(t, err, errDistributionEngineNotConfigured.Error())
}

func TestDistributionServerSplitRange_Success(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:             1,
			Start:               []byte(""),
			End:                 []byte("m"),
			GroupID:             1,
			State:               distribution.RouteStateActive,
			ParentRouteID:       0,
			MinWriteTSExclusive: 99,
		},
		{
			RouteID:       2,
			Start:         []byte("m"),
			End:           nil,
			GroupID:       2,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	engine := distribution.NewEngine()
	s := NewDistributionServer(
		engine,
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
	)

	resp, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.NoError(t, err)

	require.Equal(t, uint64(2), resp.CatalogVersion)
	require.Equal(t, uint64(3), resp.Left.RouteId)
	require.Equal(t, []byte(""), resp.Left.Start)
	require.Equal(t, []byte("g"), resp.Left.End)
	require.Equal(t, uint64(1), resp.Left.RaftGroupId)
	require.Equal(t, uint64(1), resp.Left.ParentRouteId)
	require.Equal(t, uint64(99), resp.Left.MinWriteTsExclusive)
	require.Equal(t, uint64(4), resp.Right.RouteId)
	require.Equal(t, []byte("g"), resp.Right.Start)
	require.Equal(t, []byte("m"), resp.Right.End)
	require.Equal(t, uint64(1), resp.Right.RaftGroupId)
	require.Equal(t, uint64(1), resp.Right.ParentRouteId)
	require.Equal(t, uint64(99), resp.Right.MinWriteTsExclusive)
	require.NotZero(t, resp.Left.SplitAtHlc)
	require.Equal(t, resp.Left.SplitAtHlc, resp.Right.SplitAtHlc)
	require.Equal(t, uint64(99), resp.Right.MinWriteTsExclusive)

	snapshot, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	require.Equal(t, uint64(2), snapshot.Version)
	require.Len(t, snapshot.Routes, 3)
	// Catalog snapshots are sorted by range start key.
	require.Equal(t, uint64(3), snapshot.Routes[0].RouteID)
	require.Equal(t, uint64(99), snapshot.Routes[0].MinWriteTSExclusive)
	require.Equal(t, uint64(4), snapshot.Routes[1].RouteID)
	require.Equal(t, uint64(99), snapshot.Routes[1].MinWriteTSExclusive)
	require.Equal(t, uint64(2), snapshot.Routes[2].RouteID)
	require.NotZero(t, snapshot.Routes[0].SplitAtHLC)
	require.Equal(t, snapshot.Routes[0].SplitAtHLC, snapshot.Routes[1].SplitAtHLC)
	require.Equal(t, snapshot.Routes[0].SplitAtHLC, resp.Left.SplitAtHlc)

	require.Equal(t, uint64(2), engine.Version())
	leftRoute, ok := engine.GetRoute([]byte("b"))
	require.True(t, ok)
	require.Equal(t, uint64(3), leftRoute.RouteID)
	require.Equal(t, uint64(99), leftRoute.MinWriteTSExclusive)
	rightRoute, ok := engine.GetRoute([]byte("h"))
	require.True(t, ok)
	require.Equal(t, uint64(4), rightRoute.RouteID)
	require.Equal(t, uint64(99), rightRoute.MinWriteTSExclusive)
}

func TestDistributionServerSplitRange_SnapsFilesystemChunkKeyToFileBoundary(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID: 1,
			Start:   []byte("!fs|route|chk|"),
			End:     nil,
			GroupID: 1,
			State:   distribution.RouteStateActive,
		},
	})
	require.NoError(t, err)

	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
	)
	wantBoundary := fskeys.ChunkRouteKey(11, 22)

	resp, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               fskeys.ChunkKey(11, 22, 99),
	})
	require.NoError(t, err)
	require.Equal(t, wantBoundary, resp.Left.End)
	require.Equal(t, wantBoundary, resp.Right.Start)
}

func TestDistributionServerSplitRange_SnapsTxnWrappedFilesystemChunkKeyToFileBoundary(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID: 1,
			Start:   []byte("!fs|route|chk|"),
			End:     nil,
			GroupID: 1,
			State:   distribution.RouteStateActive,
		},
	})
	require.NoError(t, err)

	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
	)
	wantBoundary := fskeys.ChunkRouteKey(11, 22)
	txnChunkKey := append([]byte(kv.TxnKeyPrefix+"lock|"), fskeys.ChunkKey(11, 22, 99)...)

	resp, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               txnChunkKey,
	})
	require.NoError(t, err)
	require.Equal(t, wantBoundary, resp.Left.End)
	require.Equal(t, wantBoundary, resp.Right.Start)
}

func TestDistributionServerSplitRange_RejectsFilesystemPinnedHotspotBoundary(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	routeStart := fskeys.ChunkRouteKey(11, 22)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID: 1,
			Start:   routeStart,
			End:     fskeys.ChunkRouteKey(11, 23),
			GroupID: 1,
			State:   distribution.RouteStateActive,
		},
	})
	require.NoError(t, err)

	observer := &recordingDistributionFilesystemObserver{}
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
		WithDistributionFilesystemObserver(observer),
	)
	insideSameFile := append(append([]byte(nil), routeStart...), 0x01)

	_, err = s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               insideSameFile,
	})
	require.Error(t, err)
	require.Equal(t, codes.InvalidArgument, status.Code(err))
	require.ErrorContains(t, err, errDistributionSplitKeyAtBoundary.Error())
	require.Equal(t, []string{DistributionFilePinnedHotspotSplitBoundary}, observer.reasons)
}

func TestDistributionServerSplitRange_DoesNotRecordNonFilesystemNormalizedBoundary(t *testing.T) {
	t.Parallel()

	routeStart := []byte("queue")
	tests := []struct {
		name     string
		splitKey []byte
	}{
		{
			name:     "list item",
			splitKey: store.ListItemKey(routeStart, 1),
		},
		{
			name:     "txn wrapped list item",
			splitKey: append([]byte(kv.TxnKeyPrefix+"lock|"), store.ListItemKey(routeStart, 1)...),
		},
		{
			name:     "txn wrapped redis internal key",
			splitKey: []byte(kv.TxnKeyPrefix + "lock|!redis|string|queue"),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()

			ctx := context.Background()
			baseStore := store.NewMVCCStore()
			catalog := distribution.NewCatalogStore(baseStore)
			saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
				{
					RouteID: 1,
					Start:   routeStart,
					End:     []byte("queuez"),
					GroupID: 1,
					State:   distribution.RouteStateActive,
				},
			})
			require.NoError(t, err)

			observer := &recordingDistributionFilesystemObserver{}
			s := NewDistributionServer(
				distribution.NewEngine(),
				catalog,
				WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
				WithDistributionFilesystemObserver(observer),
			)

			_, err = s.SplitRange(ctx, &pb.SplitRangeRequest{
				ExpectedCatalogVersion: saved.Version,
				RouteId:                1,
				SplitKey:               tt.splitKey,
			})
			require.Error(t, err)
			require.Equal(t, codes.InvalidArgument, status.Code(err))
			require.ErrorContains(t, err, errDistributionSplitKeyAtBoundary.Error())
			require.Empty(t, observer.reasons)
		})
	}
}

func TestDistributionServerSplitRange_RequiresCoordinator(t *testing.T) {
	t.Parallel()

	s, version := seededDistributionServerWithoutCoordinator(t)
	_, err := s.SplitRange(context.Background(), &pb.SplitRangeRequest{
		ExpectedCatalogVersion: version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.ErrorContains(t, err, errDistributionCoordinatorRequired.Error())
}

func TestDistributionServerSplitRange_UnknownRoute(t *testing.T) {
	t.Parallel()

	s, version := seededDistributionServer(t)
	_, err := s.SplitRange(context.Background(), &pb.SplitRangeRequest{
		ExpectedCatalogVersion: version,
		RouteId:                999,
		SplitKey:               []byte("g"),
	})
	require.Error(t, err)
	require.Equal(t, codes.NotFound, status.Code(err))
	require.ErrorContains(t, err, errDistributionUnknownRoute.Error())
}

func TestDistributionServerSplitRange_InvalidSplitKey(t *testing.T) {
	t.Parallel()

	s, version := seededDistributionServer(t)
	_, err := s.SplitRange(context.Background(), &pb.SplitRangeRequest{
		ExpectedCatalogVersion: version,
		RouteId:                1,
		SplitKey:               []byte("z"),
	})
	require.Error(t, err)
	require.Equal(t, codes.InvalidArgument, status.Code(err))
	require.ErrorContains(t, err, errDistributionInvalidSplitKey.Error())
}

func TestDistributionServerSplitRange_SplitKeyAtBoundary(t *testing.T) {
	t.Parallel()

	s, version := seededDistributionServer(t)
	_, err := s.SplitRange(context.Background(), &pb.SplitRangeRequest{
		ExpectedCatalogVersion: version,
		RouteId:                1,
		SplitKey:               []byte("a"),
	})
	require.Error(t, err)
	require.Equal(t, codes.InvalidArgument, status.Code(err))
	require.ErrorContains(t, err, errDistributionSplitKeyAtBoundary.Error())
}

func TestDistributionServerSplitRange_VersionConflict(t *testing.T) {
	t.Parallel()

	s, version := seededDistributionServer(t)
	_, err := s.SplitRange(context.Background(), &pb.SplitRangeRequest{
		ExpectedCatalogVersion: version - 1,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.Error(t, err)
	require.Equal(t, codes.Aborted, status.Code(err))
	require.ErrorContains(t, err, errDistributionCatalogConflict.Error())
}

func TestDistributionServerSplitRange_RejectsLiveSplitJobOverlap(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{RouteID: 1, Start: []byte("a"), End: []byte("m"), GroupID: 1, State: distribution.RouteStateActive},
		{RouteID: 2, Start: []byte("m"), End: nil, GroupID: 2, State: distribution.RouteStateActive},
	})
	require.NoError(t, err)
	require.NoError(t, catalog.CreateSplitJob(ctx, distribution.SplitJob{
		JobID:         10,
		SourceRouteID: 1,
		SplitKey:      []byte("g"),
		TargetGroupID: 8,
		Phase:         distribution.SplitJobPhaseBackfill,
	}))

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))
	_, err = s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("c"),
	})
	require.Error(t, err)
	require.Equal(t, codes.Aborted, status.Code(err))
	require.ErrorContains(t, err, distribution.ErrSplitJobOverlap.Error())
	require.Zero(t, coordinator.dispatchCalls)
}

func TestDistributionServerSplitRange_AllowsDisjointRouteWhileSplitJobLive(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{RouteID: 3, Start: []byte("a"), End: []byte("g"), GroupID: 1, State: distribution.RouteStateActive, ParentRouteID: 1},
		{RouteID: 4, Start: []byte("g"), End: []byte("m"), GroupID: 1, State: distribution.RouteStateWriteFenced, ParentRouteID: 1},
		{RouteID: 2, Start: []byte("m"), End: nil, GroupID: 2, State: distribution.RouteStateActive},
	})
	require.NoError(t, err)
	require.NoError(t, catalog.CreateSplitJob(ctx, distribution.SplitJob{
		JobID:         10,
		SourceRouteID: 1,
		SplitKey:      []byte("g"),
		TargetGroupID: 8,
		Phase:         distribution.SplitJobPhaseFence,
	}))

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))
	resp, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                3,
		SplitKey:               []byte("c"),
	})
	require.NoError(t, err)
	require.Equal(t, uint64(2), resp.CatalogVersion)
	require.Equal(t, 1, coordinator.dispatchCalls)
	requireReadKeysContain(t, coordinator.lastReadKeys, distribution.CatalogNextSplitJobIDKey())
	requireReadKeysContain(t, coordinator.lastReadKeys, distribution.CatalogSplitJobKey(10))
}

func TestSplitJobReadFenceKeysExcludesTerminalHistory(t *testing.T) {
	t.Parallel()

	readKeys := splitJobReadFenceKeys([]distribution.SplitJob{
		{
			JobID: 10,
			Phase: distribution.SplitJobPhaseBackfill,
		},
		{
			JobID:        11,
			Phase:        distribution.SplitJobPhaseDone,
			TerminalAtMs: 1000,
		},
		{
			JobID:        12,
			Phase:        distribution.SplitJobPhaseAbandoned,
			TerminalAtMs: 1001,
		},
	})

	require.Len(t, readKeys, 2)
	requireReadKeysContain(t, readKeys, distribution.CatalogNextSplitJobIDKey())
	requireReadKeysContain(t, readKeys, distribution.CatalogSplitJobKey(10))
	requireReadKeysNotContain(t, readKeys, distribution.CatalogSplitJobHistoryKey(1000, 11))
	requireReadKeysNotContain(t, readKeys, distribution.CatalogSplitJobHistoryKey(1001, 12))
}

func TestDistributionServerSplitRange_ConflictsWhenSplitJobCreatedAfterOverlapScan(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{RouteID: 1, Start: []byte("a"), End: []byte("m"), GroupID: 1, State: distribution.RouteStateActive},
		{RouteID: 2, Start: []byte("m"), End: nil, GroupID: 2, State: distribution.RouteStateActive},
	})
	require.NoError(t, err)

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	coordinator.beforeApply = func(ctx context.Context, _ store.MVCCStore) error {
		return catalog.CreateSplitJob(ctx, distribution.SplitJob{
			JobID:         10,
			SourceRouteID: 1,
			SplitKey:      []byte("g"),
			TargetGroupID: 8,
			Phase:         distribution.SplitJobPhaseBackfill,
		})
	}
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))

	_, err = s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("c"),
	})
	require.Error(t, err)
	require.Equal(t, codes.Aborted, status.Code(err))
	require.ErrorContains(t, err, errDistributionCatalogConflict.Error())
	require.Equal(t, 1, coordinator.dispatchCalls)

	snapshot, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	require.Equal(t, saved.Version, snapshot.Version)
}

func TestDistributionServerSplitRange_UsesCoordinatorForCatalogWrites(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte(""),
			End:           []byte("m"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
		{
			RouteID:       2,
			Start:         []byte("m"),
			End:           nil,
			GroupID:       2,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	engine := distribution.NewEngine()
	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(engine, catalog, WithDistributionCoordinator(coordinator))
	readSnapshot, err := catalog.Snapshot(ctx)
	require.NoError(t, err)

	resp, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.NoError(t, err)
	require.Equal(t, uint64(2), resp.CatalogVersion)
	require.Equal(t, 1, coordinator.dispatchCalls)
	require.Equal(t, readSnapshot.ReadTS, coordinator.lastStartTS)
	require.NotZero(t, coordinator.lastRequestedCommitTS)
	require.NotZero(t, coordinator.lastCommitTS)
	require.Equal(t, coordinator.lastRequestedCommitTS, coordinator.lastCommitTS)
	require.Greater(t, coordinator.lastCommitTS, coordinator.lastStartTS)

	snapshot, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	left, found := findRouteByID(snapshot.Routes, resp.Left.RouteId)
	require.True(t, found)
	right, found := findRouteByID(snapshot.Routes, resp.Right.RouteId)
	require.True(t, found)
	require.Equal(t, coordinator.lastCommitTS, left.SplitAtHLC)
	require.Equal(t, coordinator.lastCommitTS, right.SplitAtHLC)
	require.Equal(t, coordinator.lastCommitTS, resp.Left.SplitAtHlc)
	require.Equal(t, coordinator.lastCommitTS, resp.Right.SplitAtHlc)

	changes, err := catalog.ChangesSince(ctx, saved.Version, 1)
	require.NoError(t, err)
	require.Len(t, changes.Deltas, 1)
	require.Len(t, changes.Deltas[0].Mutations, 3)
	require.Equal(t, distribution.CatalogMutationDelete, changes.Deltas[0].Mutations[0].Op)
	require.Equal(t, coordinator.lastCommitTS, changes.Deltas[0].Mutations[1].Route.SplitAtHLC)
	require.Equal(t, coordinator.lastCommitTS, changes.Deltas[0].Mutations[2].Route.SplitAtHLC)
}

func TestDistributionServerSplitRange_PhaseDReadsAtValidatedAppliedWatermark(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID: 1,
			Start:   []byte(""),
			End:     []byte("m"),
			GroupID: 1,
			State:   distribution.RouteStateActive,
		},
		{
			RouteID: 2,
			Start:   []byte("m"),
			End:     nil,
			GroupID: 2,
			State:   distribution.RouteStateActive,
		},
	})
	require.NoError(t, err)
	legacyFloor := catalog.LatestCommitTS()
	allocator := &distributionTSOAllocator{
		base:        legacyFloor + 100,
		leader:      true,
		phaseD:      true,
		phaseDFloor: legacyFloor,
	}
	coordinator := newDistributionCoordinatorStub(baseStore, true)
	coordinator.allocator = allocator
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(coordinator),
	)

	_, err = s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.NoError(t, err)
	require.Equal(t, legacyFloor, coordinator.lastStartTS)
	require.Equal(t, 1, coordinator.vouchCalls)
}

func TestDistributionServerSplitRange_UsesPersistentNextRouteID(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte(""),
			End:           []byte("m"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
		{
			RouteID:       2,
			Start:         []byte("m"),
			End:           nil,
			GroupID:       2,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	engine := distribution.NewEngine()
	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(engine, catalog, WithDistributionCoordinator(coordinator))

	first, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.NoError(t, err)
	require.Equal(t, uint64(3), first.Left.RouteId)
	require.Equal(t, uint64(4), first.Right.RouteId)

	nextRouteID, err := catalog.NextRouteID(ctx)
	require.NoError(t, err)
	require.Equal(t, uint64(5), nextRouteID)

	afterDelete, err := catalog.Save(ctx, first.CatalogVersion, []distribution.RouteDescriptor{
		{
			RouteID:       3,
			Start:         []byte(""),
			End:           []byte("g"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 1,
		},
		{
			RouteID:       2,
			Start:         []byte("m"),
			End:           nil,
			GroupID:       2,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)
	require.Equal(t, uint64(3), afterDelete.Version)

	second, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: afterDelete.Version,
		RouteId:                3,
		SplitKey:               []byte("c"),
	})
	require.NoError(t, err)
	require.Equal(t, uint64(5), second.Left.RouteId)
	require.Equal(t, uint64(6), second.Right.RouteId)
}

func TestDistributionServerSplitRange_ReturnsExactCommittedSplitVersion(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte(""),
			End:           []byte("m"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
		{
			RouteID:       2,
			Start:         []byte("m"),
			End:           nil,
			GroupID:       2,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	engine := distribution.NewEngine()
	coordinator := newDistributionCoordinatorStub(baseStore, true)
	coordinator.afterDispatch = func(ctx context.Context, st store.MVCCStore, commitTS uint64) error {
		return st.PutAt(ctx, distribution.CatalogVersionKey(), distribution.EncodeCatalogVersion(3), commitTS+1, 0)
	}
	s := NewDistributionServer(engine, catalog, WithDistributionCoordinator(coordinator))

	resp, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.NoError(t, err)
	require.Equal(t, uint64(2), resp.CatalogVersion)
	require.Equal(t, uint64(2), engine.Version())
	require.Equal(t, uint64(3), resp.Left.RouteId)
	require.Equal(t, uint64(4), resp.Right.RouteId)
	require.Equal(t, coordinator.lastCommitTS, resp.Left.SplitAtHlc)
	require.Equal(t, coordinator.lastCommitTS, resp.Right.SplitAtHlc)

	committed, err := catalog.SnapshotAt(ctx, coordinator.lastCommitTS)
	require.NoError(t, err)
	require.Equal(t, uint64(2), committed.Version)

	latest, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	require.Equal(t, uint64(3), latest.Version)
}

func TestDistributionServerApplyEngineSnapshotAcceptsNewerEngine(t *testing.T) {
	t.Parallel()

	engine := distribution.NewEngine()
	recent := distribution.CatalogSnapshot{
		Version: 3,
		Routes: []distribution.RouteDescriptor{{
			RouteID: 1,
			Start:   []byte(""),
			End:     nil,
			GroupID: 1,
			State:   distribution.RouteStateActive,
		}},
	}
	require.NoError(t, engine.ApplySnapshot(recent))

	s := NewDistributionServer(engine, nil)
	stale := recent
	stale.Version = 2
	require.NoError(t, s.applyEngineSnapshot(stale))
	require.Equal(t, uint64(3), engine.Version())
}

func TestDistributionServerSplitRange_RetriesCatalogReloadUntilVisible(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte(""),
			End:           []byte("m"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
		{
			RouteID:       2,
			Start:         []byte("m"),
			End:           nil,
			GroupID:       2,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	engine := distribution.NewEngine()
	coordinator := newDistributionCoordinatorStub(baseStore, true)
	coordinator.asyncApplyDelay = 15 * time.Millisecond
	coordinator.asyncApplyDone = make(chan error, 1)
	s := NewDistributionServer(engine, catalog, WithDistributionCoordinator(coordinator))

	resp, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.NoError(t, err)
	require.Equal(t, uint64(2), resp.CatalogVersion)

	applyErr := testutil.Recv(t, coordinator.asyncApplyDone, time.Second, "timed out waiting for async split apply")
	require.NoError(t, applyErr)
}

func TestDistributionServerSplitRange_RequiresCatalogLeaderWhenCoordinatorConfigured(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte(""),
			End:           nil,
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, false)),
	)
	_, err = s.SplitRange(ctx, &pb.SplitRangeRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
	})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.ErrorContains(t, err, errDistributionNotLeader.Error())
}

func TestBuildCatalogSplitOps_UsesSurgicalSplitMutations(t *testing.T) {
	t.Parallel()

	left := distribution.RouteDescriptor{
		RouteID:       3,
		Start:         []byte(""),
		End:           []byte("g"),
		GroupID:       1,
		State:         distribution.RouteStateActive,
		ParentRouteID: 1,
	}
	right := distribution.RouteDescriptor{
		RouteID:       4,
		Start:         []byte("g"),
		End:           []byte("m"),
		GroupID:       1,
		State:         distribution.RouteStateActive,
		ParentRouteID: 1,
	}

	ops, err := buildCatalogSplitOps(1, left, right, 2, 5, false)
	require.NoError(t, err)
	require.Len(t, ops, 5)
	require.Equal(t, kv.Del, ops[0].Op)
	require.Equal(t, distribution.CatalogRouteKey(1), ops[0].Key)
	require.Equal(t, kv.Put, ops[1].Op)
	require.Equal(t, distribution.CatalogRouteKey(3), ops[1].Key)
	require.Equal(t, kv.Put, ops[2].Op)
	require.Equal(t, distribution.CatalogRouteKey(4), ops[2].Key)
	require.Equal(t, kv.Put, ops[3].Op)
	require.Equal(t, distribution.CatalogVersionKey(), ops[3].Key)
	require.Equal(t, kv.Put, ops[4].Op)
	require.Equal(t, distribution.CatalogNextRouteIDKey(), ops[4].Key)
	nextRouteID, err := distribution.DecodeCatalogNextRouteID(ops[4].Value)
	require.NoError(t, err)
	require.Equal(t, uint64(5), nextRouteID)
}

func seededDistributionServer(t *testing.T) (*DistributionServer, uint64) {
	t.Helper()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte("a"),
			End:           []byte("m"),
			GroupID:       7,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	return NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
	), saved.Version
}

func seededDistributionServerWithoutCoordinator(t *testing.T) (*DistributionServer, uint64) {
	t.Helper()

	ctx := context.Background()
	catalog := distribution.NewCatalogStore(store.NewMVCCStore())
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte("a"),
			End:           []byte("m"),
			GroupID:       7,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)

	return NewDistributionServer(distribution.NewEngine(), catalog), saved.Version
}

type distributionCoordinatorStub struct {
	store                 store.MVCCStore
	allocator             kv.TimestampAllocator
	leader                bool
	clock                 *kv.HLC
	nextTS                uint64
	lastStartTS           uint64
	lastCommitTS          uint64
	lastRequestedCommitTS uint64
	lastReadKeys          [][]byte
	beforeApply           func(context.Context, store.MVCCStore) error
	afterDispatch         func(context.Context, store.MVCCStore, uint64) error
	asyncApplyDone        chan error
	asyncApplyDelay       time.Duration
	dispatchCalls         int
	vouchCalls            int
	// dispatchErr, when set, fails every Dispatch so callers' retry and
	// error-propagation paths can be exercised.
	dispatchErr error
	// timestampNext/timestampErr/timestampCalls drive the split-job runner's
	// direct timestamp probes, which do not go through Dispatch.
	timestampNext  uint64
	timestampErr   error
	timestampCalls int
}

func (s *distributionCoordinatorStub) TimestampAllocator() kv.TimestampAllocator {
	if s.allocator != nil {
		return s.allocator
	}
	// With no explicit allocator the stub allocates for itself, so tests that
	// drive timestampNext / assert on timestampCalls see their own values
	// rather than a real clock.
	return s
}

func (s *distributionCoordinatorStub) VouchAppliedReadTimestamp(uint64, kv.AppliedReadTimestampVoucherRef) error {
	s.vouchCalls++
	return nil
}

func newDistributionCoordinatorStub(st store.MVCCStore, leader bool) *distributionCoordinatorStub {
	return &distributionCoordinatorStub{
		store:  st,
		leader: leader,
		clock:  kv.NewHLC(),
	}
}

func (s *distributionCoordinatorStub) Dispatch(ctx context.Context, reqs *kv.OperationGroup[kv.OP]) (*kv.CoordinateResponse, error) {
	if err := s.validateDispatch(reqs); err != nil {
		return nil, err
	}
	if s.dispatchErr != nil {
		s.dispatchCalls++
		return nil, s.dispatchErr
	}
	s.dispatchCalls++
	s.lastRequestedCommitTS = reqs.CommitTS
	startTS, commitTS := s.nextTimestamps(reqs.StartTS, reqs.CommitTS)
	s.lastStartTS = startTS
	s.lastCommitTS = commitTS
	readKeys := cloneDistributionReadKeys(reqs.ReadKeys)
	s.lastReadKeys = readKeys

	if err := kv.ValidateElemCommitTSPatches(reqs.Elems, commitTS); err != nil {
		return nil, err
	}
	mutations, err := coordinatorStubMutations(reqs.Elems, commitTS)
	if err != nil {
		return nil, err
	}
	if s.asyncApplyDelay > 0 {
		done := s.asyncApplyDone
		delay := s.asyncApplyDelay
		go func() {
			time.Sleep(delay)
			err := s.applyDispatch(ctx, mutations, readKeys, startTS, commitTS)
			if done != nil {
				done <- err
			}
		}()
		return &kv.CoordinateResponse{CommitIndex: commitTS, CommitTS: commitTS}, nil
	}
	if err := s.applyDispatch(ctx, mutations, readKeys, startTS, commitTS); err != nil {
		return nil, err
	}
	return &kv.CoordinateResponse{CommitIndex: commitTS, CommitTS: commitTS}, nil
}

func (s *distributionCoordinatorStub) validateDispatch(reqs *kv.OperationGroup[kv.OP]) error {
	if !s.leader {
		return kv.ErrLeaderNotFound
	}
	if reqs == nil || len(reqs.Elems) == 0 || !reqs.IsTxn {
		return kv.ErrInvalidRequest
	}
	return nil
}

func (s *distributionCoordinatorStub) nextTimestamps(startTS uint64, requestedCommitTS uint64) (uint64, uint64) {
	if requestedCommitTS != 0 {
		if s.clock != nil {
			s.clock.Observe(requestedCommitTS)
		}
		return startTS, requestedCommitTS
	}
	if s.nextTS == 0 {
		s.nextTS = s.store.LastCommitTS() + 1
	}
	commitTS := s.nextTS
	if startTS > 0 && commitTS <= startTS {
		commitTS = startTS + 1
	}
	s.nextTS = commitTS + 1
	return startTS, commitTS
}

func (s *distributionCoordinatorStub) applyDispatch(
	ctx context.Context,
	mutations []*store.KVPairMutation,
	readKeys [][]byte,
	startTS uint64,
	commitTS uint64,
) error {
	if s.beforeApply != nil {
		if err := s.beforeApply(ctx, s.store); err != nil {
			return err
		}
	}
	if err := s.store.ApplyMutations(ctx, mutations, readKeys, startTS, commitTS); err != nil {
		return err
	}
	if s.afterDispatch != nil {
		if err := s.afterDispatch(ctx, s.store, commitTS); err != nil {
			return err
		}
	}
	return nil
}

func cloneDistributionReadKeys(in [][]byte) [][]byte {
	if len(in) == 0 {
		return nil
	}
	out := make([][]byte, len(in))
	for i := range in {
		out[i] = distribution.CloneBytes(in[i])
	}
	return out
}

func requireReadKeysContain(t *testing.T, readKeys [][]byte, want []byte) {
	t.Helper()
	for _, key := range readKeys {
		if bytes.Equal(key, want) {
			return
		}
	}
	t.Fatalf("expected read keys to contain %q, got %q", want, readKeys)
}

func requireReadKeysNotContain(t *testing.T, readKeys [][]byte, want []byte) {
	t.Helper()
	for _, key := range readKeys {
		if bytes.Equal(key, want) {
			t.Fatalf("expected read keys not to contain %q, got %q", want, readKeys)
		}
	}
}

func coordinatorStubMutations(elems []*kv.Elem[kv.OP], commitTS uint64) ([]*store.KVPairMutation, error) {
	mutations := make([]*store.KVPairMutation, 0, len(elems))
	for _, elem := range elems {
		mutation, err := coordinatorStubMutation(elem, commitTS)
		if err != nil {
			return nil, err
		}
		mutations = append(mutations, mutation)
	}
	return mutations, nil
}

func coordinatorStubMutation(elem *kv.Elem[kv.OP], commitTS uint64) (*store.KVPairMutation, error) {
	if elem == nil {
		return nil, kv.ErrInvalidRequest
	}
	switch elem.Op {
	case kv.Put:
		value := distribution.CloneBytes(elem.Value)
		if elem.CommitTSValueOffset != 0 {
			binary.BigEndian.PutUint64(value[elem.CommitTSValueOffset:elem.CommitTSValueOffset+8], commitTS)
		}
		return &store.KVPairMutation{
			Op:    store.OpTypePut,
			Key:   distribution.CloneBytes(elem.Key),
			Value: value,
		}, nil
	case kv.Del:
		return &store.KVPairMutation{
			Op:  store.OpTypeDelete,
			Key: distribution.CloneBytes(elem.Key),
		}, nil
	case kv.DelPrefix:
		return nil, kv.ErrInvalidRequest
	default:
		return nil, kv.ErrInvalidRequest
	}
}

func (s *distributionCoordinatorStub) IsLeader() bool {
	return s.leader
}

func (s *distributionCoordinatorStub) VerifyLeader(context.Context) error {
	if !s.leader {
		return kv.ErrLeaderNotFound
	}
	return nil
}

func (s *distributionCoordinatorStub) RaftLeader() string {
	return ""
}

func (s *distributionCoordinatorStub) IsLeaderForKey(_ []byte) bool {
	return s.leader
}

func (s *distributionCoordinatorStub) VerifyLeaderForKey(_ context.Context, _ []byte) error {
	if !s.leader {
		return kv.ErrLeaderNotFound
	}
	return nil
}

func (s *distributionCoordinatorStub) RaftLeaderForKey(_ []byte) string {
	return ""
}

func (s *distributionCoordinatorStub) Clock() *kv.HLC {
	return s.clock
}

func (s *distributionCoordinatorStub) LinearizableRead(_ context.Context) (uint64, error) {
	return 0, nil
}

func (s *distributionCoordinatorStub) LeaseRead(ctx context.Context) (uint64, error) {
	return s.LinearizableRead(ctx)
}

func (s *distributionCoordinatorStub) LeaseReadForKey(ctx context.Context, _ []byte) (uint64, error) {
	return s.LinearizableRead(ctx)
}

type distributionTSOAllocator struct {
	base           uint64
	previousFloor  uint64
	count          int
	min            uint64
	err            error
	leader         bool
	activate       bool
	activatePhaseD bool
	cutover        bool
	phaseD         bool
	phaseDFloor    uint64
}

type batchOnlyDistributionTSOAllocator struct {
	delegate *distributionTSOAllocator
}

func (a *batchOnlyDistributionTSOAllocator) Next(ctx context.Context) (uint64, error) {
	return a.delegate.Next(ctx)
}

func (a *batchOnlyDistributionTSOAllocator) NextBatch(ctx context.Context, n int) (uint64, error) {
	return a.delegate.NextBatch(ctx, n)
}

func (a *batchOnlyDistributionTSOAllocator) IsLeader() bool {
	return a.delegate.IsLeader()
}

func (a *batchOnlyDistributionTSOAllocator) RunLeaseRenewal(ctx context.Context) {
	a.delegate.RunLeaseRenewal(ctx)
}

func (a *distributionTSOAllocator) Next(ctx context.Context) (uint64, error) {
	return a.NextBatch(ctx, 1)
}

func (a *distributionTSOAllocator) NextBatch(_ context.Context, n int) (uint64, error) {
	a.count = n
	if a.err != nil {
		return 0, a.err
	}
	return a.base, nil
}

func (a *distributionTSOAllocator) NextBatchAfter(_ context.Context, n int, min uint64) (uint64, error) {
	a.count = n
	a.min = min
	if a.err != nil {
		return 0, a.err
	}
	return a.base, nil
}

func (a *distributionTSOAllocator) ReserveBatchAfter(
	_ context.Context,
	n int,
	min uint64,
	activate bool,
	activatePhaseD bool,
) (kv.TSOReservation, error) {
	a.count = n
	a.min = min
	a.activate = activate
	a.activatePhaseD = activatePhaseD
	if a.err != nil {
		return kv.TSOReservation{}, a.err
	}
	if activate {
		a.cutover = true
	}
	if activatePhaseD {
		a.phaseD = true
		a.phaseDFloor = a.previousFloor
	}
	return kv.TSOReservation{
		Base:                    a.base,
		Count:                   n,
		PreviousAllocationFloor: a.previousFloor,
		CutoverActive:           a.cutover,
		PhaseDActive:            a.phaseD,
		PhaseDFloor:             a.phaseDFloor,
	}, nil
}

func (a *distributionTSOAllocator) ValidateDurableTimestamp(_ context.Context, timestamp uint64) error {
	if a.err != nil {
		return a.err
	}
	if !a.phaseD || timestamp == 0 || timestamp > a.base {
		return kv.ErrTSOTimestampInvalid
	}
	if timestamp <= a.phaseDFloor {
		return stderrors.Join(kv.ErrTSOTimestampInvalid, kv.ErrTSOTimestampPrePhaseD)
	}
	return nil
}

func (a *distributionTSOAllocator) PhaseDFloor() uint64 { return a.phaseDFloor }

func (a *distributionTSOAllocator) AllocationFloor() uint64 { return a.base }

func (a *distributionTSOAllocator) CutoverActive() bool { return a.cutover }

func (a *distributionTSOAllocator) PhaseDActive() bool { return a.phaseD }

func (a *distributionTSOAllocator) PhaseDRequired() bool { return a.phaseD }

func (a *distributionTSOAllocator) IsLeader() bool { return a.leader }

func (a *distributionTSOAllocator) RunLeaseRenewal(ctx context.Context) {
	<-ctx.Done()
}

// distributionLeaderView reports a follower whose leader is at addr.
func distributionLeaderView(addr string) *raftenginetest.StaticLeaderView {
	return &raftenginetest.StaticLeaderView{
		StateValue:  raftengine.StateFollower,
		LeaderValue: raftengine.LeaderInfo{ID: "leader", Address: addr},
		ReadErr:     raftengine.ErrNotLeader,
	}
}

type recordingDistributionFilesystemObserver struct {
	reasons []string
}

func (o *recordingDistributionFilesystemObserver) ObserveFilePinnedHotspot(reason string) {
	o.reasons = append(o.reasons, reason)
}

// GetTimestamp's activate_cutover / activate_phase_d booleans commit one-way
// markers, and Distribution sits on the shared Raft gRPC server with no
// bearer-token interceptor of its own. Trusting the wire fields alone would let
// any caller that reaches the port drive the group-0 leader through the staged
// rollout.
func TestDistributionServerGetTimestamp_AuthorizesActivationLocally(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{base: 701, leader: true}
	var seen [][2]bool
	refuse := errors.New("local rollout does not permit this activation")
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
		WithDistributionTSOActivationGate(func(cutover, phaseD bool) error {
			seen = append(seen, [2]bool{cutover, phaseD})
			return refuse
		}),
	)

	_, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{
		Count:           1,
		ActivateCutover: true,
	})
	require.Error(t, err)
	require.Equal(t, codes.PermissionDenied, status.Code(err))
	require.Equal(t, [][2]bool{{true, false}}, seen)

	// A request that activates nothing is not gated at all.
	seen = nil
	_, err = s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{Count: 1})
	require.NoError(t, err)
	require.Empty(t, seen, "the gate is only consulted for activation requests")
}

// With the gate satisfied the activation proceeds as before.
func TestDistributionServerGetTimestamp_PermittedActivationProceeds(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{base: 701, leader: true}
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
		WithDistributionTSOActivationGate(func(bool, bool) error { return nil }),
	)

	resp, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{
		Count:           1,
		ActivateCutover: true,
		ActivatePhaseD:  true,
	})
	require.NoError(t, err)
	require.NotZero(t, resp.GetTimestamp())
}

// A marker another leader already committed is not an activation request. This
// node's mode file can still name the preceding stage until its next reload, and
// refusing would answer every reservation with PermissionDenied -- which
// isTransientTSORouteError does not retry -- stalling allocation and writes
// cluster-wide until the local configuration caught up.
func TestDistributionServerGetTimestamp_AlreadyDurableMarkerSkipsTheGate(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{base: 701, leader: true, cutover: true, phaseD: true}
	var calls int
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
		WithDistributionTSOActivationGate(func(bool, bool) error {
			calls++
			return errors.New("local rollout has not reached this stage yet")
		}),
	)

	resp, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{
		Count:           1,
		ActivateCutover: true,
		ActivatePhaseD:  true,
	})
	require.NoError(t, err)
	require.NotZero(t, resp.GetTimestamp())
	require.Zero(t, calls, "both markers are already durable, so nothing is being activated")
}

// A marker that is not durable yet is still gated, and only the pending half is
// presented to the gate.
func TestDistributionServerGetTimestamp_GatesOnlyThePendingMarker(t *testing.T) {
	t.Parallel()

	alloc := &distributionTSOAllocator{base: 701, leader: true, cutover: true}
	var seen [][2]bool
	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithDistributionTimestampAllocator(alloc),
		WithDistributionTSOActivationGate(func(cutover, phaseD bool) error {
			seen = append(seen, [2]bool{cutover, phaseD})
			return errors.New("local rollout has not reached phase d")
		}),
	)

	_, err := s.GetTimestamp(context.Background(), &pb.GetTimestampRequest{
		Count:           1,
		ActivateCutover: true,
		ActivatePhaseD:  true,
	})
	require.Error(t, err)
	require.Equal(t, codes.PermissionDenied, status.Code(err))
	require.Equal(t, [][2]bool{{false, true}}, seen,
		"cutover is already durable; only phase D is still an activation")
}

// GetRouteOwnership answers the historical owner of a key, so it has to
// normalize the same way GetRoute does. An internal storage key -- here a
// filesystem chunk -- routes by its logical !fs|route|chk| key, and the raw
// !fs|chk| bytes sort into a different route entirely. Without normalization
// the RPC reports the raw-prefix owner rather than the group that owned the
// key at that catalog version.
func TestDistributionServerGetRouteOwnership_NormalizesFilesystemChunkKeys(t *testing.T) {
	t.Parallel()

	home := uint64(11)
	inode := uint64(22)
	routeKey := fskeys.ChunkRouteKey(home, inode)
	engine := distribution.NewEngine()
	require.NoError(t, engine.ApplySnapshot(distribution.CatalogSnapshot{
		Version: 3,
		Routes: []distribution.RouteDescriptor{
			{RouteID: 1, Start: []byte(""), End: routeKey, GroupID: 1, State: distribution.RouteStateActive},
			{RouteID: 2, Start: routeKey, End: nil, GroupID: 2, State: distribution.RouteStateActive},
		},
	}))

	s := NewDistributionServer(engine, nil)
	resp, err := s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{
		Key:            fskeys.ChunkKey(home, inode, 99),
		CatalogVersion: 3,
	})
	require.NoError(t, err)
	require.True(t, resp.Found)
	require.Equal(t, uint64(2), resp.Route.RaftGroupId,
		"the chunk must resolve to its logical route owner, not the raw-prefix owner")
	require.Equal(t, uint64(2), resp.Route.RouteId)
}

func TestDistributionServerGetRouteOwnership_NormalizesS3BucketAuxiliaryKeys(t *testing.T) {
	t.Parallel()

	bucket := "bucket-a"
	routeKey := s3keys.RoutePrefixForBucketAnyGeneration(bucket)
	engine := distribution.NewEngine()
	require.NoError(t, engine.ApplySnapshot(distribution.CatalogSnapshot{
		Version: 3,
		Routes: []distribution.RouteDescriptor{
			{RouteID: 1, Start: []byte(""), End: routeKey, GroupID: 1, State: distribution.RouteStateActive},
			{RouteID: 2, Start: routeKey, End: nil, GroupID: 2, State: distribution.RouteStateActive},
		},
	}))

	s := NewDistributionServer(engine, nil)
	for _, key := range [][]byte{
		s3keys.BucketMetaKey(bucket),
		s3keys.BucketGenerationKey(bucket),
	} {
		resp, err := s.GetRouteOwnership(context.Background(), &pb.GetRouteOwnershipRequest{
			Key:            key,
			CatalogVersion: 3,
		})
		require.NoError(t, err)
		require.True(t, resp.Found)
		require.Equal(t, uint64(2), resp.Route.RaftGroupId,
			"bucket auxiliary keys must resolve to the bucket route owner, not the raw-prefix owner")
		require.Equal(t, uint64(2), resp.Route.RouteId)
	}
}

func TestDistributionServerPinReadTSWithoutTrackerReturnsReleasableToken(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), nil)
	token := s.pinReadTS(10)
	require.NotNil(t, token)
	require.NotPanics(t, func() {
		token.Release()
	})

	var nilServer *DistributionServer
	nilToken := nilServer.pinReadTS(10)
	require.NotNil(t, nilToken)
	require.NotPanics(t, func() {
		nilToken.Release()
	})
}

func TestDistributionServerGetSplitMigrationCapabilityReportsNotReadyUntilRunnerReady(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), nil)
	resp, err := s.GetSplitMigrationCapability(context.Background(), &pb.GetSplitMigrationCapabilityRequest{})
	require.NoError(t, err)
	require.False(t, resp.GetMigrationCapable())
	require.NotContains(t, resp.GetCapabilities(), splitMigrationCapabilityV2)
}

func TestDistributionServerGetSplitMigrationCapabilityReportsReadyWhenRunnerReady(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), nil, WithSplitJobRunnerReady())
	resp, err := s.GetSplitMigrationCapability(context.Background(), &pb.GetSplitMigrationCapabilityRequest{})
	require.NoError(t, err)
	require.True(t, resp.GetMigrationCapable())
	require.Contains(t, resp.GetCapabilities(), splitMigrationCapabilityV2)
}

func TestDistributionServerGetSplitMigrationCapabilityRespectsReadinessGate(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(
		distribution.NewEngine(),
		nil,
		WithSplitJobRunnerReady(),
		WithSplitJobRunnerReadinessGate(func(context.Context) error {
			return status.Error(codes.FailedPrecondition, "migration opcode disabled")
		}),
	)
	resp, err := s.GetSplitMigrationCapability(context.Background(), &pb.GetSplitMigrationCapabilityRequest{})
	require.NoError(t, err)
	require.False(t, resp.GetMigrationCapable())
	require.NotContains(t, resp.GetCapabilities(), splitMigrationCapabilityV2)
}

func TestDistributionServerSplitJobRunnerReadinessFollowsRuntime(t *testing.T) {
	t.Parallel()

	baseStore := store.NewMVCCStore()
	var gateOpen atomic.Bool
	s := NewDistributionServer(distribution.NewEngine(), distribution.NewCatalogStore(baseStore),
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, false)),
		WithSplitPromotionClientFactory(func(context.Context, distribution.SplitJob) (SplitPromotionClient, error) {
			return nil, nil
		}),
		WithSplitMigrationClientFactory(func(context.Context, distribution.SplitJob, uint64) (SplitMigrationClient, SplitMigrationClient, error) {
			return nil, nil, nil
		}),
		WithSplitJobRunnerReadinessGate(func(context.Context) error {
			if !gateOpen.Load() {
				return status.Error(codes.FailedPrecondition, "local gate closed")
			}
			return nil
		}),
	)
	probe := func() bool {
		resp, err := s.GetSplitMigrationCapability(context.Background(), &pb.GetSplitMigrationCapabilityRequest{})
		require.NoError(t, err)
		return resp.GetMigrationCapable()
	}
	require.False(t, probe())

	canceled, cancelBeforeStart := context.WithCancel(context.Background())
	cancelBeforeStart()
	require.NoError(t, s.RunSplitJobRunner(canceled))
	require.False(t, probe())

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- s.RunSplitJobRunner(ctx) }()
	t.Cleanup(cancel)
	require.Eventually(t, s.splitJobRunnerRunning, time.Second, time.Millisecond)
	require.False(t, probe())
	gateOpen.Store(true)
	require.True(t, probe())
	gateOpen.Store(false)
	require.False(t, probe())
	gateOpen.Store(true)
	require.True(t, probe())
	cancel()
	require.False(t, probe())
	require.NoError(t, <-done)
	require.False(t, probe())
}

func TestDistributionServerUnconfiguredSplitJobRunnerNeverAdvertisesRuntimeReadiness(t *testing.T) {
	t.Parallel()

	s := NewDistributionServer(distribution.NewEngine(), distribution.NewCatalogStore(store.NewMVCCStore()))
	require.NoError(t, s.RunSplitJobRunner(context.Background()))
	resp, err := s.GetSplitMigrationCapability(context.Background(), &pb.GetSplitMigrationCapabilityRequest{})
	require.NoError(t, err)
	require.False(t, resp.GetMigrationCapable())
}

func TestDistributionServerStartSplitMigration_FailsClosedUntilCapabilityGate(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))

	_, err := s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
		ExpectedCatalogVersion: 1,
		RouteId:                1,
		SplitKey:               []byte("g"),
		TargetGroupId:          2,
	})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.ErrorContains(t, err, errDistributionClusterNotReady.Error())
	require.Zero(t, coordinator.dispatchCalls)

	jobs, listErr := catalog.ListSplitJobs(ctx)
	require.NoError(t, listErr)
	require.Empty(t, jobs)
}

func TestDistributionServerStartSplitMigrationReturnsCapabilityGateError(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(coordinator),
		WithSplitMigrationCapabilityGate(func(context.Context) error {
			return status.Error(codes.Unavailable, "split migration capability not ready")
		}),
	)

	_, err := s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
		ExpectedCatalogVersion: 1,
		RouteId:                1,
		SplitKey:               []byte("g"),
		TargetGroupId:          2,
	})
	require.Error(t, err)
	require.Equal(t, codes.Unavailable, status.Code(err))
	require.ErrorContains(t, err, "split migration capability not ready")
	require.Zero(t, coordinator.dispatchCalls)
}

func TestDistributionServerStartSplitMigrationCapabilityGateRunsOutsideCatalogLock(t *testing.T) {
	// Not parallel: its deadline/liveness budget is sized for a quiet
	// process, and parallel peers on a loaded runner can exhaust it.
	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID:       1,
		Start:         []byte("a"),
		End:           []byte("m"),
		GroupID:       1,
		State:         distribution.RouteStateActive,
		ParentRouteID: 0,
	}})
	require.NoError(t, err)

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	gateEntered := make(chan struct{})
	releaseGate := make(chan struct{})
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(coordinator),
		WithDistributionKnownRaftGroups(1, 2),
		WithSplitMigrationCapabilityGate(func(context.Context) error {
			close(gateEntered)
			<-releaseGate
			return status.Error(codes.Unavailable, "split migration capability not ready")
		}),
	)

	startDone := make(chan error, 1)
	go func() {
		_, err := s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
			ExpectedCatalogVersion: saved.Version,
			RouteId:                1,
			SplitKey:               []byte("g"),
			TargetGroupId:          2,
		})
		startDone <- err
	}()
	<-gateEntered

	splitDone := make(chan error, 1)
	go func() {
		_, err := s.SplitRange(ctx, &pb.SplitRangeRequest{
			ExpectedCatalogVersion: saved.Version,
			RouteId:                1,
			SplitKey:               []byte("g"),
		})
		splitDone <- err
	}()
	select {
	case err := <-splitDone:
		require.NoError(t, err)
	case <-time.After(500 * time.Millisecond):
		t.Fatal("SplitRange blocked behind StartSplitMigration capability gate")
	}

	close(releaseGate)
	err = <-startDone
	require.Error(t, err)
	require.Equal(t, codes.Unavailable, status.Code(err))
}

func TestDistributionServerStartSplitMigration_CreatesPlannedJobWhenGateOpen(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID:       1,
		Start:         []byte("a"),
		End:           []byte("m"),
		GroupID:       1,
		State:         distribution.RouteStateActive,
		ParentRouteID: 0,
	}})
	require.NoError(t, err)

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	gateCalls := 0
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(coordinator),
		WithDistributionKnownRaftGroups(1, 2),
		WithSplitMigrationCapabilityGate(func(context.Context) error {
			gateCalls++
			return nil
		}),
	)

	resp, err := s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
		TargetGroupId:          2,
	})
	require.NoError(t, err)
	require.Equal(t, saved.Version, resp.CatalogVersion)
	require.Equal(t, uint64(1), resp.JobId)
	require.Equal(t, 1, gateCalls)
	require.Equal(t, 1, coordinator.dispatchCalls)
	require.ElementsMatch(t, []string{
		string(distribution.CatalogSplitJobKey(1)),
		string(distribution.CatalogNextSplitJobIDKey()),
		string(distribution.CatalogVersionKey()),
		string(distribution.CatalogRouteKey(1)),
	}, byteSliceStrings(coordinator.lastReadKeys))

	jobs, err := catalog.ListSplitJobs(ctx)
	require.NoError(t, err)
	require.Len(t, jobs, 1)
	job := jobs[0]
	require.Equal(t, uint64(1), job.JobID)
	require.Equal(t, uint64(1), job.SourceRouteID)
	require.Equal(t, []byte("g"), job.SplitKey)
	require.Equal(t, uint64(2), job.TargetGroupID)
	require.Equal(t, distribution.SplitJobPhasePlanned, job.Phase)
	require.NotZero(t, job.StartedAtMs)
	require.NotZero(t, job.UpdatedAtMs)
	require.NotEmpty(t, job.BracketProgress)
	next, err := catalog.NextSplitJobID(ctx)
	require.NoError(t, err)
	require.Equal(t, uint64(2), next)
}

func TestDistributionServerStartSplitMigration_NormalizesFilesystemChunkSplitKey(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID: 1,
		Start:   fskeys.ChunkRouteKey(11, 21),
		End:     fskeys.ChunkRouteKey(11, 23),
		GroupID: 1,
		State:   distribution.RouteStateActive,
	}})
	require.NoError(t, err)

	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
		WithDistributionKnownRaftGroups(1, 2),
		WithSplitMigrationCapabilityGate(func(context.Context) error { return nil }),
	)
	wantBoundary := fskeys.ChunkRouteKey(11, 22)

	resp, err := s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               fskeys.ChunkKey(11, 22, 99),
		TargetGroupId:          2,
	})
	require.NoError(t, err)
	require.Equal(t, uint64(1), resp.JobId)

	jobs, err := catalog.ListSplitJobs(ctx)
	require.NoError(t, err)
	require.Len(t, jobs, 1)
	require.Equal(t, wantBoundary, jobs[0].SplitKey)
	require.NotEqual(t, fskeys.ChunkKey(11, 22, 99), jobs[0].SplitKey)
}

func TestDistributionServerStartSplitMigration_RejectsUnknownTargetGroup(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID:       1,
		Start:         []byte("a"),
		End:           []byte("m"),
		GroupID:       1,
		State:         distribution.RouteStateActive,
		ParentRouteID: 0,
	}})
	require.NoError(t, err)

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(coordinator),
		WithDistributionKnownRaftGroups(1, 2),
		WithSplitMigrationCapabilityGate(func(context.Context) error { return nil }),
	)

	_, err = s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
		TargetGroupId:          3,
	})
	require.Error(t, err)
	require.Equal(t, codes.InvalidArgument, status.Code(err))
	require.ErrorContains(t, err, errDistributionUnknownTargetGroup.Error())
	require.Zero(t, coordinator.dispatchCalls)
}

func TestDistributionServerStartSplitMigration_RejectsNonActiveSourceRoute(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	for _, tc := range []struct {
		name  string
		state distribution.RouteState
	}{
		{name: "write_fenced", state: distribution.RouteStateWriteFenced},
		{name: "migrating_source", state: distribution.RouteStateMigratingSource},
		{name: "migrating_target", state: distribution.RouteStateMigratingTarget},
	} {
		t.Run(tc.name, func(t *testing.T) {
			baseStore := store.NewMVCCStore()
			catalog := distribution.NewCatalogStore(baseStore)
			saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
				RouteID:       1,
				Start:         []byte("a"),
				End:           []byte("m"),
				GroupID:       1,
				State:         tc.state,
				ParentRouteID: 0,
			}})
			require.NoError(t, err)

			coordinator := newDistributionCoordinatorStub(baseStore, true)
			s := NewDistributionServer(
				distribution.NewEngine(),
				catalog,
				WithDistributionCoordinator(coordinator),
				WithDistributionKnownRaftGroups(1, 2),
				WithSplitMigrationCapabilityGate(func(context.Context) error { return nil }),
			)

			_, err = s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
				ExpectedCatalogVersion: saved.Version,
				RouteId:                1,
				SplitKey:               []byte("g"),
				TargetGroupId:          2,
			})
			require.Error(t, err)
			require.Equal(t, codes.FailedPrecondition, status.Code(err))
			require.ErrorContains(t, err, errDistributionSourceRouteNotActive.Error())
			require.Zero(t, coordinator.dispatchCalls)

			jobs, listErr := catalog.ListSplitJobs(ctx)
			require.NoError(t, listErr)
			require.Empty(t, jobs)
		})
	}
}

func TestDistributionServerStartSplitMigration_RejectsSecondLiveJob(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{
		{
			RouteID:       1,
			Start:         []byte("a"),
			End:           []byte("m"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
		{
			RouteID:       2,
			Start:         []byte("m"),
			End:           nil,
			GroupID:       2,
			State:         distribution.RouteStateActive,
			ParentRouteID: 0,
		},
	})
	require.NoError(t, err)
	require.NoError(t, catalog.CreateSplitJob(ctx, distribution.SplitJob{
		JobID:         1,
		SourceRouteID: 2,
		SplitKey:      []byte("t"),
		TargetGroupID: 3,
		Phase:         distribution.SplitJobPhaseBackfill,
		StartedAtMs:   1000,
		UpdatedAtMs:   1000,
	}))

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(coordinator),
		WithDistributionKnownRaftGroups(1, 2, 3, 4),
		WithSplitMigrationCapabilityGate(func(context.Context) error { return nil }),
	)

	_, err = s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
		ExpectedCatalogVersion: saved.Version,
		RouteId:                1,
		SplitKey:               []byte("g"),
		TargetGroupId:          4,
	})
	require.Error(t, err)
	require.Equal(t, codes.ResourceExhausted, status.Code(err))
	require.ErrorContains(t, err, distribution.ErrTooManyInFlightSplitJobs.Error())
	require.Zero(t, coordinator.dispatchCalls)
}

func TestDistributionServerStartSplitMigration_RejectsReservedMigrationRange(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	for _, tc := range []struct {
		name     string
		splitKey []byte
		end      []byte
	}{
		{name: "dist catalog", splitKey: []byte("!dist|"), end: nil},
		{name: "dist staged catalog", splitKey: []byte("!dist|migstage|"), end: nil},
		{name: "migration staged", splitKey: []byte("!migstage|ready|1"), end: nil},
		{name: "migration tracker", splitKey: []byte("!migwrite|"), end: nil},
		{name: "migration fence", splitKey: []byte("!migfence|"), end: nil},
	} {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			baseStore := store.NewMVCCStore()
			catalog := distribution.NewCatalogStore(baseStore)
			saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
				RouteID:       1,
				Start:         []byte(""),
				End:           tc.end,
				GroupID:       1,
				State:         distribution.RouteStateActive,
				ParentRouteID: 0,
			}})
			require.NoError(t, err)

			coordinator := newDistributionCoordinatorStub(baseStore, true)
			s := NewDistributionServer(
				distribution.NewEngine(),
				catalog,
				WithDistributionCoordinator(coordinator),
				WithDistributionKnownRaftGroups(1, 2),
				WithSplitMigrationCapabilityGate(func(context.Context) error { return nil }),
			)

			_, err = s.StartSplitMigration(ctx, &pb.StartSplitMigrationRequest{
				ExpectedCatalogVersion: saved.Version,
				RouteId:                1,
				SplitKey:               tc.splitKey,
				TargetGroupId:          2,
			})
			require.Error(t, err)
			require.Equal(t, codes.InvalidArgument, status.Code(err))
			require.ErrorContains(t, err, distribution.ErrMigrationReservedRange.Error())
			require.Zero(t, coordinator.dispatchCalls)

			jobs, listErr := catalog.ListSplitJobs(ctx)
			require.NoError(t, listErr)
			require.Empty(t, jobs)
		})
	}
}

func TestDistributionServerSplitJobRPCs_ReadAndListCatalogJobs(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	catalog := distribution.NewCatalogStore(store.NewMVCCStore())
	live := sampleDistributionSplitJob(10)
	live.Phase = distribution.SplitJobPhaseDeltaCopy
	require.NoError(t, catalog.CreateSplitJob(ctx, live))
	history := sampleDistributionSplitJob(11)
	history.Phase = distribution.SplitJobPhaseDone
	history.TerminalAtMs = 2000
	require.NoError(t, catalog.CreateSplitJob(ctx, history))
	require.NoError(t, catalog.MoveSplitJobToHistory(ctx, history, history))

	s := NewDistributionServer(distribution.NewEngine(), catalog)
	got, err := s.GetSplitJob(ctx, &pb.GetSplitJobRequest{JobId: live.JobID})
	require.NoError(t, err)
	require.Equal(t, live.JobID, got.Job.JobId)
	require.Equal(t, pb.SplitJobPhase_SPLIT_JOB_PHASE_DELTA_COPY, got.Job.Phase)

	listAll, err := s.ListSplitJobs(ctx, &pb.ListSplitJobsRequest{})
	require.NoError(t, err)
	require.Len(t, listAll.Jobs, 2)
	require.Equal(t, []uint64{live.JobID, history.JobID}, []uint64{listAll.Jobs[0].JobId, listAll.Jobs[1].JobId})

	listDone, err := s.ListSplitJobs(ctx, &pb.ListSplitJobsRequest{Phase: "done"})
	require.NoError(t, err)
	require.Len(t, listDone.Jobs, 1)
	require.Equal(t, history.JobID, listDone.Jobs[0].JobId)

	_, err = s.ListSplitJobs(ctx, &pb.ListSplitJobsRequest{Phase: "not-a-phase"})
	require.Error(t, err)
	require.Equal(t, codes.InvalidArgument, status.Code(err))
}

func TestDistributionServerListSplitJobs_PaginatesNewestHistory(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	catalog := distribution.NewCatalogStore(store.NewMVCCStore())
	for jobID, terminalAtMs := uint64(1), int64(1001); jobID <= 205; jobID, terminalAtMs = jobID+1, terminalAtMs+1 {
		job := sampleDistributionSplitJob(jobID)
		job.Phase = distribution.SplitJobPhaseDone
		job.TerminalAtMs = terminalAtMs
		job.UpdatedAtMs = job.TerminalAtMs
		require.NoError(t, catalog.CreateSplitJob(ctx, job))
		require.NoError(t, catalog.MoveSplitJobToHistory(ctx, job, job))
	}

	s := NewDistributionServer(distribution.NewEngine(), catalog)
	first, err := s.ListSplitJobs(ctx, &pb.ListSplitJobsRequest{})
	require.NoError(t, err)
	require.Len(t, first.Jobs, listSplitJobsDefaultPageSize)
	require.NotEmpty(t, first.NextPageCursor)
	require.Equal(t, uint64(205), first.Jobs[0].JobId)
	require.Equal(t, uint64(6), first.Jobs[len(first.Jobs)-1].JobId)

	second, err := s.ListSplitJobs(ctx, &pb.ListSplitJobsRequest{PageCursor: first.NextPageCursor})
	require.NoError(t, err)
	require.Empty(t, second.NextPageCursor)
	require.Equal(t, []uint64{5, 4, 3, 2, 1}, splitJobIDs(second.Jobs))
}

func TestDistributionServerListSplitJobs_RejectsInvalidCursor(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	catalog := distribution.NewCatalogStore(store.NewMVCCStore())
	job := sampleDistributionSplitJob(1)
	job.Phase = distribution.SplitJobPhaseDone
	job.TerminalAtMs = 1000
	require.NoError(t, catalog.CreateSplitJob(ctx, job))
	require.NoError(t, catalog.MoveSplitJobToHistory(ctx, job, job))

	s := NewDistributionServer(distribution.NewEngine(), catalog)
	_, err := s.ListSplitJobs(ctx, &pb.ListSplitJobsRequest{PageCursor: []byte("bad")})
	require.Error(t, err)
	require.Equal(t, codes.InvalidArgument, status.Code(err))

	missing := sampleDistributionSplitJob(999)
	missing.TerminalAtMs = 9999
	page, err := s.ListSplitJobs(ctx, &pb.ListSplitJobsRequest{PageCursor: encodeSplitJobListCursor(missing)})
	require.NoError(t, err)
	require.Equal(t, []uint64{1}, splitJobIDs(page.Jobs))
}

func TestDistributionServerRetrySplitJob_UsesCoordinatorCAS(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	job := sampleDistributionSplitJob(12)
	job.Phase = distribution.SplitJobPhaseFailed
	job.RetryPhase = distribution.SplitJobPhaseFence
	job.LastError = "retry me"
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))
	_, err := s.RetrySplitJob(ctx, &pb.RetrySplitJobRequest{JobId: job.JobID})
	require.NoError(t, err)
	require.Equal(t, 1, coordinator.dispatchCalls)

	got, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, distribution.SplitJobPhaseFence, got.Phase)
	require.Equal(t, distribution.SplitJobPhaseNone, got.RetryPhase)
	require.Empty(t, got.LastError)
}

func TestDistributionServerRetrySplitJob_MapsDispatchLeadershipLoss(t *testing.T) {
	t.Parallel()

	tests := []struct {
		name string
		err  error
	}{
		{name: "leader not found", err: kv.ErrLeaderNotFound},
		{name: "raft not leader", err: raftengine.ErrNotLeader},
		{name: "leadership lost", err: raftengine.ErrLeadershipLost},
		{name: "transfer in progress", err: raftengine.ErrLeadershipTransferInProgress},
		{name: "wrapped grpc detail", err: errors.New("rpc error: code = Unknown desc = raft engine: leadership lost")},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			ctx := context.Background()
			baseStore := store.NewMVCCStore()
			catalog := distribution.NewCatalogStore(baseStore)
			job := sampleDistributionSplitJob(15)
			job.Phase = distribution.SplitJobPhaseFailed
			job.RetryPhase = distribution.SplitJobPhaseFence
			require.NoError(t, catalog.CreateSplitJob(ctx, job))

			coordinator := newDistributionCoordinatorStub(baseStore, true)
			coordinator.dispatchErr = tc.err
			s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))
			_, err := s.RetrySplitJob(ctx, &pb.RetrySplitJobRequest{JobId: job.JobID})
			require.Error(t, err)
			require.Equal(t, codes.FailedPrecondition, status.Code(err))
			require.ErrorContains(t, err, errDistributionNotLeader.Error())
			require.Equal(t, 1, coordinator.dispatchCalls)
		})
	}
}

func TestDistributionServerAbandonSplitJob_RecordsAbandoningViaCoordinator(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	job := sampleDistributionSplitJob(13)
	job.Phase = distribution.SplitJobPhaseFailed
	job.RetryPhase = distribution.SplitJobPhaseBackfill
	job.AbandonFromPhase = distribution.SplitJobPhaseNone
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))
	_, err := s.AbandonSplitJob(ctx, &pb.AbandonSplitJobRequest{JobId: job.JobID})
	require.NoError(t, err)
	require.Equal(t, 1, coordinator.dispatchCalls)

	got, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, distribution.SplitJobPhaseAbandoning, got.Phase)
	require.Equal(t, distribution.SplitJobPhaseNone, got.RetryPhase)
	require.Equal(t, distribution.SplitJobPhaseBackfill, got.AbandonFromPhase)
}

func TestDistributionServerCompleteSplitJobTargetPromotion_UsesCoordinatorCAS(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, promotionCompleteDistributionRoutes())
	require.NoError(t, err)
	job := promotionCompleteDistributionJob()
	require.NoError(t, catalog.CreateSplitJob(ctx, job))
	before, err := catalog.Snapshot(ctx)
	require.NoError(t, err)

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	coordinator.timestampNext = before.ReadTS + 10
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))

	snapshot, completed, err := s.completeSplitJobTargetPromotionViaCoordinator(ctx, saved.Version, job, 2000)
	require.NoError(t, err)
	require.Equal(t, saved.Version+1, snapshot.Version)
	require.True(t, completed.TargetPromotionDone)
	require.Equal(t, distribution.SplitJobPhaseCleanup, completed.Phase)
	require.Equal(t, before.ReadTS+10, completed.PromotionCompletedTS)
	require.Equal(t, int64(2000), completed.UpdatedAtMs)
	require.Zero(t, completed.TerminalAtMs)
	require.Equal(t, 1, coordinator.dispatchCalls)
	require.Equal(t, 1, coordinator.timestampCalls)
	require.Equal(t, before.ReadTS, coordinator.lastStartTS)
	require.Equal(t, completed.PromotionCompletedTS, coordinator.lastCommitTS)
	requireReadKeysContain(t, coordinator.lastReadKeys, distribution.CatalogVersionKey())
	requireReadKeysContain(t, coordinator.lastReadKeys, distribution.CatalogSplitJobKey(job.JobID))

	loadedJob, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, completed, loadedJob)

	loaded, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	target := distributionRouteByID(t, loaded.Routes, 3)
	require.False(t, target.StagedVisibilityActive)
	require.Equal(t, uint64(0), target.MigrationJobID)
	require.Equal(t, uint64(777), target.MinWriteTSExclusive)
}

func TestDistributionServerCompleteSplitJobTargetPromotion_RetryAfterCommitIsIdempotent(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, promotionCompleteDistributionRoutes())
	require.NoError(t, err)
	job := promotionCompleteDistributionJob()
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))

	firstSnapshot, firstCompleted, err := s.completeSplitJobTargetPromotionViaCoordinator(ctx, saved.Version, job, 2000)
	require.NoError(t, err)
	retrySnapshot, retryCompleted, err := s.completeSplitJobTargetPromotionViaCoordinator(ctx, saved.Version, job, 3000)
	require.NoError(t, err)
	require.Equal(t, firstSnapshot.Version, retrySnapshot.Version)
	require.Equal(t, firstCompleted, retryCompleted)
	require.Equal(t, 1, coordinator.dispatchCalls)
}

func TestDistributionServerCompleteSplitJobTargetPromotion_PersistsLegacyTerminalTime(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	routes := promotionCompleteDistributionRoutes()
	routes[1].StagedVisibilityActive = false
	routes[1].MigrationJobID = 0
	saved, err := catalog.Save(ctx, 0, routes)
	require.NoError(t, err)
	expected := promotionCompleteDistributionJob()
	legacy := distribution.CloneSplitJob(expected)
	legacy.Phase = distribution.SplitJobPhaseDone
	legacy.TargetPromotionDone = true
	legacy.PromotionCompletedTS = saved.ReadTS + 1
	require.NoError(t, catalog.CreateSplitJob(ctx, legacy))

	coordinator := newDistributionCoordinatorStub(baseStore, true)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))

	snapshot, completed, err := s.completeSplitJobTargetPromotionViaCoordinator(ctx, saved.Version, expected, 3000)
	require.NoError(t, err)
	require.Equal(t, saved.Version+1, snapshot.Version)
	require.Equal(t, int64(3000), completed.TerminalAtMs)
	require.Equal(t, int64(3000), completed.UpdatedAtMs)
	require.Equal(t, 1, coordinator.dispatchCalls)

	loaded, found, err := catalog.SplitJob(ctx, legacy.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, completed, loaded)
}

func TestDistributionServerRunSplitJobRunnerOnce_PromotesCleanupJob(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, promotionCompleteDistributionRoutes())
	require.NoError(t, err)
	job := promotionCompleteDistributionJob()
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	client := &splitPromotionClientStub{
		responses: []*pb.PromoteStagedVersionsResponse{
			{NextCursor: []byte("cursor-1")},
			{Done: true},
		},
	}
	s, _, _ := newSplitRuntimeRunner(t, baseStore, catalog, job)
	coordinator, ok := s.coordinator.(*ownershipCatalogCoordinator)
	require.True(t, ok)
	s.splitPromotionClientFactory = func(context.Context, distribution.SplitJob) (SplitPromotionClient, error) { return client, nil }

	require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
	require.Equal(t, 2, client.calls)
	require.Equal(t, job.JobID, client.requests[0].GetJobId())
	require.Empty(t, client.requests[0].GetCursor())
	require.Equal(t, defaultSplitPromotionMaxVersions, client.requests[0].GetMaxVersions())
	require.Equal(t, defaultSplitPromotionMaxBytes, client.requests[0].GetMaxBytes())
	require.Equal(t, defaultSplitPromotionMaxScanned, client.requests[0].GetMaxScannedBytes())
	require.Equal(t, []byte("cursor-1"), client.requests[1].GetCursor())
	require.Equal(t, 1, coordinator.dispatchCalls)

	loadedJob, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.True(t, loadedJob.TargetPromotionDone)
	require.Equal(t, distribution.SplitJobPhaseCleanup, loadedJob.Phase)
	require.NotZero(t, loadedJob.PromotionCompletedTS)
	require.Zero(t, loadedJob.TerminalAtMs)

	loaded, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	require.Equal(t, saved.Version+1, loaded.Version)
	target := distributionRouteByID(t, loaded.Routes, 3)
	require.False(t, target.StagedVisibilityActive)
	require.Equal(t, uint64(0), target.MigrationJobID)
	require.Equal(t, uint64(777), target.MinWriteTSExclusive)

	route, ok := s.engine.GetRoute([]byte("z"))
	require.True(t, ok)
	require.False(t, route.StagedVisibilityActive)
	require.Equal(t, uint64(0), route.MigrationJobID)
	require.Equal(t, saved.Version+1, s.engine.Version())
}

func TestDistributionServerRunSplitJobRunnerOnce_TerminalizesPromotedCleanupJob(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	routes := promotionCompleteDistributionRoutes()
	routes[1].StagedVisibilityActive = false
	routes[1].MigrationJobID = 0
	saved, err := catalog.Save(ctx, 0, routes)
	require.NoError(t, err)
	job := promotionCompleteDistributionJob()
	job.TargetPromotionDone = true
	job.PromotionCompletedTS = saved.ReadTS + 1
	job.UpdatedAtMs = 2000
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	s, _, target := newSplitRuntimeRunner(t, baseStore, catalog, job)

	for range 200 {
		require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
		current, found, loadErr := catalog.SplitJob(ctx, job.JobID)
		require.NoError(t, loadErr)
		require.True(t, found)
		if current.Phase == distribution.SplitJobPhaseDone {
			break
		}
	}
	require.Zero(t, target.calls)

	loadedJob, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, distribution.SplitJobPhaseDone, loadedJob.Phase)
	require.True(t, loadedJob.TargetPromotionDone)
	require.Equal(t, job.PromotionCompletedTS, loadedJob.PromotionCompletedTS)

	loaded, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	require.Equal(t, saved.Version, loaded.Version)
}

func TestDistributionServerRunSplitJobRunnerOnce_CompletesCrossGroupMigration(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID: 1,
		Start:   []byte("a"),
		End:     []byte("z"),
		GroupID: 1,
		State:   distribution.RouteStateActive,
	}})
	require.NoError(t, err)
	job, err := distribution.InitializeSplitJobPlan(distribution.SplitJob{
		JobID:         1,
		SourceRouteID: 1,
		SplitKey:      []byte("m"),
		TargetGroupID: 2,
	}, saved.Routes[0], time.Now().UnixMilli())
	require.NoError(t, err)
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	s, source, target := newSplitRuntimeRunner(t, baseStore, catalog, job)

	for range 200 {
		require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
		current, found, loadErr := catalog.SplitJob(ctx, job.JobID)
		require.NoError(t, loadErr)
		require.True(t, found)
		if current.Phase == distribution.SplitJobPhaseDone {
			break
		}
	}

	completed, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, distribution.SplitJobPhaseDone, completed.Phase)
	require.True(t, completed.WriteTrackerArmed)
	require.True(t, completed.PostFenceDrainCompleted)
	require.NotZero(t, completed.SnapshotTS)
	require.NotZero(t, completed.FenceTS)
	require.NotZero(t, completed.CutoverVersion)
	require.True(t, completed.TargetPromotionDone)
	require.NotEmpty(t, source.controls)
	require.NotEmpty(t, target.controls)
	require.NotEmpty(t, source.exports)
	require.True(t, completed.TransferPreflightDone)
	preflightExports := 0
	for _, req := range source.exports {
		if req.GetMaxCommitTs() == completed.TransferPreflightTS {
			require.Zero(t, req.GetMinCommitTs())
			preflightExports++
		}
	}
	require.Equal(t, len(completed.TransferPreflightProgress), preflightExports)
	require.Len(t, target.imports, len(source.exports)-preflightExports)
	require.GreaterOrEqual(t, len(source.events), 4)
	require.Equal(t, []string{"control", "guard", "locks", "timestamp"}, source.events[:4], "tracker and transfer guard barriers must precede lock drain and snapshot timestamp selection")

	finalSnapshot, err := catalog.Snapshot(ctx)
	require.NoError(t, err)
	require.Len(t, finalSnapshot.Routes, 2)
	right := distributionRouteByID(t, finalSnapshot.Routes, 3)
	require.Equal(t, uint64(2), right.GroupID)
	require.Equal(t, distribution.RouteStateActive, right.State)
	require.False(t, right.StagedVisibilityActive)
	require.Equal(t, completed.FenceTS, right.MinWriteTSExclusive)
	value, err := target.internal.store.GetAt(ctx, []byte("n"), ^uint64(0))
	require.NoError(t, err)
	require.Equal(t, []byte("v"), value, "the real import and promotion must retain source data")
	_, err = source.internal.store.GetAt(ctx, []byte("n"), ^uint64(0))
	require.ErrorIs(t, err, store.ErrKeyNotFound, "source cleanup must remove the transferred version")
}

func TestDistributionServerRunSplitJobRunnerOnce_CompletesAbandonCleanup(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID: 1,
		Start:   []byte("a"),
		End:     []byte("z"),
		GroupID: 1,
		State:   distribution.RouteStateActive,
	}})
	require.NoError(t, err)
	job, err := distribution.InitializeSplitJobPlan(distribution.SplitJob{
		JobID:         7,
		SourceRouteID: 1,
		SplitKey:      []byte("m"),
		TargetGroupID: 2,
	}, saved.Routes[0], time.Now().UnixMilli())
	require.NoError(t, err)
	job.Phase = distribution.SplitJobPhaseAbandoning
	job.AbandonFromPhase = distribution.SplitJobPhaseBackfill
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	s, source, target := newSplitRuntimeRunner(t, baseStore, catalog, job)

	for range 10 {
		require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
		current, found, loadErr := catalog.SplitJob(ctx, job.JobID)
		require.NoError(t, loadErr)
		require.True(t, found)
		if current.Phase == distribution.SplitJobPhaseAbandoned {
			break
		}
	}
	completed, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, distribution.SplitJobPhaseAbandoned, completed.Phase)
	require.Positive(t, completed.TerminalAtMs)
	require.NotEmpty(t, source.cleanups)
	require.NotEmpty(t, target.cleanups)
	require.Equal(t, pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_VERSIONS, target.cleanups[0].GetMode())
}

func TestDistributionServerRunSplitJobRunnerOnce_PausesOnCapabilityRegression(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID: 1,
		Start:   []byte("a"),
		End:     []byte("z"),
		GroupID: 1,
		State:   distribution.RouteStateActive,
	}})
	require.NoError(t, err)
	job, err := distribution.InitializeSplitJobPlan(distribution.SplitJob{
		JobID:         9,
		SourceRouteID: 1,
		SplitKey:      []byte("m"),
		TargetGroupID: 2,
	}, saved.Routes[0], time.Now().UnixMilli())
	require.NoError(t, err)
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	capabilityErr := errors.New("node capability missing")
	s, source, _ := newSplitRuntimeRunner(t, baseStore, catalog, job)
	s.migrationCapabilityGate = func(context.Context) error { return capabilityErr }

	require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
	paused, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.True(t, paused.CapabilityRegressed)
	require.Equal(t, distribution.SplitJobPhasePlanned, paused.Phase)
	require.Empty(t, source.controls)

	s.migrationCapabilityGate = func(context.Context) error { return nil }
	require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
	resumed, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.False(t, resumed.CapabilityRegressed)
	require.Equal(t, distribution.SplitJobPhasePlanned, resumed.Phase)
	require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
	armed, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.Equal(t, distribution.SplitJobPhaseBackfill, armed.Phase)
	require.NotZero(t, armed.SnapshotTS)
}

func TestDistributionServerCleanupSplitJobSourceProofsWaitsForMetadataBarrier(t *testing.T) {
	t.Parallel()
	testSourceMetadataOwnershipBarrier(t)
}

func TestDistributionServerRunSplitJobRunnerOnce_FailClosesCapabilityRegressionAfterSideEffects(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	saved, err := catalog.Save(ctx, 0, []distribution.RouteDescriptor{{
		RouteID: 1,
		Start:   []byte("a"),
		End:     []byte("z"),
		GroupID: 1,
		State:   distribution.RouteStateActive,
	}})
	require.NoError(t, err)
	job, err := distribution.InitializeSplitJobPlan(distribution.SplitJob{
		JobID:         10,
		SourceRouteID: 1,
		SplitKey:      []byte("m"),
		TargetGroupID: 2,
	}, saved.Routes[0], time.Now().UnixMilli())
	require.NoError(t, err)
	job.Phase = distribution.SplitJobPhaseBackfill
	job.SnapshotTS = 50
	job.WriteTrackerArmed = true
	job.SourceRetentionPinTS = initialMigrationRetentionPinTS
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	source := &splitMigrationClientStub{}
	target := &splitMigrationClientStub{}
	capabilityErr := errors.New("node capability missing")
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(newDistributionCoordinatorStub(baseStore, true)),
		WithSplitMigrationCapabilityGate(func(context.Context) error { return capabilityErr }),
		WithSplitPromotionClientFactory(func(context.Context, distribution.SplitJob) (SplitPromotionClient, error) {
			return target, nil
		}),
		WithSplitMigrationClientFactory(func(context.Context, distribution.SplitJob, uint64) (SplitMigrationClient, SplitMigrationClient, error) {
			return source, target, nil
		}),
	)

	require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
	regressed, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.True(t, regressed.CapabilityRegressed)
	require.Len(t, source.controls, 1)
	require.Len(t, target.controls, 1)
	sourceFailClosed := source.controls[0]
	require.Equal(t, job.JobID, sourceFailClosed.GetJobId())
	require.Equal(t, []byte("m"), sourceFailClosed.GetRouteStart())
	require.Equal(t, []byte("z"), sourceFailClosed.GetRouteEnd())
	require.True(t, sourceFailClosed.GetSourceWriteFence())
	require.True(t, sourceFailClosed.GetSourceReadFence())
	require.True(t, sourceFailClosed.GetTrackWrites())
	require.Equal(t, uint64(50), sourceFailClosed.GetMinWriteTsExclusive())
	targetFailClosed := target.controls[0]
	require.False(t, targetFailClosed.GetSourceWriteFence())
	require.False(t, targetFailClosed.GetSourceReadFence())
	require.False(t, targetFailClosed.GetTrackWrites())
	require.Equal(t, uint64(50), targetFailClosed.GetMinWriteTsExclusive())

	s.migrationCapabilityGate = func(context.Context) error { return nil }
	require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
	resumed, found, err := catalog.SplitJob(ctx, job.JobID)
	require.NoError(t, err)
	require.True(t, found)
	require.False(t, resumed.CapabilityRegressed)
	require.Len(t, source.controls, 2)
	sourceRestored := source.controls[1]
	require.False(t, sourceRestored.GetSourceWriteFence())
	require.False(t, sourceRestored.GetSourceReadFence())
	require.True(t, sourceRestored.GetTrackWrites())
	require.Equal(t, initialMigrationRetentionPinTS, sourceRestored.GetMinWriteTsExclusive())
	require.Len(t, target.controls, 1)
}

func TestSplitJobHistoryGCKeysAppliesTTLAndCountBound(t *testing.T) {
	t.Parallel()

	now := time.UnixMilli(10 * splitJobHistoryTTL.Milliseconds())
	jobs := make([]distribution.SplitJob, 0, splitJobHistoryLimit+3)
	jobs = append(jobs, distribution.SplitJob{
		JobID:        1,
		Phase:        distribution.SplitJobPhaseDone,
		TerminalAtMs: now.Add(-splitJobHistoryTTL - time.Second).UnixMilli(),
	})
	for i := 0; i < splitJobHistoryLimit+2; i++ {
		jobs = append(jobs, distribution.SplitJob{
			JobID:        uint64(i) + 2, //nolint:gosec // loop bound is splitJobHistoryLimit.
			Phase:        distribution.SplitJobPhaseDone,
			TerminalAtMs: now.Add(-time.Hour).UnixMilli() + int64(i),
		})
	}

	keys := splitJobHistoryGCKeys(jobs, now)
	require.Len(t, keys, 3)
	require.Equal(t, distribution.CatalogSplitJobHistoryKey(jobs[0].TerminalAtMs, jobs[0].JobID), keys[0])
}

func TestDistributionServerRunSplitJobRunnerOnce_SkipsFollower(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore, distribution.WithCatalogRouteDescriptorV2Writes(true))
	_, err := catalog.Save(ctx, 0, promotionCompleteDistributionRoutes())
	require.NoError(t, err)
	require.NoError(t, catalog.CreateSplitJob(ctx, promotionCompleteDistributionJob()))

	client := &splitPromotionClientStub{
		responses: []*pb.PromoteStagedVersionsResponse{{Done: true}},
	}
	coordinator := newDistributionCoordinatorStub(baseStore, false)
	s := NewDistributionServer(
		distribution.NewEngine(),
		catalog,
		WithDistributionCoordinator(coordinator),
		WithSplitPromotionClientFactory(func(context.Context, distribution.SplitJob) (SplitPromotionClient, error) {
			return client, nil
		}),
	)

	require.NoError(t, s.RunSplitJobRunnerOnce(ctx))
	require.Zero(t, client.calls)
	require.Zero(t, coordinator.dispatchCalls)
}

func TestSplitJobRunnerContextDoneRecognizesWrappedGRPCStatus(t *testing.T) {
	t.Parallel()

	require.True(t, splitJobRunnerContextDone(context.Canceled))
	require.True(t, splitJobRunnerContextDone(context.DeadlineExceeded))
	require.True(t, splitJobRunnerContextDone(errors.WithStack(status.Error(codes.Canceled, "stopping"))))
	require.True(t, splitJobRunnerContextDone(errors.WithStack(status.Error(codes.DeadlineExceeded, "stopping"))))
	require.False(t, splitJobRunnerContextDone(errors.WithStack(status.Error(codes.Unavailable, "not leader"))))
}

func TestPromoteSplitJobTargetRejectsNoCursorProgress(t *testing.T) {
	t.Parallel()

	client := &splitPromotionClientStub{
		responses: []*pb.PromoteStagedVersionsResponse{{NextCursor: []byte("same")}},
	}
	err := promoteSplitJobTarget(context.Background(), client, promotionCompleteDistributionJob())
	require.NoError(t, err)

	client = &splitPromotionClientStub{
		responses: []*pb.PromoteStagedVersionsResponse{
			{NextCursor: []byte("same")},
			{NextCursor: []byte("same")},
		},
	}
	err = promoteSplitJobTarget(context.Background(), client, promotionCompleteDistributionJob())
	require.Error(t, err)
	require.ErrorContains(t, err, "split promotion made no cursor progress")
}

func TestDistributionServerRetrySplitJob_RequiresCatalogLeader(t *testing.T) {
	t.Parallel()

	ctx := context.Background()
	baseStore := store.NewMVCCStore()
	catalog := distribution.NewCatalogStore(baseStore)
	job := sampleDistributionSplitJob(14)
	job.Phase = distribution.SplitJobPhaseFailed
	job.RetryPhase = distribution.SplitJobPhaseBackfill
	require.NoError(t, catalog.CreateSplitJob(ctx, job))

	coordinator := newDistributionCoordinatorStub(baseStore, false)
	s := NewDistributionServer(distribution.NewEngine(), catalog, WithDistributionCoordinator(coordinator))
	_, err := s.RetrySplitJob(ctx, &pb.RetrySplitJobRequest{JobId: job.JobID})
	require.Error(t, err)
	require.Equal(t, codes.FailedPrecondition, status.Code(err))
	require.Zero(t, coordinator.dispatchCalls)
}

func sampleDistributionSplitJob(jobID uint64) distribution.SplitJob {
	return distribution.SplitJob{
		JobID:         jobID,
		SourceRouteID: 1,
		SplitKey:      []byte("g"),
		TargetGroupID: 2,
		Phase:         distribution.SplitJobPhaseBackfill,
		RetryPhase:    distribution.SplitJobPhaseNone,
		StartedAtMs:   1000,
		UpdatedAtMs:   1000,
	}
}

func promotionCompleteDistributionJob() distribution.SplitJob {
	return distribution.SplitJob{
		JobID:          99,
		SourceRouteID:  42,
		SplitKey:       []byte("m"),
		TargetGroupID:  2,
		Phase:          distribution.SplitJobPhaseCleanup,
		FenceTS:        777,
		CutoverVersion: 1,
		// Set because InitializeSplitJobPlan records it for every job it
		// creates, so a job that reached CLEANUP always carries it. Leaving it
		// zero made this fixture a legacy job, which runSplitJobPhase repairs
		// with an extra catalog write -- the dispatch count below is about
		// promotion, not about that repair. The repair itself is covered by
		// TestSplitJobSourceGroupBackfillRecordsTheGroupWhileTheShapeStillAnswers.
		SourceGroupID: 1,
	}
}

func promotionCompleteDistributionRoutes() []distribution.RouteDescriptor {
	return []distribution.RouteDescriptor{
		{
			RouteID:       2,
			Start:         []byte(""),
			End:           []byte("m"),
			GroupID:       1,
			State:         distribution.RouteStateActive,
			ParentRouteID: 42,
		},
		{
			RouteID:                3,
			Start:                  []byte("m"),
			End:                    nil,
			GroupID:                2,
			State:                  distribution.RouteStateActive,
			ParentRouteID:          42,
			StagedVisibilityActive: true,
			MigrationJobID:         99,
			MinWriteTSExclusive:    777,
		},
	}
}

func distributionRouteByID(t *testing.T, routes []distribution.RouteDescriptor, routeID uint64) distribution.RouteDescriptor {
	t.Helper()
	for _, route := range routes {
		if route.RouteID == routeID {
			return route
		}
	}
	t.Fatalf("route %d not found in %+v", routeID, routes)
	return distribution.RouteDescriptor{}
}

func splitJobIDs(jobs []*pb.SplitJob) []uint64 {
	ids := make([]uint64, 0, len(jobs))
	for _, job := range jobs {
		ids = append(ids, job.GetJobId())
	}
	return ids
}

func byteSliceStrings(in [][]byte) []string {
	out := make([]string, 0, len(in))
	for _, item := range in {
		out = append(out, string(item))
	}
	return out
}

type splitPromotionClientStub struct {
	responses []*pb.PromoteStagedVersionsResponse
	err       error
	requests  []*pb.PromoteStagedVersionsRequest
	calls     int
}

type splitMigrationClientStub struct {
	splitPromotionClientStub
	exports  []*pb.ExportRangeVersionsRequest
	imports  []*pb.ImportRangeVersionsRequest
	controls []*pb.TargetStagedReadinessRequest
	cleanups []*pb.CleanupMigrationRequest
	probes   []*pb.ProbeMigrationStateRequest
	probeFn  func(*pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error)
	nextTS   uint64
	events   []string
}

func (s *splitMigrationClientStub) ExportRangeVersions(
	_ context.Context,
	req *pb.ExportRangeVersionsRequest,
	_ ...grpc.CallOption,
) (grpc.ServerStreamingClient[pb.ExportRangeVersionsResponse], error) {
	cloned := &pb.ExportRangeVersionsRequest{
		MaxPages:             req.GetMaxPages(),
		RangeStart:           distribution.CloneBytes(req.GetRangeStart()),
		RangeEnd:             distribution.CloneBytes(req.GetRangeEnd()),
		MaxCommitTs:          req.GetMaxCommitTs(),
		MinCommitTs:          req.GetMinCommitTs(),
		Cursor:               distribution.CloneBytes(req.GetCursor()),
		ChunkBytes:           req.GetChunkBytes(),
		RouteStart:           distribution.CloneBytes(req.GetRouteStart()),
		RouteEnd:             distribution.CloneBytes(req.GetRouteEnd()),
		MaxScannedBytes:      req.GetMaxScannedBytes(),
		KeyFamily:            req.GetKeyFamily(),
		ExcludeKnownInternal: req.GetExcludeKnownInternal(),
		ExcludePrefixes:      req.GetExcludePrefixes(),
	}
	s.exports = append(s.exports, cloned)
	phaseByte := byte(0)
	if req.GetMinCommitTs() != 0 {
		phaseByte = 1
	}
	family := req.GetKeyFamily()
	if family > math.MaxUint8 {
		return nil, errors.New("test key family overflows cleanup cursor")
	}
	cursor := []byte{byte(family), phaseByte}
	return &splitMigrationStreamStub{responses: []*pb.ExportRangeVersionsResponse{{
		Versions: []*pb.MVCCVersion{{
			Key:       []byte("n"),
			CommitTs:  10,
			Value:     []byte("v"),
			KeyFamily: req.GetKeyFamily(),
		}},
		NextCursor: cursor,
		Done:       true,
	}}}, nil
}

func (s *splitMigrationClientStub) ImportRangeVersions(
	_ context.Context,
	req *pb.ImportRangeVersionsRequest,
	_ ...grpc.CallOption,
) (*pb.ImportRangeVersionsResponse, error) {
	s.imports = append(s.imports, req)
	return &pb.ImportRangeVersionsResponse{AckedCursor: distribution.CloneBytes(req.GetCursor())}, nil
}

func (s *splitMigrationClientStub) ApplyTargetStagedReadiness(
	_ context.Context,
	req *pb.TargetStagedReadinessRequest,
	_ ...grpc.CallOption,
) (*pb.TargetStagedReadinessResponse, error) {
	s.controls = append(s.controls, req)
	s.events = append(s.events, "control")
	minAdmittedTS := uint64(0)
	if req.GetTrackWrites() {
		minAdmittedTS = 10
	}
	return &pb.TargetStagedReadinessResponse{MinAdmittedTs: minAdmittedTS}, nil
}

func (s *splitMigrationClientStub) ProbeMigrationLocks(
	context.Context,
	*pb.ProbeMigrationLocksRequest,
	...grpc.CallOption,
) (*pb.ProbeMigrationLocksResponse, error) {
	return &pb.ProbeMigrationLocksResponse{}, nil
}

func (s *splitMigrationClientStub) CleanupMigration(
	_ context.Context,
	req *pb.CleanupMigrationRequest,
	_ ...grpc.CallOption,
) (*pb.CleanupMigrationResponse, error) {
	s.cleanups = append(s.cleanups, req)
	return &pb.CleanupMigrationResponse{Done: true, NextCursor: distribution.CloneBytes(req.GetCursor())}, nil
}

func (s *splitMigrationClientStub) ProbeMigrationState(
	_ context.Context,
	req *pb.ProbeMigrationStateRequest,
	_ ...grpc.CallOption,
) (*pb.ProbeMigrationStateResponse, error) {
	s.probes = append(s.probes, req)
	if s.probeFn != nil {
		return s.probeFn(req)
	}
	return &pb.ProbeMigrationStateResponse{Ready: true, CatalogVersion: req.GetExpectedCatalogVersion(), AppliedConfigurationIndex: 1}, nil
}

func (s *splitMigrationClientStub) IssueMigrationTimestamp(
	context.Context,
	*pb.IssueMigrationTimestampRequest,
	...grpc.CallOption,
) (*pb.IssueMigrationTimestampResponse, error) {
	s.events = append(s.events, "timestamp")
	if s.nextTS == 0 {
		s.nextTS = 100
	}
	s.nextTS++
	return &pb.IssueMigrationTimestampResponse{Timestamp: s.nextTS, LastCommitTs: s.nextTS - 1}, nil
}

type splitMigrationStreamStub struct {
	grpc.ClientStream
	responses []*pb.ExportRangeVersionsResponse
}

func (s *splitMigrationStreamStub) Recv() (*pb.ExportRangeVersionsResponse, error) {
	if len(s.responses) == 0 {
		return nil, io.EOF
	}
	resp := s.responses[0]
	s.responses = s.responses[1:]
	return resp, nil
}

func (s *splitPromotionClientStub) PromoteStagedVersions(
	_ context.Context,
	req *pb.PromoteStagedVersionsRequest,
	_ ...grpc.CallOption,
) (*pb.PromoteStagedVersionsResponse, error) {
	s.calls++
	s.requests = append(s.requests, &pb.PromoteStagedVersionsRequest{
		JobId:           req.GetJobId(),
		Cursor:          distribution.CloneBytes(req.GetCursor()),
		MaxVersions:     req.GetMaxVersions(),
		MaxBytes:        req.GetMaxBytes(),
		MaxScannedBytes: req.GetMaxScannedBytes(),
	})
	if s.err != nil {
		return nil, s.err
	}
	if len(s.responses) == 0 {
		return &pb.PromoteStagedVersionsResponse{Done: true}, nil
	}
	resp := s.responses[0]
	s.responses = s.responses[1:]
	return resp, nil
}

func (s *distributionCoordinatorStub) Next(ctx context.Context) (uint64, error) {
	return s.NextAfter(ctx, 0)
}

func (s *distributionCoordinatorStub) NextAfter(_ context.Context, min uint64) (uint64, error) {
	s.timestampCalls++
	if s.timestampErr != nil {
		return 0, s.timestampErr
	}
	next := s.timestampNext
	if next == 0 {
		next = s.store.LastCommitTS() + 1
	}
	if next <= min {
		next = min + 1
	}
	s.timestampNext = next + 1
	return next, nil
}
