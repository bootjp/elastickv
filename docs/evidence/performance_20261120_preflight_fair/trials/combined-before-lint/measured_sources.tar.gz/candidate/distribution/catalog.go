package distribution

import (
	"bytes"
	"context"
	"encoding/binary"
	"math"
	"sort"

	"github.com/bootjp/elastickv/store"
	"github.com/cockroachdb/errors"
)

const (
	catalogMetaPrefix        = "!dist|meta|"
	catalogRoutePrefix       = "!dist|route|"
	catalogVersionStorageKey = catalogMetaPrefix + "version"
	catalogNextRouteIDKey    = catalogMetaPrefix + "next_route_id"

	catalogUint64Bytes       = 8
	catalogVersionRecordSize = 1 + catalogUint64Bytes

	catalogVersionCodecVersion  byte = 1
	catalogRouteCodecVersionMin byte = 1
	catalogRouteCodecVersionV1  byte = 1
	catalogRouteCodecVersionV2  byte = 2
	catalogRouteCodecVersionV3  byte = 3
	catalogRouteCodecVersion    byte = catalogRouteCodecVersionV3
	catalogRouteV3TailSize           = catalogUint64Bytes + 1 + catalogUint64Bytes + catalogUint64Bytes

	catalogScanPageSize          = 256
	catalogSaveMetaMutationCount = 2
)

var (
	ErrCatalogStoreRequired        = errors.New("catalog store is required")
	ErrCatalogVersionMismatch      = errors.New("catalog version mismatch")
	ErrCatalogVersionOverflow      = errors.New("catalog version overflow")
	ErrCatalogRouteIDOverflow      = errors.New("catalog route id overflow")
	ErrCatalogRouteIDRequired      = errors.New("catalog route id is required")
	ErrCatalogGroupIDRequired      = errors.New("catalog group id is required")
	ErrCatalogDuplicateRouteID     = errors.New("catalog route id must be unique")
	ErrCatalogInvalidRouteRange    = errors.New("catalog route range is invalid")
	ErrCatalogInvalidVersionRecord = errors.New("catalog version record is invalid")
	ErrCatalogInvalidNextRouteID   = errors.New("catalog next route id record is invalid")
	ErrCatalogInvalidRouteRecord   = errors.New("catalog route record is invalid")
	ErrCatalogInvalidRouteState    = errors.New("catalog route state is invalid")
	ErrCatalogInvalidRouteKey      = errors.New("catalog route key is invalid")
	ErrCatalogRouteKeyIDMismatch   = errors.New("catalog route key and record route id mismatch")
	ErrCatalogRouteV2WriteDisabled = errors.New("catalog route descriptor v2 writes are disabled")
)

// RouteState describes the control-plane state of a route.
type RouteState byte

const (
	// RouteStateActive is a normal serving route.
	RouteStateActive RouteState = iota
	// RouteStateWriteFenced blocks writes during cutover.
	RouteStateWriteFenced
	// RouteStateMigratingSource means range data is being copied out.
	RouteStateMigratingSource
	// RouteStateMigratingTarget means range data is being copied in.
	RouteStateMigratingTarget
)

func (s RouteState) valid() bool {
	switch s {
	case RouteStateActive, RouteStateWriteFenced, RouteStateMigratingSource, RouteStateMigratingTarget:
		return true
	default:
		return false
	}
}

// RouteDescriptor is the durable representation of a route.
type RouteDescriptor struct {
	RouteID                uint64
	Start                  []byte
	End                    []byte
	GroupID                uint64
	State                  RouteState
	ParentRouteID          uint64
	StagedVisibilityActive bool
	MigrationJobID         uint64
	MinWriteTSExclusive    uint64
	SplitAtHLC             uint64
}

// CatalogSnapshot is a point-in-time snapshot of the route catalog.
type CatalogSnapshot struct {
	Version uint64
	Routes  []RouteDescriptor
	ReadTS  uint64
}

// CatalogStore provides persistence helpers for route catalog state.
type CatalogStore struct {
	store                        store.MVCCStore
	allowRouteDescriptorV2Writes bool
	migrationStoreForGroup       CatalogMigrationStoreResolver
	migrationRetireForGroup      CatalogMigrationRetireResolver
}

type CatalogStoreOption func(*CatalogStore)

// CatalogMigrationStoreResolver resolves the local MVCC store for a data group.
type CatalogMigrationStoreResolver func(groupID uint64) (store.MVCCStore, error)

// CatalogMigrationRetireResolver retires migration metadata through the target
// data group's replicated apply path.
type CatalogMigrationRetireResolver func(ctx context.Context, groupID, jobID uint64) error

func WithCatalogRouteDescriptorV2Writes(enabled bool) CatalogStoreOption {
	return func(s *CatalogStore) {
		s.allowRouteDescriptorV2Writes = enabled
	}
}

// WithCatalogMigrationStoreResolver makes split-job finalization retire
// target-local migration metadata from the target data group store.
func WithCatalogMigrationStoreResolver(resolver CatalogMigrationStoreResolver) CatalogStoreOption {
	return func(s *CatalogStore) {
		s.migrationStoreForGroup = resolver
	}
}

// WithCatalogMigrationRetireResolver makes split-job finalization retire
// target-local migration metadata through the target data group Raft log.
func WithCatalogMigrationRetireResolver(resolver CatalogMigrationRetireResolver) CatalogStoreOption {
	return func(s *CatalogStore) {
		s.migrationRetireForGroup = resolver
	}
}

// NewCatalogStore creates a route catalog persistence helper.
func NewCatalogStore(st store.MVCCStore, opts ...CatalogStoreOption) *CatalogStore {
	s := &CatalogStore{store: st}
	for _, opt := range opts {
		if opt != nil {
			opt(s)
		}
	}
	return s
}

func (s *CatalogStore) AllowsRouteDescriptorV2Writes() bool {
	return s != nil && s.allowRouteDescriptorV2Writes
}

// CatalogVersionKey returns the reserved key used for catalog version storage.
func CatalogVersionKey() []byte {
	return []byte(catalogVersionStorageKey)
}

// CatalogNextRouteIDKey returns the reserved key used for next route id storage.
func CatalogNextRouteIDKey() []byte {
	return []byte(catalogNextRouteIDKey)
}

// CatalogRouteKey returns the reserved key used for a route descriptor.
func CatalogRouteKey(routeID uint64) []byte {
	key := make([]byte, len(catalogRoutePrefix)+catalogUint64Bytes)
	copy(key, []byte(catalogRoutePrefix))
	binary.BigEndian.PutUint64(key[len(catalogRoutePrefix):], routeID)
	return key
}

// IsCatalogRouteKey reports whether key belongs to the route catalog keyspace.
func IsCatalogRouteKey(key []byte) bool {
	return bytes.HasPrefix(key, []byte(catalogRoutePrefix))
}

// CatalogRouteIDFromKey parses the route ID from a catalog route key.
func CatalogRouteIDFromKey(key []byte) (uint64, bool) {
	if !IsCatalogRouteKey(key) {
		return 0, false
	}
	suffix := key[len(catalogRoutePrefix):]
	if len(suffix) != catalogUint64Bytes {
		return 0, false
	}
	return binary.BigEndian.Uint64(suffix), true
}

// EncodeCatalogVersion serializes a catalog version record.
func EncodeCatalogVersion(version uint64) []byte {
	out := make([]byte, catalogVersionRecordSize)
	out[0] = catalogVersionCodecVersion
	binary.BigEndian.PutUint64(out[1:], version)
	return out
}

// EncodeCatalogNextRouteID serializes a next route id record.
func EncodeCatalogNextRouteID(nextRouteID uint64) []byte {
	return EncodeCatalogVersion(nextRouteID)
}

// DecodeCatalogVersion deserializes a catalog version record.
func DecodeCatalogVersion(raw []byte) (uint64, error) {
	if len(raw) != catalogVersionRecordSize {
		return 0, errors.WithStack(ErrCatalogInvalidVersionRecord)
	}
	if raw[0] != catalogVersionCodecVersion {
		return 0, errors.Wrapf(ErrCatalogInvalidVersionRecord, "unsupported version %d", raw[0])
	}
	return binary.BigEndian.Uint64(raw[1:]), nil
}

// DecodeCatalogNextRouteID deserializes a next route id record.
func DecodeCatalogNextRouteID(raw []byte) (uint64, error) {
	nextRouteID, err := DecodeCatalogVersion(raw)
	if err != nil {
		return 0, errors.Wrapf(ErrCatalogInvalidNextRouteID, "decode next route id: %v", err)
	}
	if nextRouteID == 0 {
		return 0, errors.WithStack(ErrCatalogInvalidNextRouteID)
	}
	return nextRouteID, nil
}

// EncodeRouteDescriptor serializes a route descriptor record.
func EncodeRouteDescriptor(route RouteDescriptor) ([]byte, error) {
	raw, _, err := encodeRouteDescriptorWithSplitAtHLCOffset(route)
	return raw, err
}

func encodeRouteDescriptorWithSplitAtHLCOffset(route RouteDescriptor) ([]byte, uint64, error) {
	if err := validateRouteDescriptor(route); err != nil {
		return nil, 0, err
	}

	out := make([]byte, 0, routeDescriptorEncodedSize(route))
	version := catalogRouteCodecVersionV2
	if routeDescriptorRequiresV2(route) {
		version = catalogRouteCodecVersionV3
	}
	out = append(out, version)
	out = appendU64(out, route.RouteID)
	out = appendU64(out, route.GroupID)
	out = append(out, byte(route.State))
	out = appendU64(out, route.ParentRouteID)
	out = appendU64(out, uint64(len(route.Start)))
	out = append(out, route.Start...)

	if route.End == nil {
		out = append(out, 0)
	} else {
		out = append(out, 1)
		out = appendU64(out, uint64(len(route.End)))
		out = append(out, route.End...)
	}

	splitAtHLCOffset := uint64(len(out))
	if version == catalogRouteCodecVersionV3 {
		out = appendRouteDescriptorV3Tail(out, route)
	} else {
		out = appendU64(out, route.SplitAtHLC)
	}
	return out, splitAtHLCOffset, nil
}

func EncodeRouteDescriptorForCatalogWrite(route RouteDescriptor, allowV2 bool) ([]byte, error) {
	if routeDescriptorRequiresV2(route) && !allowV2 {
		return nil, errors.WithStack(ErrCatalogRouteV2WriteDisabled)
	}
	return EncodeRouteDescriptor(route)
}

// EncodeRouteDescriptorForCatalogWriteWithSplitAtHLCOffset serializes a route
// descriptor and returns the byte offset of its SplitAtHLC field.
func EncodeRouteDescriptorForCatalogWriteWithSplitAtHLCOffset(route RouteDescriptor, allowV2 bool) ([]byte, uint64, error) {
	if routeDescriptorRequiresV2(route) && !allowV2 {
		return nil, 0, errors.WithStack(ErrCatalogRouteV2WriteDisabled)
	}
	return encodeRouteDescriptorWithSplitAtHLCOffset(route)
}

// DecodeRouteDescriptor deserializes a route descriptor record.
func DecodeRouteDescriptor(raw []byte) (RouteDescriptor, error) {
	if len(raw) < 1 {
		return RouteDescriptor{}, errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	version := raw[0]
	if version < catalogRouteCodecVersionMin || version > catalogRouteCodecVersion {
		return RouteDescriptor{}, errors.Wrapf(ErrCatalogInvalidRouteRecord, "unsupported version %d", raw[0])
	}

	r := bytes.NewReader(raw[1:])
	route, err := decodeRouteDescriptorHeader(r)
	if err != nil {
		return RouteDescriptor{}, err
	}
	route.End, err = decodeRouteDescriptorEnd(r)
	if err != nil {
		return RouteDescriptor{}, err
	}
	if err := decodeRouteDescriptorTail(version, r, &route); err != nil {
		return RouteDescriptor{}, err
	}
	if err := validateRouteDescriptor(route); err != nil {
		return RouteDescriptor{}, err
	}
	return route, nil
}

// Snapshot reads a consistent route catalog snapshot at the store's latest
// known commit timestamp.
func (s *CatalogStore) Snapshot(ctx context.Context) (CatalogSnapshot, error) {
	if err := ensureCatalogStore(s); err != nil {
		return CatalogSnapshot{}, err
	}
	return s.SnapshotAt(ctx, s.store.LastCommitTS())
}

// IsCatalogKey reports whether key belongs to the durable distribution
// catalog namespace.
func IsCatalogKey(key []byte) bool {
	return bytes.HasPrefix(key, []byte("!dist|"))
}

// LatestCommitTS returns the local catalog store watermark without reading
// catalog data. Callers use it as the pre-Phase-D legacy timestamp input before
// selecting the transaction snapshot through the dedicated TSO.
func (s *CatalogStore) LatestCommitTS() uint64 {
	if s == nil || s.store == nil {
		return 0
	}
	return s.store.LastCommitTS()
}

// SnapshotAt reads a consistent route catalog snapshot at a specific MVCC
// timestamp.
func (s *CatalogStore) SnapshotAt(ctx context.Context, ts uint64) (CatalogSnapshot, error) {
	if err := ensureCatalogStore(s); err != nil {
		return CatalogSnapshot{}, err
	}
	ctx = contextOrBackground(ctx)

	version, err := s.versionAt(ctx, ts)
	if err != nil {
		return CatalogSnapshot{}, err
	}
	routes, err := s.routesAt(ctx, ts)
	if err != nil {
		return CatalogSnapshot{}, err
	}
	return CatalogSnapshot{Version: version, Routes: routes, ReadTS: ts}, nil
}

// Version reads only the durable catalog version at the latest commit
// timestamp.
func (s *CatalogStore) Version(ctx context.Context) (uint64, error) {
	if err := ensureCatalogStore(s); err != nil {
		return 0, err
	}
	ctx = contextOrBackground(ctx)

	readTS := s.store.LastCommitTS()
	return s.versionAt(ctx, readTS)
}

// NextRouteID reads the next route id counter from catalog metadata.
func (s *CatalogStore) NextRouteID(ctx context.Context) (uint64, error) {
	if err := ensureCatalogStore(s); err != nil {
		return 0, err
	}
	ctx = contextOrBackground(ctx)

	readTS := s.store.LastCommitTS()
	nextRouteID, err := s.NextRouteIDAt(ctx, readTS)
	if err != nil {
		return 0, err
	}
	return nextRouteID, nil
}

// NextRouteIDAt reads the next route id counter at a given snapshot timestamp.
func (s *CatalogStore) NextRouteIDAt(ctx context.Context, ts uint64) (uint64, error) {
	if err := ensureCatalogStore(s); err != nil {
		return 0, err
	}
	ctx = contextOrBackground(ctx)
	nextRouteID, err := s.nextRouteIDAt(ctx, ts)
	if err != nil {
		return 0, err
	}
	if nextRouteID != 0 {
		return nextRouteID, nil
	}

	// Fallback for catalogs created before next_route_id metadata existed.
	routes, err := s.routesAt(ctx, ts)
	if err != nil {
		return 0, err
	}
	return NextRouteIDFloor(routes)
}

// Save updates the route catalog using optimistic version checks and bumps the
// catalog version by exactly one on success.
func (s *CatalogStore) Save(ctx context.Context, expectedVersion uint64, routes []RouteDescriptor) (CatalogSnapshot, error) {
	if err := ensureCatalogStore(s); err != nil {
		return CatalogSnapshot{}, err
	}
	ctx = contextOrBackground(ctx)

	plan, err := s.prepareSave(ctx, expectedVersion, routes)
	if err != nil {
		return CatalogSnapshot{}, err
	}
	mutations, err := s.buildSaveMutations(ctx, &plan)
	if err != nil {
		return CatalogSnapshot{}, err
	}
	if err := s.applySaveMutations(ctx, plan, mutations); err != nil {
		return CatalogSnapshot{}, err
	}

	return CatalogSnapshot{
		Version: plan.nextVersion,
		Routes:  cloneRouteDescriptors(plan.routes),
	}, nil
}

func ensureCatalogStore(s *CatalogStore) error {
	if s == nil || s.store == nil {
		return errors.WithStack(ErrCatalogStoreRequired)
	}
	return nil
}

func contextOrBackground(ctx context.Context) context.Context {
	if ctx == nil {
		return context.Background()
	}
	return ctx
}

func normalizeRoutes(routes []RouteDescriptor) ([]RouteDescriptor, error) {
	if len(routes) == 0 {
		return []RouteDescriptor{}, nil
	}
	out := make([]RouteDescriptor, 0, len(routes))
	seen := make(map[uint64]struct{}, len(routes))
	for _, route := range routes {
		if err := validateRouteDescriptor(route); err != nil {
			return nil, err
		}
		if _, exists := seen[route.RouteID]; exists {
			return nil, errors.WithStack(ErrCatalogDuplicateRouteID)
		}
		seen[route.RouteID] = struct{}{}
		out = append(out, CloneRouteDescriptor(route))
	}
	sortRouteDescriptors(out)
	return out, nil
}

func validateRouteDescriptor(route RouteDescriptor) error {
	if route.RouteID == 0 {
		return errors.WithStack(ErrCatalogRouteIDRequired)
	}
	if route.GroupID == 0 {
		return errors.WithStack(ErrCatalogGroupIDRequired)
	}
	if !route.State.valid() {
		return errors.WithStack(ErrCatalogInvalidRouteState)
	}
	if route.End != nil && bytes.Compare(route.Start, route.End) >= 0 {
		return errors.WithStack(ErrCatalogInvalidRouteRange)
	}
	if route.StagedVisibilityActive && route.MigrationJobID == 0 {
		return errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	if !route.StagedVisibilityActive && route.MigrationJobID != 0 {
		return errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	return nil
}

// CloneRouteDescriptor returns a deep copy of route.
func CloneRouteDescriptor(route RouteDescriptor) RouteDescriptor {
	return RouteDescriptor{
		RouteID:                route.RouteID,
		Start:                  CloneBytes(route.Start),
		End:                    CloneBytes(route.End),
		GroupID:                route.GroupID,
		State:                  route.State,
		ParentRouteID:          route.ParentRouteID,
		StagedVisibilityActive: route.StagedVisibilityActive,
		MigrationJobID:         route.MigrationJobID,
		MinWriteTSExclusive:    route.MinWriteTSExclusive,
		SplitAtHLC:             route.SplitAtHLC,
	}
}

func cloneRouteDescriptors(routes []RouteDescriptor) []RouteDescriptor {
	out := make([]RouteDescriptor, len(routes))
	for i := range routes {
		out[i] = CloneRouteDescriptor(routes[i])
	}
	return out
}

func sortRouteDescriptors(routes []RouteDescriptor) {
	sort.Slice(routes, func(i, j int) bool {
		return routeDescriptorLess(routes[i], routes[j])
	})
}

func routeDescriptorLess(left, right RouteDescriptor) bool {
	if c := bytes.Compare(left.Start, right.Start); c != 0 {
		return c < 0
	}

	if left.End == nil && right.End != nil {
		return false
	}
	if left.End != nil && right.End == nil {
		return true
	}
	if left.End != nil && right.End != nil {
		if c := bytes.Compare(left.End, right.End); c != 0 {
			return c < 0
		}
	}

	return left.RouteID < right.RouteID
}

func readU64LenBytes(r *bytes.Reader, rawLen uint64) ([]byte, error) {
	n, err := u64ToInt(rawLen)
	if err != nil {
		return nil, err
	}
	if n > r.Len() {
		return nil, errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	if n == 0 {
		return []byte{}, nil
	}
	out := make([]byte, n)
	if _, err := r.Read(out); err != nil {
		return nil, errors.WithStack(err)
	}
	return out, nil
}

func u64ToInt(v uint64) (int, error) {
	if v > uint64(math.MaxInt) {
		return 0, errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	return int(v), nil
}

func (s *CatalogStore) versionAt(ctx context.Context, ts uint64) (uint64, error) {
	raw, err := s.store.GetAt(ctx, CatalogVersionKey(), ts)
	if err != nil {
		if errors.Is(err, store.ErrKeyNotFound) {
			return 0, nil
		}
		return 0, errors.WithStack(err)
	}
	v, err := DecodeCatalogVersion(raw)
	if err != nil {
		return 0, err
	}
	return v, nil
}

func (s *CatalogStore) nextRouteIDAt(ctx context.Context, ts uint64) (uint64, error) {
	raw, err := s.store.GetAt(ctx, CatalogNextRouteIDKey(), ts)
	if err != nil {
		if errors.Is(err, store.ErrKeyNotFound) {
			return 0, nil
		}
		return 0, errors.WithStack(err)
	}
	nextRouteID, err := DecodeCatalogNextRouteID(raw)
	if err != nil {
		return 0, err
	}
	return nextRouteID, nil
}

// NextRouteIDFloor returns the minimum valid next route ID for routes.
// It is shared by catalog persistence and split planning to keep route-ID
// allocation rules consistent.
func NextRouteIDFloor(routes []RouteDescriptor) (uint64, error) {
	maxRouteID := uint64(0)
	for _, route := range routes {
		if route.RouteID > maxRouteID {
			maxRouteID = route.RouteID
		}
	}
	if maxRouteID == math.MaxUint64 {
		return 0, errors.WithStack(ErrCatalogRouteIDOverflow)
	}
	return maxRouteID + 1, nil
}

func (s *CatalogStore) routesAt(ctx context.Context, ts uint64) ([]RouteDescriptor, error) {
	entries, err := s.scanRouteEntriesAt(ctx, ts)
	if err != nil {
		return nil, err
	}
	out := make([]RouteDescriptor, 0, len(entries))
	seen := make(map[uint64]struct{}, len(entries))
	for _, kvp := range entries {
		routeID, ok := CatalogRouteIDFromKey(kvp.Key)
		if !ok {
			return nil, errors.WithStack(ErrCatalogInvalidRouteKey)
		}
		route, err := DecodeRouteDescriptor(kvp.Value)
		if err != nil {
			return nil, err
		}
		if route.RouteID != routeID {
			return nil, errors.WithStack(ErrCatalogRouteKeyIDMismatch)
		}
		if _, exists := seen[route.RouteID]; exists {
			return nil, errors.WithStack(ErrCatalogDuplicateRouteID)
		}
		seen[route.RouteID] = struct{}{}
		out = append(out, route)
	}
	sortRouteDescriptors(out)
	return out, nil
}

func (s *CatalogStore) scanRouteEntriesAt(ctx context.Context, ts uint64) ([]*store.KVPair, error) {
	prefix := []byte(catalogRoutePrefix)
	upper := prefixScanEnd(prefix)
	cursor := CloneBytes(prefix)
	out := make([]*store.KVPair, 0)

	for {
		page, err := s.store.ScanAt(ctx, cursor, upper, catalogScanPageSize, ts)
		if err != nil {
			return nil, errors.WithStack(err)
		}
		if len(page) == 0 {
			break
		}

		var (
			lastKey []byte
			done    bool
		)
		out, lastKey, done = appendRoutePage(out, page, prefix)
		if done {
			return out, nil
		}
		if lastKey == nil || len(page) < catalogScanPageSize {
			break
		}
		nextCursor, inRange := nextCursorWithinUpper(lastKey, upper)
		if !inRange {
			break
		}
		cursor = nextCursor
	}
	return out, nil
}

type savePlan struct {
	readTS      uint64
	minCommitTS uint64
	nextVersion uint64
	routes      []RouteDescriptor
}

func (s *CatalogStore) prepareSave(ctx context.Context, expectedVersion uint64, routes []RouteDescriptor) (savePlan, error) {
	normalized, err := normalizeRoutes(routes)
	if err != nil {
		return savePlan{}, err
	}

	readTS := s.store.LastCommitTS()
	currentVersion, err := s.versionAt(ctx, readTS)
	if err != nil {
		return savePlan{}, err
	}
	if currentVersion != expectedVersion {
		return savePlan{}, errors.WithStack(ErrCatalogVersionMismatch)
	}

	nextVersion := expectedVersion + 1
	if nextVersion == 0 {
		return savePlan{}, errors.WithStack(ErrCatalogVersionOverflow)
	}
	minCommitTS := readTS + 1
	if minCommitTS == 0 {
		return savePlan{}, errors.WithStack(ErrCatalogVersionOverflow)
	}

	return savePlan{
		readTS:      readTS,
		minCommitTS: minCommitTS,
		nextVersion: nextVersion,
		routes:      normalized,
	}, nil
}

func (s *CatalogStore) buildSaveMutations(ctx context.Context, plan *savePlan) ([]*store.KVPairMutation, error) {
	if plan == nil {
		return nil, errors.WithStack(ErrCatalogStoreRequired)
	}
	existingRoutes, err := s.routesAt(ctx, plan.readTS)
	if err != nil {
		return nil, err
	}
	plan.routes = mergeRouteDescriptorWriteFloors(existingRoutes, plan.routes)

	nextRouteID, err := s.nextRouteIDAt(ctx, plan.readTS)
	if err != nil {
		return nil, err
	}
	for _, routes := range [][]RouteDescriptor{existingRoutes, plan.routes} {
		floor, err := NextRouteIDFloor(routes)
		if err != nil {
			return nil, err
		}
		if nextRouteID < floor {
			nextRouteID = floor
		}
	}

	mutations := make([]*store.KVPairMutation, 0, len(existingRoutes)+len(plan.routes)+catalogSaveMetaMutationCount)
	mutations = appendDeleteRouteMutations(mutations, existingRoutes, plan.routes)
	mutations, err = appendUpsertRouteMutations(mutations, existingRoutes, plan.routes, s.allowRouteDescriptorV2Writes)
	if err != nil {
		return nil, err
	}
	delta, err := buildCatalogDelta(existingRoutes, plan.routes, plan.nextVersion-1, plan.nextVersion)
	if err != nil {
		return nil, err
	}
	deltaMutations, err := s.BuildDeltaMutationsAt(ctx, plan.readTS, delta)
	if err != nil {
		return nil, err
	}
	mutations = append(mutations, deltaMutations...)
	mutations = append(mutations, &store.KVPairMutation{
		Op:    store.OpTypePut,
		Key:   CatalogVersionKey(),
		Value: EncodeCatalogVersion(plan.nextVersion),
	})
	mutations = append(mutations, &store.KVPairMutation{
		Op:    store.OpTypePut,
		Key:   CatalogNextRouteIDKey(),
		Value: EncodeCatalogNextRouteID(nextRouteID),
	})
	return mutations, nil
}

func mergeRouteDescriptorWriteFloors(existing []RouteDescriptor, desired []RouteDescriptor) []RouteDescriptor {
	if len(existing) == 0 || len(desired) == 0 {
		return desired
	}
	existingByID := make(map[uint64]RouteDescriptor, len(existing))
	for _, route := range existing {
		existingByID[route.RouteID] = route
	}
	for i := range desired {
		existingRoute, ok := existingByID[desired[i].RouteID]
		if !ok {
			continue
		}
		if existingRoute.MinWriteTSExclusive > desired[i].MinWriteTSExclusive {
			desired[i].MinWriteTSExclusive = existingRoute.MinWriteTSExclusive
		}
	}
	return desired
}

func (s *CatalogStore) applySaveMutations(ctx context.Context, plan savePlan, mutations []*store.KVPairMutation) error {
	commitTS, err := s.commitTSForApply(plan.minCommitTS)
	if err != nil {
		return err
	}
	if err := s.store.ApplyMutations(ctx, mutations, nil, plan.readTS, commitTS); err != nil {
		if errors.Is(err, store.ErrWriteConflict) {
			return errors.WithStack(ErrCatalogVersionMismatch)
		}
		return errors.WithStack(err)
	}
	return nil
}

func (s *CatalogStore) commitTSForApply(minCommitTS uint64) (uint64, error) {
	currentLast := s.store.LastCommitTS()
	candidateFromStore := currentLast + 1
	if candidateFromStore == 0 {
		return 0, errors.WithStack(ErrCatalogVersionOverflow)
	}

	if candidateFromStore > minCommitTS {
		return candidateFromStore, nil
	}
	return minCommitTS, nil
}

func appendDeleteRouteMutations(out []*store.KVPairMutation, existing []RouteDescriptor, desired []RouteDescriptor) []*store.KVPairMutation {
	desiredByID := make(map[uint64]struct{}, len(desired))
	for _, route := range desired {
		desiredByID[route.RouteID] = struct{}{}
	}

	for _, route := range existing {
		if _, ok := desiredByID[route.RouteID]; ok {
			continue
		}
		out = append(out, &store.KVPairMutation{
			Op:  store.OpTypeDelete,
			Key: CatalogRouteKey(route.RouteID),
		})
	}
	return out
}

func appendUpsertRouteMutations(out []*store.KVPairMutation, existing []RouteDescriptor, desired []RouteDescriptor, allowRouteDescriptorV2Writes bool) ([]*store.KVPairMutation, error) {
	existingByID := make(map[uint64]RouteDescriptor, len(existing))
	for _, route := range existing {
		existingByID[route.RouteID] = route
	}

	for _, route := range desired {
		if existingRoute, ok := existingByID[route.RouteID]; ok && routeDescriptorEqual(existingRoute, route) {
			continue
		}
		encoded, err := EncodeRouteDescriptorForCatalogWrite(route, allowRouteDescriptorV2Writes)
		if err != nil {
			return nil, err
		}
		out = append(out, &store.KVPairMutation{
			Op:    store.OpTypePut,
			Key:   CatalogRouteKey(route.RouteID),
			Value: encoded,
		})
	}
	return out, nil
}

// Equal reports whether two descriptors have the same durable catalog fields.
func (left RouteDescriptor) Equal(right RouteDescriptor) bool {
	return routeDescriptorEqual(left, right)
}

func routeDescriptorEqual(left, right RouteDescriptor) bool {
	return left.RouteID == right.RouteID &&
		bytes.Equal(left.Start, right.Start) &&
		bytes.Equal(left.End, right.End) &&
		left.GroupID == right.GroupID &&
		left.State == right.State &&
		left.ParentRouteID == right.ParentRouteID &&
		left.StagedVisibilityActive == right.StagedVisibilityActive &&
		left.MigrationJobID == right.MigrationJobID &&
		left.MinWriteTSExclusive == right.MinWriteTSExclusive &&
		left.SplitAtHLC == right.SplitAtHLC
}

func appendU64(dst []byte, v uint64) []byte {
	var encoded [catalogUint64Bytes]byte
	binary.BigEndian.PutUint64(encoded[:], v)
	return append(dst, encoded[:]...)
}

func routeDescriptorEncodedSize(route RouteDescriptor) int {
	size := 1 + catalogUint64Bytes + catalogUint64Bytes + 1 + catalogUint64Bytes + catalogUint64Bytes + len(route.Start) + 1
	if route.End != nil {
		size += catalogUint64Bytes + len(route.End)
	}
	size += catalogUint64Bytes
	if routeDescriptorRequiresV2(route) {
		size += 1 + catalogUint64Bytes + catalogUint64Bytes
	}
	return size
}

func routeDescriptorRequiresV2(route RouteDescriptor) bool {
	return route.StagedVisibilityActive || route.MigrationJobID != 0 || route.MinWriteTSExclusive != 0
}

func appendRouteDescriptorV3Tail(out []byte, route RouteDescriptor) []byte {
	out = appendU64(out, route.SplitAtHLC)
	if route.StagedVisibilityActive {
		out = append(out, 1)
	} else {
		out = append(out, 0)
	}
	out = appendU64(out, route.MigrationJobID)
	out = appendU64(out, route.MinWriteTSExclusive)
	return out
}

func decodeRouteDescriptorTail(version byte, r *bytes.Reader, route *RouteDescriptor) error {
	switch version {
	case catalogRouteCodecVersionV1:
		if r.Len() != 0 {
			return errors.WithStack(ErrCatalogInvalidRouteRecord)
		}
		return nil
	case catalogRouteCodecVersionV2:
		var err error
		route.SplitAtHLC, err = decodeRouteDescriptorSplitAtHLC(r)
		if err != nil {
			return err
		}
		if r.Len() != 0 {
			return errors.WithStack(ErrCatalogInvalidRouteRecord)
		}
		return nil
	case catalogRouteCodecVersionV3:
		return decodeRouteDescriptorV3Tail(r, route)
	default:
		return errors.Wrapf(ErrCatalogInvalidRouteRecord, "unsupported version %d", version)
	}
}

func decodeRouteDescriptorV3Tail(r *bytes.Reader, route *RouteDescriptor) error {
	if r.Len() != catalogRouteV3TailSize {
		return errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	var err error
	route.SplitAtHLC, err = decodeRouteDescriptorSplitAtHLC(r)
	if err != nil {
		return err
	}
	stagedRaw, err := r.ReadByte()
	if err != nil {
		return errors.WithStack(err)
	}
	switch stagedRaw {
	case 0:
		route.StagedVisibilityActive = false
	case 1:
		route.StagedVisibilityActive = true
	default:
		return errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	if err := binary.Read(r, binary.BigEndian, &route.MigrationJobID); err != nil {
		return errors.WithStack(err)
	}
	if err := binary.Read(r, binary.BigEndian, &route.MinWriteTSExclusive); err != nil {
		return errors.WithStack(err)
	}
	return nil
}

func decodeRouteDescriptorHeader(r *bytes.Reader) (RouteDescriptor, error) {
	var routeID uint64
	var groupID uint64
	var parentRouteID uint64
	var startLen uint64

	if err := binary.Read(r, binary.BigEndian, &routeID); err != nil {
		return RouteDescriptor{}, errors.WithStack(err)
	}
	if err := binary.Read(r, binary.BigEndian, &groupID); err != nil {
		return RouteDescriptor{}, errors.WithStack(err)
	}
	stateRaw, err := r.ReadByte()
	if err != nil {
		return RouteDescriptor{}, errors.WithStack(err)
	}
	if err := binary.Read(r, binary.BigEndian, &parentRouteID); err != nil {
		return RouteDescriptor{}, errors.WithStack(err)
	}
	if err := binary.Read(r, binary.BigEndian, &startLen); err != nil {
		return RouteDescriptor{}, errors.WithStack(err)
	}

	start, err := readU64LenBytes(r, startLen)
	if err != nil {
		return RouteDescriptor{}, err
	}
	return RouteDescriptor{
		RouteID:       routeID,
		GroupID:       groupID,
		State:         RouteState(stateRaw),
		ParentRouteID: parentRouteID,
		Start:         start,
	}, nil
}

func decodeRouteDescriptorEnd(r *bytes.Reader) ([]byte, error) {
	endFlag, err := r.ReadByte()
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if endFlag == 0 {
		return nil, nil
	}
	if endFlag != 1 {
		return nil, errors.Wrapf(ErrCatalogInvalidRouteRecord, "invalid end flag %d", endFlag)
	}

	var endLen uint64
	if err := binary.Read(r, binary.BigEndian, &endLen); err != nil {
		return nil, errors.WithStack(err)
	}
	return readU64LenBytes(r, endLen)
}

func decodeRouteDescriptorSplitAtHLC(r *bytes.Reader) (uint64, error) {
	if r.Len() < catalogUint64Bytes {
		return 0, errors.WithStack(ErrCatalogInvalidRouteRecord)
	}
	var buf [catalogUint64Bytes]byte
	if _, err := r.Read(buf[:]); err != nil {
		return 0, errors.WithStack(err)
	}
	return binary.BigEndian.Uint64(buf[:]), nil
}

func appendRoutePage(out []*store.KVPair, page []*store.KVPair, prefix []byte) ([]*store.KVPair, []byte, bool) {
	var lastKey []byte
	for _, kvp := range page {
		if kvp == nil {
			continue
		}
		if !bytes.HasPrefix(kvp.Key, prefix) {
			return out, lastKey, true
		}
		out = append(out, &store.KVPair{
			Key:   CloneBytes(kvp.Key),
			Value: CloneBytes(kvp.Value),
		})
		lastKey = kvp.Key
	}
	return out, lastKey, false
}

func nextCursorWithinUpper(lastKey []byte, upper []byte) ([]byte, bool) {
	if len(lastKey) == 0 {
		return nil, false
	}
	nextCursor := nextScanCursor(lastKey)
	if upper != nil && bytes.Compare(nextCursor, upper) >= 0 {
		return nil, false
	}
	return nextCursor, true
}

func prefixScanEnd(prefix []byte) []byte {
	if len(prefix) == 0 {
		return nil
	}
	out := CloneBytes(prefix)
	for i := len(out) - 1; i >= 0; i-- {
		if out[i] == ^byte(0) {
			continue
		}
		out[i]++
		return out[:i+1]
	}
	return nil
}

func nextScanCursor(lastKey []byte) []byte {
	next := make([]byte, len(lastKey)+1)
	copy(next, lastKey)
	return next
}

// CatalogGroupID returns the Raft group that owns the distribution catalog
// key in engine's current routes.
func CatalogGroupID(engine *Engine) (uint64, error) {
	if engine == nil {
		return 0, errors.New("distribution engine is required")
	}
	route, ok := engine.GetRoute(CatalogVersionKey())
	if !ok {
		return 0, errors.New("no shard route for distribution catalog key")
	}
	if route.GroupID == 0 {
		return 0, errors.New("invalid shard route for distribution catalog key")
	}
	return route.GroupID, nil
}
