package adapter

import (
	"bytes"
	"context"
	"encoding/binary"
	"log/slog"
	"math"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/bootjp/elastickv/distribution"
	"github.com/bootjp/elastickv/internal/fskeys"
	"github.com/bootjp/elastickv/internal/raftengine"
	"github.com/bootjp/elastickv/kv"
	pb "github.com/bootjp/elastickv/proto"
	"github.com/bootjp/elastickv/store"
	"github.com/cockroachdb/errors"
	"google.golang.org/genproto/googleapis/rpc/errdetails"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

// DistributionServer serves distribution related gRPC APIs.
type DistributionServer struct {
	physicalBandGate            func(context.Context) error
	mu                          sync.Mutex
	engine                      *distribution.Engine
	catalog                     *distribution.CatalogStore
	coordinator                 kv.Coordinator
	timestampAllocator          kv.TSOAllocator
	readTracker                 *kv.ActiveTimestampTracker
	watchInterval               time.Duration
	watchLeader                 func() bool
	tsoActivationGate           func(cutover, phaseD bool) error
	fsObserver                  DistributionFilesystemObserver
	readBlocked                 func() bool
	migrationCapabilityGate     SplitMigrationCapabilityGate
	splitJobRunnerReady         bool
	splitJobRunnerContexts      map[*splitJobRunnerRun]struct{}
	splitJobRunnerReadinessGate SplitMigrationCapabilityGate
	splitPromotionClientFactory SplitPromotionClientFactory
	splitMigrationClientFactory SplitMigrationClientFactory
	splitMigrationGroupFactory  SplitMigrationGroupClientFactory
	splitMigrationVoterFactory  SplitMigrationVoterFactory
	splitApplyMemberFactory     SplitMigrationApplyMemberSnapshotFactory
	ownershipRefresh            *migrationOwnershipRefresh
	knownRaftGroups             map[uint64]struct{}
	splitJobHistoryGCLast       time.Time
	splitJobFailures            map[uint64]splitJobFailureState
	reloadRetry                 struct {
		attempts int
		interval time.Duration
	}
	pb.UnimplementedDistributionServer
}

// DistributionServerOption configures DistributionServer behavior.
type DistributionServerOption func(*DistributionServer)

// WithDistributionPhysicalBandGate enables the versioned protocol only when
// a future production peer-identity and rollout gate explicitly admits it.
func WithDistributionPhysicalBandGate(gate func(context.Context) error) DistributionServerOption {
	return func(s *DistributionServer) { s.physicalBandGate = gate }
}

type splitJobRunnerRun struct{ ctx context.Context }

type DistributionFilesystemObserver interface {
	ObserveFilePinnedHotspot(reason string)
}

const DistributionFilePinnedHotspotSplitBoundary = "split_boundary"

// SplitMigrationCapabilityGate reports whether this node can safely create
// migration-only side effects. A nil gate keeps StartSplitMigration fail-closed.
type SplitMigrationCapabilityGate func(context.Context) error

// SplitPromotionClient is the subset of the internal gRPC client the split
// job runner needs to promote target-local staged rows.
type SplitPromotionClient interface {
	PromoteStagedVersions(context.Context, *pb.PromoteStagedVersionsRequest, ...grpc.CallOption) (*pb.PromoteStagedVersionsResponse, error)
}

// SplitPromotionClientFactory dials the node currently leading a split job's
// target range and returns the internal client used by the runner.
type SplitPromotionClientFactory func(context.Context, distribution.SplitJob) (SplitPromotionClient, error)

// SplitMigrationClient is the internal data-plane client used for a split
// job's source export, target import, and durable source/target guards.
type SplitMigrationClient interface {
	SplitPromotionClient
	ExportRangeVersions(context.Context, *pb.ExportRangeVersionsRequest, ...grpc.CallOption) (grpc.ServerStreamingClient[pb.ExportRangeVersionsResponse], error)
	ImportRangeVersions(context.Context, *pb.ImportRangeVersionsRequest, ...grpc.CallOption) (*pb.ImportRangeVersionsResponse, error)
	ApplyTargetStagedReadiness(context.Context, *pb.TargetStagedReadinessRequest, ...grpc.CallOption) (*pb.TargetStagedReadinessResponse, error)
	ProbeMigrationLocks(context.Context, *pb.ProbeMigrationLocksRequest, ...grpc.CallOption) (*pb.ProbeMigrationLocksResponse, error)
	CleanupMigration(context.Context, *pb.CleanupMigrationRequest, ...grpc.CallOption) (*pb.CleanupMigrationResponse, error)
	ProbeMigrationState(context.Context, *pb.ProbeMigrationStateRequest, ...grpc.CallOption) (*pb.ProbeMigrationStateResponse, error)
	IssueMigrationTimestamp(context.Context, *pb.IssueMigrationTimestampRequest, ...grpc.CallOption) (*pb.IssueMigrationTimestampResponse, error)
}

// SplitMigrationClientFactory resolves both participating group leaders.
type SplitMigrationClientFactory func(context.Context, distribution.SplitJob, uint64) (source SplitMigrationClient, target SplitMigrationClient, err error)

// SplitMigrationGroupClientFactory resolves one group without requiring the
// other participant to be available during source recovery.
type SplitMigrationGroupClientFactory func(context.Context, uint64) (SplitMigrationClient, error)

type SplitMigrationVoter struct {
	ID      string
	Address string
	Client  SplitMigrationClient
}

// SplitMigrationVoterFactory resolves the current voter set and a direct
// client for each voter. The runner re-resolves it before every barrier.
type SplitMigrationVoterFactory func(context.Context, uint64) ([]SplitMigrationVoter, error)

// WithDistributionTSOActivationGate authorizes a caller's request to activate
// the durable cutover or Phase-D marker against this node's own rollout
// configuration.
//
// Those two request booleans commit one-way markers. Distribution is registered
// on the shared Raft gRPC server and the bearer-token interceptor protects only
// the Admin service, so without this any caller that can reach the port could
// drive the group-0 leader through the staged rollout -- committing Phase D
// before every member supports it, or committing cutover on a node whose
// coordinator is still on the legacy issuance path. The wire fields say what the
// caller wants; the gate says what this node is configured to do.
//
// Leaving it unset keeps the previous behaviour, which suits tests and the
// single-node demo.
func WithDistributionTSOActivationGate(gate func(cutover, phaseD bool) error) DistributionServerOption {
	return func(s *DistributionServer) {
		s.tsoActivationGate = gate
	}
}

// WithDistributionCoordinator configures the coordinator used for Raft-backed
// catalog mutations in SplitRange.
func WithDistributionCoordinator(coordinator kv.Coordinator) DistributionServerOption {
	return func(s *DistributionServer) {
		s.coordinator = coordinator
	}
}

// WithDistributionTimestampAllocator exposes the local dedicated TSO
// allocator through GetTimestamp. The allocator itself rejects followers, so
// clients can re-resolve the group-0 leader without a forwarding loop.
func WithDistributionTimestampAllocator(allocator kv.TSOAllocator) DistributionServerOption {
	return func(s *DistributionServer) {
		s.timestampAllocator = allocator
	}
}

func WithDistributionActiveTimestampTracker(tracker *kv.ActiveTimestampTracker) DistributionServerOption {
	return func(s *DistributionServer) {
		s.readTracker = tracker
	}
}

func WithDistributionFilesystemObserver(observer DistributionFilesystemObserver) DistributionServerOption {
	return func(s *DistributionServer) {
		s.fsObserver = observer
	}
}

func WithDistributionReadGate(blocked func() bool) DistributionServerOption {
	return func(s *DistributionServer) {
		s.readBlocked = blocked
	}
}

func WithSplitMigrationCapabilityGate(gate SplitMigrationCapabilityGate) DistributionServerOption {
	return func(s *DistributionServer) {
		s.migrationCapabilityGate = gate
	}
}

// WithSplitJobRunnerReady explicitly overrides the runner lifecycle check.
// It is retained for tests; production can use RunSplitJobRunner's lifecycle.
func WithSplitJobRunnerReady() DistributionServerOption {
	return func(s *DistributionServer) {
		s.splitJobRunnerReady = true
	}
}

// WithSplitJobRunnerReadinessGate configures local runtime gates that must be
// open before this node advertises split migration capability.
func WithSplitJobRunnerReadinessGate(gate SplitMigrationCapabilityGate) DistributionServerOption {
	return func(s *DistributionServer) {
		s.splitJobRunnerReadinessGate = gate
	}
}

// WithSplitPromotionClientFactory configures the client factory used by the
// split job runner to promote target-local staged versions.
func WithSplitPromotionClientFactory(factory SplitPromotionClientFactory) DistributionServerOption {
	return func(s *DistributionServer) {
		s.splitPromotionClientFactory = factory
	}
}

// WithSplitMigrationClientFactory configures the source/target clients used by
// the production split job state machine.
func WithSplitMigrationClientFactory(factory SplitMigrationClientFactory) DistributionServerOption {
	return func(s *DistributionServer) {
		s.splitMigrationClientFactory = factory
	}
}

func WithSplitMigrationGroupClientFactory(factory SplitMigrationGroupClientFactory) DistributionServerOption {
	return func(s *DistributionServer) {
		s.splitMigrationGroupFactory = factory
	}
}

func WithSplitMigrationVoterFactory(factory SplitMigrationVoterFactory) DistributionServerOption {
	return func(s *DistributionServer) {
		s.splitMigrationVoterFactory = factory
	}
}

// WithDistributionKnownRaftGroups configures the Raft group IDs this node can
// route migration work to.
func WithDistributionKnownRaftGroups(groupIDs ...uint64) DistributionServerOption {
	return func(s *DistributionServer) {
		groups := make(map[uint64]struct{}, len(groupIDs))
		for _, groupID := range groupIDs {
			if groupID == 0 {
				continue
			}
			groups[groupID] = struct{}{}
		}
		s.knownRaftGroups = groups
	}
}

// WithCatalogReloadRetryPolicy configures the retry policy used after split
// commit when waiting for the local catalog snapshot to become visible.
func WithCatalogReloadRetryPolicy(attempts int, interval time.Duration) DistributionServerOption {
	return func(s *DistributionServer) {
		if attempts > 0 {
			s.reloadRetry.attempts = attempts
		}
		if interval > 0 {
			s.reloadRetry.interval = interval
		}
	}
}

// WithCatalogWatchInterval sets how often an idle catalog stream checks for a
// newly committed version.
func WithCatalogWatchInterval(interval time.Duration) DistributionServerOption {
	return func(s *DistributionServer) {
		if interval > 0 {
			s.watchInterval = interval
		}
	}
}

// WithCatalogWatchLeaderCheck restricts long-lived catalog streams to the
// current default-group leader. Existing callers without a check retain the
// package-level server behavior used by tests and embedded deployments.
func WithCatalogWatchLeaderCheck(check func() bool) DistributionServerOption {
	return func(s *DistributionServer) {
		s.watchLeader = check
	}
}

const (
	childRouteCount                = 2
	splitMutationOpCount           = childRouteCount + 3
	listSplitJobsDefaultPageSize   = 200
	splitJobListCursorVersion      = byte(1)
	splitJobListCursorTerminalOff  = 1
	splitJobListCursorJobIDOff     = splitJobListCursorTerminalOff + 8
	splitJobListCursorEncodedBytes = splitJobListCursorJobIDOff + 8
	SplitMigrationCapabilityV2     = "cap_migration_v2"
	splitMigrationCapabilityV2     = SplitMigrationCapabilityV2

	splitPromotionDefaultMaxVersions = 1024
	splitPromotionBytesPerMiB        = 1024 * 1024
	splitPromotionMaxBytesMiB        = 4
	splitPromotionMaxScannedMiB      = 16
	splitPromotionAttemptTimeoutSecs = 2
	promotionCompleteBaseOpCount     = 2
)

var (
	defaultCatalogReloadRetryAttempts   = 20
	defaultCatalogReloadRetryInterval   = 10 * time.Millisecond
	defaultSplitJobRunnerInterval       = time.Second
	defaultSplitPromotionMaxVersions    = uint32(splitPromotionDefaultMaxVersions)
	defaultSplitPromotionMaxBytes       = uint64(splitPromotionMaxBytesMiB * splitPromotionBytesPerMiB)
	defaultSplitPromotionMaxScanned     = uint64(splitPromotionMaxScannedMiB * splitPromotionBytesPerMiB)
	defaultSplitPromotionAttemptTimeout = time.Duration(splitPromotionAttemptTimeoutSecs) * time.Second
	defaultCatalogWatchInterval         = 100 * time.Millisecond

	errDistributionCatalogNotConfigured   = errors.New("route catalog is not configured")
	errDistributionUnknownRoute           = errors.New("unknown route")
	errDistributionInvalidSplitKey        = errors.New("invalid split key")
	errDistributionSplitKeyAtBoundary     = errors.New("split key at route boundary")
	errDistributionCatalogConflict        = errors.New("catalog version conflict")
	errDistributionRouteIDOverflow        = errors.New("route id overflow")
	errDistributionNotLeader              = errors.New("not leader for distribution catalog")
	errDistributionCoordinatorRequired    = errors.New("distribution coordinator is not configured")
	errDistributionEngineNotConfigured    = errors.New("distribution engine is not configured")
	errDistributionCatalogVersionNotFound = errors.New("route catalog version not found")
	errDistributionClusterNotReady        = errors.New("cluster is not ready for split migration")
	errDistributionRaftGroupsNotKnown     = errors.New("distribution raft groups are not configured")
	errDistributionUnknownTargetGroup     = errors.New("unknown target group")
	errDistributionSourceRouteNotActive   = errors.New("source route is not active")
	errDistributionCatalogMutationInvalid = errors.New("catalog store mutation is invalid")
)

// NewDistributionServer creates a new server.
func NewDistributionServer(e *distribution.Engine, catalog *distribution.CatalogStore, opts ...DistributionServerOption) *DistributionServer {
	s := &DistributionServer{
		engine:        e,
		catalog:       catalog,
		watchInterval: defaultCatalogWatchInterval,
	}
	s.reloadRetry.attempts = defaultCatalogReloadRetryAttempts
	s.reloadRetry.interval = defaultCatalogReloadRetryInterval
	for _, opt := range opts {
		if opt != nil {
			opt(s)
		}
	}
	return s
}

func (s *DistributionServer) SetReadGate(blocked func() bool) {
	if s != nil {
		s.readBlocked = blocked
	}
}

func (s *DistributionServer) requireReadReady() error {
	if s != nil && s.readBlocked != nil && s.readBlocked() {
		//nolint:wrapcheck // Preserve the gRPC status code for startup readers.
		return status.Error(codes.Unavailable, "distribution startup has not completed")
	}
	return nil
}

func (s *DistributionServer) RunSplitJobRunner(ctx context.Context) error {
	if ctx == nil {
		ctx = context.Background()
	}
	if !s.splitJobRunnerConfigured() || ctx.Err() != nil {
		return nil
	}
	run := &splitJobRunnerRun{ctx: ctx}
	s.mu.Lock()
	if s.splitJobRunnerContexts == nil {
		s.splitJobRunnerContexts = make(map[*splitJobRunnerRun]struct{})
	}
	s.splitJobRunnerContexts[run] = struct{}{}
	s.mu.Unlock()
	defer func() {
		s.mu.Lock()
		delete(s.splitJobRunnerContexts, run)
		s.mu.Unlock()
	}()
	ticker := time.NewTicker(defaultSplitJobRunnerInterval)
	defer ticker.Stop()
	for {
		continueSoon, err := s.runSplitJobRunnerOnce(ctx)
		if err != nil {
			if !splitJobRunnerContextDone(err) {
				slog.Warn("split job runner tick failed", "err", err)
			}
		}
		if !waitSplitJobRunner(ctx, ticker.C, continueSoon && err == nil) {
			return nil
		}
	}
}

func (s *DistributionServer) RunSplitJobRunnerOnce(ctx context.Context) error {
	_, err := s.runSplitJobRunnerOnce(ctx)
	return err
}

func (s *DistributionServer) runSplitJobRunnerOnce(ctx context.Context) (bool, error) {
	if !s.splitJobRunnerConfigured() {
		return false, nil
	}
	leader, err := s.verifySplitJobRunnerLeader(ctx)
	if err != nil || !leader {
		return false, err
	}
	jobs, err := s.catalog.ListSplitJobs(ctx)
	if err != nil {
		return false, splitJobCatalogStatusError(err)
	}
	if job, ok := nextRunnableSplitJob(jobs); ok {
		return s.runSplitJobRunnerJob(ctx, job)
	}
	return false, s.gcSplitJobHistory(ctx, jobs, time.Now())
}

func (s *DistributionServer) runSplitJobRunnerJob(ctx context.Context, job distribution.SplitJob) (bool, error) {
	if err := s.verifySplitJobCleanupDispatch(ctx, job); err != nil {
		return false, err
	}
	if job.Phase != distribution.SplitJobPhaseAbandoning {
		ready, err := s.splitJobCapabilityReady(ctx, job)
		if err != nil || !ready {
			return false, err
		}
	}
	if err := s.runSplitJobAttempt(ctx, job); err != nil {
		return false, err
	}
	return s.splitJobPreflightContinuation(ctx, job)
}

func (s *DistributionServer) splitJobCapabilityReady(ctx context.Context, job distribution.SplitJob) (bool, error) {
	if s.migrationCapabilityGate == nil {
		return true, nil
	}
	gateErr := s.migrationCapabilityGate(ctx)
	if gateErr != nil {
		return s.handleSplitJobCapabilityRegression(ctx, job, gateErr)
	}
	if !job.CapabilityRegressed {
		return true, nil
	}
	return s.clearSplitJobCapabilityRegression(ctx, job)
}

func (s *DistributionServer) handleSplitJobCapabilityRegression(ctx context.Context, job distribution.SplitJob, cause error) (bool, error) {
	markedJob, marked, err := s.markSplitJobCapabilityRegressed(ctx, job, cause)
	if err != nil || !marked {
		return false, err
	}
	if splitJobCapabilityRegressionRequiresFailClosed(markedJob) {
		closed, err := s.ensureSplitJobCapabilityRegressionFailClosed(ctx, markedJob)
		if err != nil || !closed {
			return false, err
		}
	}
	return false, nil
}

func (s *DistributionServer) markSplitJobCapabilityRegressed(ctx context.Context, job distribution.SplitJob, cause error) (distribution.SplitJob, bool, error) {
	marked := false
	markedJob := job
	err := s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase != job.Phase {
			return current, nil
		}
		marked = true
		if !current.CapabilityRegressed {
			current.CapabilityRegressed = true
			current.LastError = "cluster migration capability regressed: " + cause.Error()
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		markedJob = distribution.CloneSplitJob(current)
		return current, nil
	})
	if err != nil || !marked {
		return job, marked, err
	}
	return markedJob, true, nil
}

func (s *DistributionServer) clearSplitJobCapabilityRegression(ctx context.Context, job distribution.SplitJob) (bool, error) {
	if splitJobCapabilityRegressionRequiresFailClosed(job) {
		restored, err := s.restoreSplitJobCapabilityRegressionGuards(ctx, job)
		if err != nil || !restored {
			return false, err
		}
	}
	err := s.updateSplitJobViaCoordinator(ctx, job.JobID, func(current distribution.SplitJob) (distribution.SplitJob, error) {
		if current.Phase == job.Phase && current.CapabilityRegressed {
			current.CapabilityRegressed = false
			current.LastError = ""
			current.UpdatedAtMs = time.Now().UnixMilli()
		}
		return current, nil
	})
	return false, err
}

func (s *DistributionServer) splitJobRunnerConfigured() bool {
	return s != nil && s.catalog != nil && s.coordinator != nil && s.splitPromotionClientFactory != nil && s.splitMigrationClientFactory != nil
}

func (s *DistributionServer) verifySplitJobRunnerLeader(ctx context.Context) (bool, error) {
	if !s.coordinator.IsLeaderForKey(distribution.CatalogVersionKey()) {
		return false, nil
	}
	if err := s.coordinator.VerifyLeaderForKey(ctx, distribution.CatalogVersionKey()); err != nil {
		return false, errors.WithStack(err)
	}
	return true, nil
}

func nextRunnableSplitJob(jobs []distribution.SplitJob) (distribution.SplitJob, bool) {
	for _, job := range jobs {
		switch job.Phase {
		case distribution.SplitJobPhasePlanned,
			distribution.SplitJobPhaseBackfill,
			distribution.SplitJobPhaseFence,
			distribution.SplitJobPhaseDeltaCopy,
			distribution.SplitJobPhaseCutover,
			distribution.SplitJobPhaseCleanup,
			distribution.SplitJobPhaseAbandoning:
			return job, true
		case distribution.SplitJobPhaseNone,
			distribution.SplitJobPhaseDone,
			distribution.SplitJobPhaseFailed,
			distribution.SplitJobPhaseAbandoned:
			continue
		}
	}
	return distribution.SplitJob{}, false
}

func (s *DistributionServer) promoteSplitJobTargetAndComplete(ctx context.Context, job distribution.SplitJob) error {
	if !job.TargetPromotionDone {
		client, err := s.splitPromotionClientFactory(ctx, job)
		if err != nil {
			return errors.WithStack(err)
		}
		if client == nil {
			return errors.New("split promotion client is nil")
		}
		if err := promoteSplitJobTarget(ctx, client, job); err != nil {
			return errors.WithStack(err)
		}
	}
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return err
	}
	current, found, err := s.catalog.SplitJobAt(ctx, job.JobID, snapshot.ReadTS)
	if err != nil {
		return splitJobPromotionStatusError(err)
	}
	if !found {
		return splitJobPromotionStatusError(distribution.ErrCatalogSplitJobConflict)
	}
	completed, _, err := s.completeSplitJobTargetPromotionViaCoordinator(ctx, snapshot.Version, current, time.Now().UnixMilli())
	if err != nil {
		return err
	}
	return s.applyEngineSnapshot(completed)
}

func promoteSplitJobTarget(ctx context.Context, client SplitPromotionClient, job distribution.SplitJob) error {
	var cursor []byte
	for {
		attemptCtx, cancel := splitPromotionAttemptContext(ctx)
		resp, err := client.PromoteStagedVersions(attemptCtx, &pb.PromoteStagedVersionsRequest{
			JobId:           job.JobID,
			Cursor:          cursor,
			MaxVersions:     defaultSplitPromotionMaxVersions,
			MaxBytes:        defaultSplitPromotionMaxBytes,
			MaxScannedBytes: defaultSplitPromotionMaxScanned,
		})
		cancel()
		if err != nil {
			return errors.WithStack(err)
		}
		if resp.GetDone() {
			return nil
		}
		next := resp.GetNextCursor()
		if len(next) == 0 || bytes.Equal(next, cursor) {
			return errors.New("split promotion made no cursor progress")
		}
		cursor = distribution.CloneBytes(next)
	}
}

func splitPromotionAttemptContext(ctx context.Context) (context.Context, context.CancelFunc) {
	if ctx == nil {
		ctx = context.Background()
	}
	if defaultSplitPromotionAttemptTimeout <= 0 {
		return ctx, func() {}
	}
	return context.WithTimeout(ctx, defaultSplitPromotionAttemptTimeout)
}

func splitJobRunnerContextDone(err error) bool {
	if errors.Is(err, context.Canceled) || errors.Is(err, context.DeadlineExceeded) {
		return true
	}
	code := status.Code(errors.Cause(err))
	return code == codes.Canceled || code == codes.DeadlineExceeded
}

// UpdateRoute allows updating route information.
func (s *DistributionServer) UpdateRoute(start, end []byte, group uint64) {
	s.engine.UpdateRoute(start, end, group)
}

// GetRoute returns route for a key.
func (s *DistributionServer) GetRoute(ctx context.Context, req *pb.GetRouteRequest) (*pb.GetRouteResponse, error) {
	if err := s.requireReadReady(); err != nil {
		return nil, err
	}
	r, ok := s.engine.GetRoute(kv.RouteOwnershipKey(req.Key))
	if !ok {
		return &pb.GetRouteResponse{}, nil
	}
	return &pb.GetRouteResponse{
		Start:       r.Start,
		End:         r.End,
		RaftGroupId: r.GroupID,
	}, nil
}

// GetTimestamp returns the base of a consecutive timestamp window. When a
// dedicated allocator is configured, only the local group-0 leader can serve
// the request and the returned window is already durable in that Raft group.
func (s *DistributionServer) GetTimestamp(ctx context.Context, req *pb.GetTimestampRequest) (*pb.GetTimestampResponse, error) {
	count, minTimestamp, err := timestampRequestValues(req)
	if err != nil {
		return nil, err
	}
	if req != nil && req.GetReservationProtocolVersion() != 0 {
		return s.physicalBandTimestamp(ctx, req, count, minTimestamp)
	}
	activateCutover, activatePhaseD, err := timestampActivationValues(req)
	if err != nil {
		return nil, err
	}
	if err := s.authorizeTSOActivation(activateCutover, activatePhaseD); err != nil {
		return nil, err
	}
	if s.timestampAllocator == nil {
		return s.legacyTimestampResponse(count, minTimestamp, activateCutover, activatePhaseD)
	}

	reservation, err := s.allocateTimestampReservation(ctx, count, minTimestamp, activateCutover, activatePhaseD)
	if err != nil {
		return nil, timestampRPCError(err)
	}
	if err := validateTimestampReservation(reservation, count, minTimestamp); err != nil {
		return nil, errors.WithStack(status.Error(codes.Internal, err.Error()))
	}
	return &pb.GetTimestampResponse{
		Timestamp:               reservation.Base,
		CommittedByDedicatedTso: true,
		Count:                   uint32(count), //nolint:gosec // count is bounded by MaxTSOBatchSize.
		PreviousAllocationFloor: reservation.PreviousAllocationFloor,
		CutoverActive:           reservation.CutoverActive,
		PhaseDActive:            reservation.PhaseDActive,
		PhaseDFloor:             reservation.PhaseDFloor,
	}, nil
}

func (s *DistributionServer) physicalBandTimestamp(ctx context.Context, req *pb.GetTimestampRequest, count int, min uint64) (*pb.GetTimestampResponse, error) {
	if req.GetReservationProtocolVersion() != kv.TSOPhysicalBandProtocolVersion {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "unsupported TSO reservation protocol version"))
	}
	if req.GetActivateCutover() || req.GetActivatePhaseD() {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "physical-band reservation cannot activate TSO modes"))
	}
	if s.physicalBandGate == nil {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "physical-band reservation is not activated"))
	}
	if err := s.physicalBandGate(ctx); err != nil {
		return nil, errors.WithStack(status.Error(codes.PermissionDenied, "physical-band reservation is not authorized"))
	}
	allocator, ok := s.timestampAllocator.(kv.TSOPhysicalBandAllocator)
	if !ok {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "physical-band reservation is unavailable"))
	}
	reservation, err := allocator.ReservePhysicalBandAfter(ctx, count, min)
	if err != nil {
		return nil, timestampRPCError(err)
	}
	if err := validatePhysicalBandReservation(reservation, count, min); err != nil {
		return nil, errors.WithStack(status.Error(codes.Internal, err.Error()))
	}
	return &pb.GetTimestampResponse{
		Timestamp:                  reservation.Base,
		Count:                      uint32(count), //nolint:gosec // timestampRequestValues bounds count.
		CommittedByDedicatedTso:    true,
		ReservationProtocolVersion: kv.TSOPhysicalBandProtocolVersion,
		CommittedBandEnd:           reservation.CommittedBandEnd,
		PreviousIssuedCursor:       reservation.PreviousIssuedCursor,
	}, nil
}

func validatePhysicalBandReservation(r kv.TSOPhysicalBandReservation, count int, min uint64) error {
	if err := validateTimestampWindow(r.Base, count, min); err != nil {
		return err
	}
	end := r.Base + uint64(count) - 1 //nolint:gosec // count is positive, bounded, and overflow was checked above.
	if r.Count != count || r.CommittedBandEnd < end || r.CommittedBandEnd&0xffff != 0xffff ||
		r.Base>>16 != r.CommittedBandEnd>>16 || r.PreviousIssuedCursor >= r.Base ||
		(r.PreviousIssuedCursor != 0 && r.PreviousIssuedCursor>>16 != r.Base>>16) {
		return errors.New("invalid physical-band reservation metadata")
	}
	return nil
}

func timestampActivationValues(req *pb.GetTimestampRequest) (bool, bool, error) {
	activateCutover := req != nil && req.GetActivateCutover()
	activatePhaseD := req != nil && req.GetActivatePhaseD()
	if activatePhaseD && !activateCutover {
		return false, false, errors.WithStack(status.Error(codes.InvalidArgument,
			"phase D activation requires cutover activation"))
	}
	return activateCutover, activatePhaseD, nil
}

// authorizeTSOActivation checks an activation request against this node's own
// rollout configuration before the one-way marker is committed.
func (s *DistributionServer) authorizeTSOActivation(activateCutover, activatePhaseD bool) error {
	if s.tsoActivationGate == nil {
		return nil
	}
	// A marker another leader already committed is not an activation request.
	// Following it is mandatory, and this node's own mode file can still name
	// the preceding stage until its next reload -- refusing would answer every
	// reservation with PermissionDenied, which isTransientTSORouteError does not
	// retry, so allocation and writes would stall cluster-wide until the local
	// configuration caught up.
	cutover, phaseD := s.pendingTSOActivation(activateCutover, activatePhaseD)
	if !cutover && !phaseD {
		return nil
	}
	if err := s.tsoActivationGate(cutover, phaseD); err != nil {
		return errors.WithStack(status.Error(codes.PermissionDenied, err.Error()))
	}
	return nil
}

// pendingTSOActivation narrows a request's activation flags to the markers that
// are not durable yet.
// The two markers are probed independently. A single two-method assertion fails
// entirely when an allocator exposes only one of them, which silently restores
// the outage this narrowing exists to prevent.
func (s *DistributionServer) pendingTSOActivation(activateCutover, activatePhaseD bool) (bool, bool) {
	if cutover, ok := s.timestampAllocator.(interface{ CutoverActive() bool }); ok && cutover.CutoverActive() {
		activateCutover = false
	}
	if phaseD, ok := s.timestampAllocator.(interface{ PhaseDActive() bool }); ok && phaseD.PhaseDActive() {
		activatePhaseD = false
	}
	return activateCutover, activatePhaseD
}

func (s *DistributionServer) legacyTimestampResponse(
	count int,
	minTimestamp uint64,
	activateCutover bool,
	activatePhaseD bool,
) (*pb.GetTimestampResponse, error) {
	if count != 1 || minTimestamp != 0 || activateCutover || activatePhaseD {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "dedicated TSO allocator is not configured"))
	}
	if s.engine == nil {
		return nil, errors.WithStack(status.Error(codes.Unavailable, "distribution engine is not configured"))
	}
	return &pb.GetTimestampResponse{Timestamp: s.engine.NextTimestamp()}, nil
}

// ValidateTimestamp verifies a read/start timestamp against the durable M7
// allocation range. The local allocator performs the group-0 leader fence;
// followers reject so clients re-resolve rather than validating stale state.
func (s *DistributionServer) ValidateTimestamp(
	ctx context.Context,
	req *pb.ValidateTimestampRequest,
) (*pb.ValidateTimestampResponse, error) {
	if req == nil || req.GetTimestamp() == 0 {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "timestamp is required"))
	}
	if req.GetLegacyResolution() {
		return s.validateLegacyResolutionTimestamp(ctx, req)
	}
	if req.GetStartTimestamp() != 0 {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "start timestamp requires legacy resolution mode"))
	}
	validator, ok := s.timestampAllocator.(kv.DurableTimestampValidator)
	if !ok {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition,
			"dedicated TSO timestamp validation is not configured"))
	}
	if err := validator.ValidateDurableTimestamp(ctx, req.GetTimestamp()); err != nil {
		return nil, timestampRPCError(err)
	}
	resp := &pb.ValidateTimestampResponse{Valid: true, PhaseDActive: true}
	if state, ok := s.timestampAllocator.(interface {
		PhaseDFloor() uint64
		AllocationFloor() uint64
	}); ok {
		resp.PhaseDFloor = state.PhaseDFloor()
		resp.AllocationFloor = state.AllocationFloor()
	}
	return resp, nil
}

func (s *DistributionServer) validateLegacyResolutionTimestamp(ctx context.Context, req *pb.ValidateTimestampRequest) (*pb.ValidateTimestampResponse, error) {
	if req.GetStartTimestamp() == 0 || req.GetStartTimestamp() >= req.GetTimestamp() {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "legacy resolution requires 0 < start < commit"))
	}
	validator, ok := s.timestampAllocator.(kv.DurableLegacyResolutionValidator)
	if !ok {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "pending legacy resolution validation is not configured"))
	}
	if err := validator.ValidateLegacyResolutionTimestamps(ctx, req.GetStartTimestamp(), req.GetTimestamp()); err != nil {
		return nil, timestampRPCError(err)
	}
	return &pb.ValidateTimestampResponse{Valid: true, LegacyResolutionValidated: true}, nil
}

func (s *DistributionServer) allocateTimestampReservation(
	ctx context.Context,
	count int,
	minTimestamp uint64,
	activateCutover bool,
	activatePhaseD bool,
) (kv.TSOReservation, error) {
	if allocator, ok := s.timestampAllocator.(kv.TSOReservationAllocator); ok {
		reservation, err := allocator.ReserveBatchAfter(ctx, count, minTimestamp, activateCutover, activatePhaseD)
		return reservation, errors.Wrap(err, "reserve dedicated TSO window")
	}
	reservation := kv.TSOReservation{Count: count}
	switch {
	case activateCutover || activatePhaseD:
		return reservation, errors.WithStack(status.Error(codes.FailedPrecondition,
			"TSO allocator does not support durable cutover"))
	case minTimestamp > 0:
		return reservation, errors.WithStack(status.Error(codes.FailedPrecondition,
			"TSO allocator does not support durable reservation metadata"))
	default:
		base, err := s.timestampAllocator.NextBatch(ctx, count)
		reservation.Base = base
		return reservation, errors.Wrap(err, "reserve TSO window")
	}
}

func validateTimestampWindow(base uint64, count int, minTimestamp uint64) error {
	if base == 0 || base <= minTimestamp {
		return errors.Errorf("dedicated TSO returned base %d at or below minimum %d", base, minTimestamp)
	}
	size := uint64(count) //nolint:gosec // count is positive and bounded by timestampRequestValues.
	if base > math.MaxUint64-(size-1) {
		return errors.Errorf("dedicated TSO returned overflowing window base=%d count=%d", base, count)
	}
	return nil
}

func validateTimestampReservation(reservation kv.TSOReservation, count int, minTimestamp uint64) error {
	if err := validateTimestampWindow(reservation.Base, count, minTimestamp); err != nil {
		return err
	}
	if reservation.Count != count {
		return errors.Errorf("dedicated TSO returned count %d, want %d", reservation.Count, count)
	}
	if reservation.PreviousAllocationFloor >= reservation.Base {
		return errors.Errorf("dedicated TSO returned base %d at or below previous floor %d",
			reservation.Base, reservation.PreviousAllocationFloor)
	}
	return nil
}

func timestampRequestValues(req *pb.GetTimestampRequest) (int, uint64, error) {
	if req == nil {
		return 1, 0, nil
	}
	count := req.GetCount()
	if count == 0 {
		count = 1
	}
	if count > uint32(kv.MaxTSOBatchSize) {
		return 0, 0, status.Errorf(codes.InvalidArgument, "timestamp count %d exceeds maximum %d", count, kv.MaxTSOBatchSize)
	}
	return int(count), req.GetMinTimestamp(), nil
}

func timestampRPCError(err error) error {
	if code := status.Code(err); code != codes.Unknown {
		return err
	}
	if mapped := phaseDActivationRPCError(err); mapped != nil {
		return mapped
	}
	switch {
	case errors.Is(err, context.Canceled):
		return errors.WithStack(status.Error(codes.Canceled, err.Error()))
	case errors.Is(err, context.DeadlineExceeded):
		return errors.WithStack(status.Error(codes.DeadlineExceeded, err.Error()))
	case errors.Is(err, kv.ErrInvalidTSOBatchSize), errors.Is(err, kv.ErrTxnCommitTSRequired):
		return errors.WithStack(status.Error(codes.InvalidArgument, err.Error()))
	case errors.Is(err, kv.ErrTSONotLeader), errors.Is(err, kv.ErrLeaderNotFound):
		return errors.WithStack(status.Error(codes.FailedPrecondition, err.Error()))
	case errors.Is(err, kv.ErrTSOTimestampPrePhaseD):
		return errors.WithStack(status.Error(codes.OutOfRange, err.Error()))
	case errors.Is(err, kv.ErrTSOTimestampInvalid):
		return errors.WithStack(status.Error(codes.InvalidArgument, err.Error()))
	default:
		return errors.WithStack(status.Error(codes.Unavailable, err.Error()))
	}
}

func phaseDActivationRPCError(err error) error {
	switch {
	case errors.Is(err, kv.ErrTSOPhaseDInactive):
		return inactiveTimestampRPCError(err)
	case errors.Is(err, kv.ErrTSOPhaseDActivationPending):
		return errors.WithStack(status.Error(codes.ResourceExhausted, err.Error()))
	case errors.Is(err, kv.ErrTSOPhaseDActivationGateRequired):
		return errors.WithStack(status.Error(codes.FailedPrecondition, err.Error()))
	default:
		return nil
	}
}

func inactiveTimestampRPCError(err error) error {
	s := status.New(codes.FailedPrecondition, err.Error())
	withDetail, detailErr := s.WithDetails(&errdetails.ErrorInfo{
		Domain: kv.TSOValidationErrorDomain, Reason: kv.TSOPhaseDInactiveReason,
	})
	if detailErr != nil {
		return errors.WithStack(s.Err())
	}
	return errors.WithStack(withDetail.Err())
}

// ListRoutes returns all durable routes from catalog storage.
func (s *DistributionServer) ListRoutes(ctx context.Context, req *pb.ListRoutesRequest) (*pb.ListRoutesResponse, error) {
	if err := s.requireReadReady(); err != nil {
		return nil, err
	}
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return nil, err
	}

	return &pb.ListRoutesResponse{
		CatalogVersion: snapshot.Version,
		Routes:         toProtoRouteDescriptors(snapshot.Routes),
	}, nil
}

func (s *DistributionServer) GetRouteOwnership(ctx context.Context, req *pb.GetRouteOwnershipRequest) (*pb.GetRouteOwnershipResponse, error) {
	if err := s.requireReadReady(); err != nil {
		return nil, err
	}
	snapshot, err := s.routeSnapshotAt(req.GetCatalogVersion())
	if err != nil {
		return nil, err
	}
	// Normalized exactly like GetRoute above. An internal storage key -- a
	// filesystem chunk, a Redis collection row -- routes by its logical key,
	// so looking the raw bytes up in the snapshot answers with the owner of
	// the raw family prefix instead of the group that actually owned the key
	// at that catalog version.
	route, ok := snapshot.RouteOf(kv.RouteOwnershipKey(req.GetKey()))
	if !ok {
		return &pb.GetRouteOwnershipResponse{
			CatalogVersion: snapshot.Version(),
			Found:          false,
		}, nil
	}
	return &pb.GetRouteOwnershipResponse{
		Route:          toProtoRoute(route),
		CatalogVersion: snapshot.Version(),
		Found:          true,
	}, nil
}

func (s *DistributionServer) GetIntersectingRoutes(ctx context.Context, req *pb.GetIntersectingRoutesRequest) (*pb.GetIntersectingRoutesResponse, error) {
	if err := s.requireReadReady(); err != nil {
		return nil, err
	}
	snapshot, err := s.routeSnapshotAt(req.GetCatalogVersion())
	if err != nil {
		return nil, err
	}
	end := req.GetEnd()
	if len(end) == 0 {
		end = nil
	}
	routes := snapshot.IntersectingRoutes(req.GetStart(), end)
	out := make([]*pb.RouteDescriptor, 0, len(routes))
	for _, route := range routes {
		out = append(out, toProtoRoute(route))
	}
	return &pb.GetIntersectingRoutesResponse{
		Routes:         out,
		CatalogVersion: snapshot.Version(),
	}, nil
}

func (s *DistributionServer) StartSplitMigration(ctx context.Context, req *pb.StartSplitMigrationRequest) (*pb.StartSplitMigrationResponse, error) {
	if err := s.verifyStartSplitMigrationPreflight(ctx, req); err != nil {
		return nil, err
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	if err := s.verifyStartSplitMigrationCatalogReady(ctx); err != nil {
		return nil, err
	}
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return nil, err
	}
	defer releaseReadPin(s.pinReadTS(snapshot.ReadTS))

	parent, err := s.startSplitMigrationParent(ctx, snapshot, req)
	if err != nil {
		return nil, err
	}
	job, err := s.newSplitMigrationJob(ctx, snapshot, parent, req)
	if err != nil {
		return nil, err
	}
	if err := s.createSplitJobViaCoordinator(ctx, snapshot.ReadTS, job); err != nil {
		return nil, err
	}
	return &pb.StartSplitMigrationResponse{
		CatalogVersion: snapshot.Version,
		JobId:          job.JobID,
	}, nil
}

func (s *DistributionServer) GetSplitMigrationCapability(ctx context.Context, _ *pb.GetSplitMigrationCapabilityRequest) (*pb.GetSplitMigrationCapabilityResponse, error) {
	if !s.splitMigrationCapabilityReady(ctx) {
		return &pb.GetSplitMigrationCapabilityResponse{}, nil
	}
	return &pb.GetSplitMigrationCapabilityResponse{
		MigrationCapable: true,
		Capabilities:     []string{splitMigrationCapabilityV2},
	}, nil
}

func (s *DistributionServer) splitMigrationCapabilityReady(ctx context.Context) bool {
	if s == nil || (!s.splitJobRunnerReady && (!s.splitJobRunnerConfigured() || !s.splitJobRunnerRunning())) {
		return false
	}
	if ctx != nil && ctx.Err() != nil {
		return false
	}
	if s.splitJobRunnerReadinessGate == nil {
		return true
	}
	return s.splitJobRunnerReadinessGate(ctx) == nil
}

func (s *DistributionServer) splitJobRunnerRunning() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	for run := range s.splitJobRunnerContexts {
		if run.ctx.Err() == nil {
			return true
		}
	}
	return false
}

func (s *DistributionServer) verifyStartSplitMigrationPreflight(ctx context.Context, req *pb.StartSplitMigrationRequest) error {
	if req.GetTargetGroupId() == 0 {
		return grpcStatusError(codes.InvalidArgument, distribution.ErrCatalogSplitJobTargetGroupRequired.Error())
	}
	if err := s.verifyStartSplitMigrationCatalogReady(ctx); err != nil {
		return err
	}
	return s.verifySplitMigrationCapability(ctx)
}

func (s *DistributionServer) verifyStartSplitMigrationCatalogReady(ctx context.Context) error {
	if err := s.verifyCatalogLeader(ctx); err != nil {
		return err
	}
	if s.catalog == nil {
		return grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	return nil
}

func (s *DistributionServer) startSplitMigrationParent(
	ctx context.Context,
	snapshot distribution.CatalogSnapshot,
	req *pb.StartSplitMigrationRequest,
) (distribution.RouteDescriptor, error) {
	if err := validateExpectedCatalogVersion(snapshot.Version, req.GetExpectedCatalogVersion()); err != nil {
		return distribution.RouteDescriptor{}, err
	}
	parent, found := findRouteByID(snapshot.Routes, req.GetRouteId())
	if !found {
		return distribution.RouteDescriptor{}, grpcStatusError(codes.NotFound, errDistributionUnknownRoute.Error())
	}
	if parent.State != distribution.RouteStateActive {
		return distribution.RouteDescriptor{}, grpcStatusError(codes.FailedPrecondition, errDistributionSourceRouteNotActive.Error())
	}
	splitKey := normalizeSplitMigrationSplitKey(req)
	if err := validateSplitKey(parent, splitKey); err != nil {
		return distribution.RouteDescriptor{}, err
	}
	if err := distribution.ValidateSplitMigrationRouteRange(splitKey, parent.End); err != nil {
		return distribution.RouteDescriptor{}, splitMigrationRangeStatusError(err)
	}
	if parent.GroupID == req.GetTargetGroupId() {
		return distribution.RouteDescriptor{}, grpcStatusError(codes.InvalidArgument, "target group must differ from source route group")
	}
	if err := s.verifyKnownTargetGroup(req.GetTargetGroupId()); err != nil {
		return distribution.RouteDescriptor{}, err
	}
	if err := s.rejectLiveSplitJob(ctx, snapshot, parent); err != nil {
		return distribution.RouteDescriptor{}, err
	}
	return parent, nil
}

func (s *DistributionServer) newSplitMigrationJob(
	ctx context.Context,
	snapshot distribution.CatalogSnapshot,
	parent distribution.RouteDescriptor,
	req *pb.StartSplitMigrationRequest,
) (distribution.SplitJob, error) {
	jobID, err := s.catalog.NextSplitJobIDAt(ctx, snapshot.ReadTS)
	if err != nil {
		return distribution.SplitJob{}, splitJobCatalogStatusError(err)
	}
	job, err := distribution.InitializeSplitJobPlan(distribution.SplitJob{
		JobID:         jobID,
		SourceRouteID: parent.RouteID,
		SplitKey:      normalizeSplitMigrationSplitKey(req),
		TargetGroupID: req.GetTargetGroupId(),
	}, parent, time.Now().UnixMilli())
	if err != nil {
		return distribution.SplitJob{}, splitJobCatalogStatusError(err)
	}
	return job, nil
}

func normalizeSplitMigrationSplitKey(req *pb.StartSplitMigrationRequest) []byte {
	return distribution.CloneBytes(fskeys.NormalizeSplitBoundary(kv.RouteKey(req.GetSplitKey())))
}

func (s *DistributionServer) GetSplitJob(ctx context.Context, req *pb.GetSplitJobRequest) (*pb.GetSplitJobResponse, error) {
	if err := s.requireReadReady(); err != nil {
		return nil, err
	}
	if req.GetJobId() == 0 {
		return nil, grpcStatusError(codes.InvalidArgument, distribution.ErrCatalogSplitJobIDRequired.Error())
	}
	if s.catalog == nil {
		return nil, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	job, found, err := s.catalog.SplitJob(ctx, req.GetJobId())
	if err != nil {
		return nil, splitJobCatalogStatusError(err)
	}
	if !found {
		return nil, grpcStatusError(codes.NotFound, distribution.ErrCatalogSplitJobNotFound.Error())
	}
	return &pb.GetSplitJobResponse{Job: distribution.SplitJobToProto(job)}, nil
}

func (s *DistributionServer) ListSplitJobs(ctx context.Context, req *pb.ListSplitJobsRequest) (*pb.ListSplitJobsResponse, error) {
	if err := s.requireReadReady(); err != nil {
		return nil, err
	}
	if s.catalog == nil {
		return nil, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	if req == nil {
		req = &pb.ListSplitJobsRequest{}
	}
	phaseFilter := normalizeSplitJobPhaseFilter(req.GetPhase())
	if phaseFilter != "" && !validSplitJobPhaseFilter(phaseFilter) {
		return nil, grpcStatusErrorf(codes.InvalidArgument, "unknown split job phase %q", req.GetPhase())
	}
	jobs, err := s.catalog.ListSplitJobs(ctx)
	if err != nil {
		return nil, splitJobCatalogStatusError(err)
	}
	resp, err := splitJobListPage(jobs, req, phaseFilter)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (s *DistributionServer) AbandonSplitJob(ctx context.Context, req *pb.AbandonSplitJobRequest) (*pb.AbandonSplitJobResponse, error) {
	if req.GetJobId() == 0 {
		return nil, grpcStatusError(codes.InvalidArgument, distribution.ErrCatalogSplitJobIDRequired.Error())
	}
	if err := s.verifyCatalogLeader(ctx); err != nil {
		return nil, err
	}
	if s.catalog == nil {
		return nil, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	if err := s.updateSplitJobViaCoordinator(ctx, req.GetJobId(), func(job distribution.SplitJob) (distribution.SplitJob, error) {
		return distribution.BeginSplitJobAbandon(job, time.Now().UnixMilli())
	}); err != nil {
		return nil, err
	}
	return &pb.AbandonSplitJobResponse{}, nil
}

func (s *DistributionServer) RetrySplitJob(ctx context.Context, req *pb.RetrySplitJobRequest) (*pb.RetrySplitJobResponse, error) {
	if req.GetJobId() == 0 {
		return nil, grpcStatusError(codes.InvalidArgument, distribution.ErrCatalogSplitJobIDRequired.Error())
	}
	if err := s.verifyCatalogLeader(ctx); err != nil {
		return nil, err
	}
	if s.catalog == nil {
		return nil, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	if err := s.updateSplitJobViaCoordinator(ctx, req.GetJobId(), func(job distribution.SplitJob) (distribution.SplitJob, error) {
		return distribution.RetrySplitJobState(job, time.Now().UnixMilli())
	}); err != nil {
		return nil, err
	}
	return &pb.RetrySplitJobResponse{}, nil
}

func (s *DistributionServer) routeSnapshotAt(version uint64) (distribution.RouteHistorySnapshot, error) {
	if s.engine == nil {
		return distribution.RouteHistorySnapshot{}, grpcStatusError(codes.FailedPrecondition, errDistributionEngineNotConfigured.Error())
	}
	snapshot, ok := s.engine.SnapshotAt(version)
	if !ok {
		return distribution.RouteHistorySnapshot{}, grpcStatusErrorf(codes.NotFound, "%s: %d", errDistributionCatalogVersionNotFound, version)
	}
	return snapshot, nil
}

// GetCatalogCapabilities negotiates the durable delta-watch protocol.
func (s *DistributionServer) GetCatalogCapabilities(ctx context.Context, _ *pb.CatalogCapabilitiesRequest) (*pb.CatalogCapabilitiesResponse, error) {
	if s.catalog == nil {
		return nil, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	version, err := s.catalog.Version(ctx)
	if err != nil {
		return nil, grpcStatusErrorf(codes.Internal, "load catalog version: %v", err)
	}
	floor, err := s.catalog.DeltaFloor(ctx)
	if err != nil {
		return nil, grpcStatusErrorf(codes.Internal, "load catalog delta floor: %v", err)
	}
	return &pb.CatalogCapabilitiesResponse{
		SupportedProtocolVersions: []uint32{distribution.CatalogWatchProtocolVersion},
		CurrentVersion:            version,
		OldestDeltaVersion:        floor,
		MaxBatchSize:              distribution.MaxCatalogDeltaBatchSize,
	}, nil
}

// WatchCatalog streams contiguous deltas and emits a snapshot reset when the
// requested reconnect cursor predates retained history.
func (s *DistributionServer) WatchCatalog(req *pb.CatalogWatchRequest, stream pb.Distribution_WatchCatalogServer) error {
	config, err := s.catalogWatchConfig(req)
	if err != nil {
		return err
	}
	for {
		if s.watchLeader != nil && !s.watchLeader() {
			return grpcStatusError(codes.Unavailable, "catalog watch requires the catalog-group leader")
		}
		nextCursor, sent, err := s.sendCatalogChanges(stream, config.cursor, config.batchSize)
		if err != nil {
			return err
		}
		config.cursor = nextCursor
		if sent {
			continue
		}
		stop, err := waitCatalogStream(stream.Context(), config.interval)
		if err != nil {
			return err
		}
		if stop {
			return nil
		}
	}
}

type catalogWatchConfig struct {
	cursor    uint64
	batchSize int
	interval  time.Duration
}

func (s *DistributionServer) catalogWatchConfig(req *pb.CatalogWatchRequest) (catalogWatchConfig, error) {
	if s.catalog == nil {
		return catalogWatchConfig{}, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	if req.GetProtocolVersion() != distribution.CatalogWatchProtocolVersion {
		return catalogWatchConfig{}, grpcStatusErrorf(codes.FailedPrecondition, "unsupported catalog watch protocol %d", req.GetProtocolVersion())
	}
	batchSize := int(req.GetMaxBatchSize())
	if batchSize <= 0 {
		batchSize = distribution.DefaultCatalogDeltaBatchSize
	}
	if batchSize > distribution.MaxCatalogDeltaBatchSize {
		batchSize = distribution.MaxCatalogDeltaBatchSize
	}
	interval := s.watchInterval
	if interval <= 0 {
		interval = defaultCatalogWatchInterval
	}
	return catalogWatchConfig{cursor: req.GetAfterVersion(), batchSize: batchSize, interval: interval}, nil
}

func (s *DistributionServer) sendCatalogChanges(
	stream pb.Distribution_WatchCatalogServer,
	cursor uint64,
	batchSize int,
) (uint64, bool, error) {
	changes, err := s.catalog.ChangesSince(stream.Context(), cursor, batchSize)
	if err != nil {
		if errors.Is(err, distribution.ErrCatalogDeltaVersionFuture) {
			return cursor, false, grpcStatusError(codes.InvalidArgument, err.Error())
		}
		return cursor, false, grpcStatusErrorf(codes.Internal, "read catalog changes: %v", err)
	}
	if changes.Reset != nil {
		return s.sendCatalogReset(stream, changes.Reset)
	}
	return sendCatalogDeltas(stream, cursor, changes.Deltas)
}

func (s *DistributionServer) sendCatalogReset(
	stream pb.Distribution_WatchCatalogServer,
	snapshot *distribution.CatalogSnapshot,
) (uint64, bool, error) {
	event := &pb.CatalogWatchEvent{Payload: &pb.CatalogWatchEvent_Snapshot{
		Snapshot: &pb.CatalogSnapshotReset{
			Version: snapshot.Version,
			Routes:  toProtoRouteDescriptors(snapshot.Routes),
		},
	}}
	if err := stream.Send(event); err != nil {
		return 0, false, errors.WithStack(err)
	}
	return snapshot.Version, true, nil
}

func sendCatalogDeltas(
	stream pb.Distribution_WatchCatalogServer,
	cursor uint64,
	deltas []distribution.CatalogDelta,
) (uint64, bool, error) {
	for _, delta := range deltas {
		event := &pb.CatalogWatchEvent{Payload: &pb.CatalogWatchEvent_Delta{
			Delta: toProtoCatalogDelta(delta),
		}}
		if err := stream.Send(event); err != nil {
			return cursor, false, errors.WithStack(err)
		}
		cursor = delta.Version
	}
	return cursor, len(deltas) > 0, nil
}

func waitCatalogStream(ctx context.Context, interval time.Duration) (bool, error) {
	err := waitWithContext(ctx, interval)
	if errors.Is(err, context.Canceled) || status.Code(errors.Cause(err)) == codes.Canceled {
		return true, nil
	}
	return false, err
}

func toProtoCatalogDelta(delta distribution.CatalogDelta) *pb.CatalogDeltaRecord {
	mutations := make([]*pb.CatalogDeltaMutation, 0, len(delta.Mutations))
	for _, mutation := range delta.Mutations {
		op := pb.CatalogDeltaMutationOp_CATALOG_DELTA_MUTATION_OP_DELETE
		var route *pb.RouteDescriptor
		if mutation.Op == distribution.CatalogMutationUpsert {
			op = pb.CatalogDeltaMutationOp_CATALOG_DELTA_MUTATION_OP_UPSERT
			route = toProtoRouteDescriptor(mutation.Route)
		}
		mutations = append(mutations, &pb.CatalogDeltaMutation{
			Op:      op,
			RouteId: mutation.RouteID,
			Route:   route,
		})
	}
	return &pb.CatalogDeltaRecord{
		PreviousVersion: delta.PreviousVersion,
		Version:         delta.Version,
		Mutations:       mutations,
	}
}

// SplitRange splits a route into two child routes in the same raft group.
func (s *DistributionServer) SplitRange(ctx context.Context, req *pb.SplitRangeRequest) (*pb.SplitRangeResponse, error) {
	// SplitRange performs a read-modify-write cycle across catalog and engine.
	// Serialize it per server instance to keep these updates consistent.
	s.mu.Lock()
	defer s.mu.Unlock()

	if err := s.verifyCatalogLeader(ctx); err != nil {
		return nil, err
	}

	readTimestamp, err := kv.BeginReadTimestampThrough(
		ctx,
		s.coordinator,
		s.catalog.LatestCommitTS(),
		"distribution split range: begin read timestamp",
	)
	if err != nil {
		return nil, grpcStatusErrorf(codes.Internal, "begin catalog split snapshot: %v", err)
	}
	snapshot, err := s.loadCatalogSnapshotAt(ctx, readTimestamp.Timestamp())
	if err != nil {
		return nil, err
	}
	defer releaseReadPin(s.pinReadTS(snapshot.ReadTS))
	if err := validateExpectedCatalogVersion(snapshot.Version, req.GetExpectedCatalogVersion()); err != nil {
		return nil, err
	}

	plan, err := s.planSplitRange(ctx, snapshot, req)
	if err != nil {
		return nil, err
	}
	partitionGroups, err := s.prepareSplitRangePartitions(ctx, snapshot, plan.parentID)
	if err != nil {
		return nil, err
	}

	saved, err := s.commitSplitRangePlan(ctx, readTimestamp, req.GetExpectedCatalogVersion(), plan, partitionGroups)
	if err != nil {
		return nil, err
	}
	savedLeft, savedRight, err := splitChildrenFromSnapshot(saved, plan.left.RouteID, plan.right.RouteID)
	if err != nil {
		return nil, err
	}

	return &pb.SplitRangeResponse{
		CatalogVersion: saved.Version,
		Left:           toProtoRouteDescriptor(savedLeft),
		Right:          toProtoRouteDescriptor(savedRight),
	}, nil
}

type splitRangePlan struct {
	parentID uint64
	readKeys [][]byte
	left     distribution.RouteDescriptor
	right    distribution.RouteDescriptor
}

func (s *DistributionServer) commitSplitRangePlan(ctx context.Context, read kv.ReadTimestamp, version uint64, plan splitRangePlan, groups []uint64) (distribution.CatalogSnapshot, error) {
	saved, err := s.saveSplitResultViaCoordinator(ctx, read, version, plan.parentID, plan.readKeys, plan.left, plan.right)
	if err != nil {
		return saved, err
	}
	if err := s.reconcileSplitRangePartitions(ctx, groups); err != nil {
		return saved, err
	}
	return saved, s.applyEngineSnapshot(saved)
}

func (s *DistributionServer) planSplitRange(ctx context.Context, snapshot distribution.CatalogSnapshot, req *pb.SplitRangeRequest) (splitRangePlan, error) {
	parent, found := findRouteByID(snapshot.Routes, req.GetRouteId())
	if !found {
		return splitRangePlan{}, grpcStatusError(codes.NotFound, errDistributionUnknownRoute.Error())
	}

	rawSplitKey := req.GetSplitKey()
	splitKey := distribution.CloneBytes(fskeys.NormalizeSplitBoundary(kv.RouteKey(rawSplitKey)))
	if err := validateSplitKey(parent, splitKey); err != nil {
		s.observeFilePinnedHotspotIfNeeded(rawSplitKey, splitKey, err)
		return splitRangePlan{}, err
	}
	readKeys, err := s.splitJobOverlapReadKeys(ctx, snapshot, parent)
	if err != nil {
		return splitRangePlan{}, err
	}
	leftID, rightID, err := s.allocateChildRouteIDs(ctx, snapshot.ReadTS, snapshot.Routes)
	if err != nil {
		return splitRangePlan{}, err
	}
	left, right := splitCatalogRoutes(parent, splitKey, leftID, rightID, 0)
	return splitRangePlan{parentID: parent.RouteID, readKeys: readKeys, left: left, right: right}, nil
}

func (s *DistributionServer) pinReadTS(ts uint64) *kv.ActiveTimestampToken {
	if s == nil || s.readTracker == nil {
		return &kv.ActiveTimestampToken{}
	}
	return s.readTracker.Pin(ts)
}

func (s *DistributionServer) observeFilePinnedHotspotIfNeeded(rawSplitKey []byte, splitKey []byte, err error) {
	if s == nil || s.fsObserver == nil || bytes.Equal(rawSplitKey, splitKey) || !isSplitBoundaryError(err) {
		return
	}
	if !fskeys.IsChunkRouteDomainKey(splitKey) {
		return
	}
	s.fsObserver.ObserveFilePinnedHotspot(DistributionFilePinnedHotspotSplitBoundary)
	if homeSlot, inode, ok := fskeys.ChunkRoutePartsFromKey(splitKey); ok {
		slog.Warn("filesystem file-pinned hotspot rejected split",
			"reason", DistributionFilePinnedHotspotSplitBoundary,
			"home_slot", homeSlot,
			"inode", inode,
		)
	}
}

func isSplitBoundaryError(err error) bool {
	return status.Code(errors.Cause(err)) == codes.InvalidArgument &&
		strings.Contains(err.Error(), errDistributionSplitKeyAtBoundary.Error())
}

func releaseReadPin(token *kv.ActiveTimestampToken) {
	if token == nil {
		return
	}
	token.Release()
}

func (s *DistributionServer) verifyCatalogLeader(ctx context.Context) error {
	if s.coordinator == nil {
		return grpcStatusError(codes.FailedPrecondition, errDistributionCoordinatorRequired.Error())
	}
	key := distribution.CatalogVersionKey()
	if !s.coordinator.IsLeaderForKey(key) {
		return grpcStatusError(codes.FailedPrecondition, errDistributionNotLeader.Error())
	}
	if err := s.coordinator.VerifyLeaderForKey(ctx, key); err != nil {
		return grpcStatusErrorf(codes.FailedPrecondition, "verify catalog leader: %v", err)
	}
	return nil
}

func (s *DistributionServer) saveSplitResultViaCoordinator(
	ctx context.Context,
	readTimestamp kv.ReadTimestamp,
	expectedVersion uint64,
	parentID uint64,
	readKeys [][]byte,
	left distribution.RouteDescriptor,
	right distribution.RouteDescriptor,
) (distribution.CatalogSnapshot, error) {
	return s.saveSplitPartitionViaCoordinator(ctx, readTimestamp, expectedVersion, parentID, readKeys, left, right, nil)
}

func (s *DistributionServer) saveSplitPartitionViaCoordinator(
	ctx context.Context,
	readTimestamp kv.ReadTimestamp,
	expectedVersion, parentID uint64,
	readKeys [][]byte,
	left, right distribution.RouteDescriptor,
	workingJob *distribution.SplitJob,
) (distribution.CatalogSnapshot, error) {
	nextVersion, nextRouteID, err := nextCatalogSplitIDs(expectedVersion, right.RouteID)
	if err != nil {
		return distribution.CatalogSnapshot{}, err
	}
	// snapshot.ReadTS is exactly readTimestamp.Timestamp(); the token itself has
	// to travel this far because the dispatch below needs its voucher.
	readTS := readTimestamp.Timestamp()
	commitTS, err := kv.NextTimestampAfterThrough(ctx, s.coordinator, readTS, "split range: allocate commitTS")
	if err != nil {
		return distribution.CatalogSnapshot{}, grpcStatusErrorf(codes.Internal, "allocate split commit timestamp: %v", err)
	}
	left.SplitAtHLC = commitTS
	right.SplitAtHLC = commitTS

	ops, err := buildCatalogSplitOps(parentID, left, right, nextVersion, nextRouteID, s.catalog.AllowsRouteDescriptorV2Writes())
	if err != nil {
		return distribution.CatalogSnapshot{}, grpcStatusErrorf(codes.Internal, "build split mutations: %v", err)
	}
	delta := distribution.CatalogDelta{
		PreviousVersion: expectedVersion,
		Version:         nextVersion,
		Mutations: []distribution.CatalogRouteMutation{
			{Op: distribution.CatalogMutationDelete, RouteID: parentID},
			{Op: distribution.CatalogMutationUpsert, RouteID: left.RouteID, Route: left},
			{Op: distribution.CatalogMutationUpsert, RouteID: right.RouteID, Route: right},
		},
	}
	deltaOps, err := s.catalogDeltaMutationOps(ctx, readTS, delta)
	if err != nil {
		return distribution.CatalogSnapshot{}, err
	}
	ops = append(ops, deltaOps...)
	partitionOps, partitionReads, err := s.catalogSplitPartitionOps(ctx, readTS, parentID, left, right, expectedVersion, workingJob)
	if err != nil {
		return distribution.CatalogSnapshot{}, err
	}
	ops = append(ops, partitionOps...)
	readKeys = append(readKeys, distribution.CatalogVersionKey(), distribution.CatalogRouteKey(parentID), distribution.CatalogNextRouteIDKey())
	readKeys = append(readKeys, partitionReads...)
	dispatchCtx := readTimestamp.WithDispatchVoucher(ctx)
	resp, err := kv.DispatchWithReadTimestamp(dispatchCtx, s.coordinator, &kv.OperationGroup[kv.OP]{
		Elems:    ops,
		IsTxn:    true,
		StartTS:  readTS,
		CommitTS: commitTS,
		ReadKeys: readKeys,
	})
	if err != nil {
		return distribution.CatalogSnapshot{}, splitPartitionCoordinatorStatusError(err)
	}
	if resp == nil || resp.CommitTS == 0 {
		return distribution.CatalogSnapshot{}, grpcStatusError(codes.Internal, "split commit timestamp missing")
	}
	return s.loadCatalogSnapshotAtVersion(ctx, resp.CommitTS, nextVersion)
}

func (s *DistributionServer) catalogDeltaMutationOps(ctx context.Context, readTS uint64, delta distribution.CatalogDelta) ([]*kv.Elem[kv.OP], error) {
	mutations, err := s.catalog.BuildDeltaMutationsAt(ctx, readTS, delta)
	if err != nil {
		return nil, grpcStatusErrorf(codes.Internal, "build catalog delta mutations: %v", err)
	}
	ops, err := catalogStoreMutationsToOps(mutations)
	if err != nil {
		return nil, grpcStatusErrorf(codes.Internal, "convert catalog delta mutations: %v", err)
	}
	return ops, nil
}

func nextCatalogSplitIDs(expectedVersion uint64, rightRouteID uint64) (uint64, uint64, error) {
	if expectedVersion == math.MaxUint64 {
		return 0, 0, grpcStatusError(codes.Internal, "catalog version overflow")
	}
	if rightRouteID == math.MaxUint64 {
		return 0, 0, grpcStatusError(codes.Internal, errDistributionRouteIDOverflow.Error())
	}
	return expectedVersion + 1, rightRouteID + 1, nil
}

func catalogStoreMutationsToOps(mutations []*store.KVPairMutation) ([]*kv.Elem[kv.OP], error) {
	ops, err := kv.StoreMutationsToElems(mutations)
	if err != nil {
		return nil, errors.WithStack(errors.Join(errDistributionCatalogMutationInvalid, err))
	}
	return ops, nil
}

func buildCatalogSplitOps(
	parentID uint64,
	left distribution.RouteDescriptor,
	right distribution.RouteDescriptor,
	nextVersion uint64,
	nextRouteID uint64,
	allowRouteDescriptorV2Writes bool,
) ([]*kv.Elem[kv.OP], error) {
	// SplitRange mutates the catalog surgically: delete one parent route, add two
	// children, bump the version, and advance the next-route-id counter.
	ops := make([]*kv.Elem[kv.OP], 0, splitMutationOpCount)
	ops = append(ops, &kv.Elem[kv.OP]{
		Op:  kv.Del,
		Key: distribution.CatalogRouteKey(parentID),
	})
	for _, route := range []distribution.RouteDescriptor{left, right} {
		encoded, patchOffset, err := distribution.EncodeRouteDescriptorForCatalogWriteWithSplitAtHLCOffset(route, allowRouteDescriptorV2Writes)
		if err != nil {
			return nil, errors.WithStack(err)
		}
		ops = append(ops, &kv.Elem[kv.OP]{
			Op:                  kv.Put,
			Key:                 distribution.CatalogRouteKey(route.RouteID),
			Value:               encoded,
			CommitTSValueOffset: patchOffset,
		})
	}
	ops = append(ops, &kv.Elem[kv.OP]{
		Op:    kv.Put,
		Key:   distribution.CatalogVersionKey(),
		Value: distribution.EncodeCatalogVersion(nextVersion),
	})
	ops = append(ops, &kv.Elem[kv.OP]{
		Op:    kv.Put,
		Key:   distribution.CatalogNextRouteIDKey(),
		Value: distribution.EncodeCatalogNextRouteID(nextRouteID),
	})
	return ops, nil
}

func splitChildrenFromSnapshot(snapshot distribution.CatalogSnapshot, leftID uint64, rightID uint64) (distribution.RouteDescriptor, distribution.RouteDescriptor, error) {
	left, found := findRouteByID(snapshot.Routes, leftID)
	if !found {
		return distribution.RouteDescriptor{}, distribution.RouteDescriptor{}, grpcStatusError(codes.Internal, "catalog split committed but left child is missing")
	}
	right, found := findRouteByID(snapshot.Routes, rightID)
	if !found {
		return distribution.RouteDescriptor{}, distribution.RouteDescriptor{}, grpcStatusError(codes.Internal, "catalog split committed but right child is missing")
	}
	return left, right, nil
}

func (s *DistributionServer) loadCatalogSnapshot(ctx context.Context) (distribution.CatalogSnapshot, error) {
	if s.catalog == nil {
		return distribution.CatalogSnapshot{}, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	snapshot, err := s.catalog.Snapshot(ctx)
	if err != nil {
		return distribution.CatalogSnapshot{}, grpcStatusErrorf(codes.Internal, "load route catalog: %v", err)
	}
	return snapshot, nil
}

func (s *DistributionServer) loadCatalogSnapshotAtLeastVersion(
	ctx context.Context,
	minVersion uint64,
) (distribution.CatalogSnapshot, error) {
	if s.catalog == nil {
		return distribution.CatalogSnapshot{}, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	attempts := s.reloadRetry.attempts
	if attempts <= 0 {
		attempts = defaultCatalogReloadRetryAttempts
	}
	interval := s.reloadRetry.interval
	if interval <= 0 {
		interval = defaultCatalogReloadRetryInterval
	}

	var last distribution.CatalogSnapshot
	for attempt := 0; attempt < attempts; attempt++ {
		snapshot, err := s.catalog.Snapshot(ctx)
		if err != nil {
			return distribution.CatalogSnapshot{}, grpcStatusErrorf(codes.Internal, "reload route catalog: %v", err)
		}
		if snapshot.Version >= minVersion {
			return snapshot, nil
		}
		last = snapshot
		if attempt == attempts-1 {
			break
		}
		if err := waitWithContext(ctx, interval); err != nil {
			return distribution.CatalogSnapshot{}, err
		}
	}
	return distribution.CatalogSnapshot{}, grpcStatusErrorf(
		codes.Internal,
		"catalog split committed but local snapshot is stale: got %d, want at least %d",
		last.Version,
		minVersion,
	)
}

func (s *DistributionServer) loadCatalogSnapshotAt(ctx context.Context, readTS uint64) (distribution.CatalogSnapshot, error) {
	if s.catalog == nil {
		return distribution.CatalogSnapshot{}, grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	snapshot, err := s.catalog.SnapshotAt(ctx, readTS)
	if err != nil {
		return distribution.CatalogSnapshot{}, grpcStatusErrorf(codes.Internal, "load route catalog: %v", err)
	}
	return snapshot, nil
}

func (s *DistributionServer) loadCatalogSnapshotAtVersion(
	ctx context.Context,
	readTS uint64,
	wantVersion uint64,
) (distribution.CatalogSnapshot, error) {
	attempts := s.reloadRetry.attempts
	if attempts <= 0 {
		attempts = defaultCatalogReloadRetryAttempts
	}
	interval := s.reloadRetry.interval
	if interval <= 0 {
		interval = defaultCatalogReloadRetryInterval
	}

	var last distribution.CatalogSnapshot
	for attempt := 0; attempt < attempts; attempt++ {
		snapshot, err := s.catalog.SnapshotAt(ctx, readTS)
		if err != nil {
			return distribution.CatalogSnapshot{}, grpcStatusErrorf(codes.Internal, "reload route catalog: %v", err)
		}
		if snapshot.Version == wantVersion {
			return snapshot, nil
		}
		last = snapshot
		if attempt == attempts-1 {
			break
		}
		if err := waitWithContext(ctx, interval); err != nil {
			return distribution.CatalogSnapshot{}, err
		}
	}
	return distribution.CatalogSnapshot{}, grpcStatusErrorf(
		codes.Internal,
		"catalog split committed but local snapshot is stale at %d: got %d, want %d",
		readTS,
		last.Version,
		wantVersion,
	)
}

func waitWithContext(ctx context.Context, delay time.Duration) error {
	if ctx == nil {
		ctx = context.Background()
	}
	timer := time.NewTimer(delay)
	defer timer.Stop()
	select {
	case <-ctx.Done():
		return errors.WithStack(status.FromContextError(ctx.Err()).Err())
	case <-timer.C:
		return nil
	}
}

func (s *DistributionServer) applyEngineSnapshot(snapshot distribution.CatalogSnapshot) error {
	if s.engine == nil {
		return grpcStatusError(codes.FailedPrecondition, errDistributionEngineNotConfigured.Error())
	}
	if err := s.engine.ApplySnapshot(snapshot); err != nil {
		if errors.Is(err, distribution.ErrEngineSnapshotVersionStale) {
			return nil
		}
		return grpcStatusErrorf(codes.Internal, "apply engine snapshot: %v", err)
	}
	return nil
}

func (s *DistributionServer) updateSplitJobViaCoordinator(
	ctx context.Context,
	jobID uint64,
	transition func(distribution.SplitJob) (distribution.SplitJob, error),
) error {
	expected, readTS, err := s.catalog.LiveSplitJobForUpdate(ctx, jobID)
	if err != nil {
		return splitJobCatalogStatusError(err)
	}
	next, err := transition(expected)
	if err != nil {
		return splitJobCatalogStatusError(err)
	}
	if distribution.SplitJobsEquivalent(expected, next) {
		return nil
	}
	encoded, err := distribution.EncodeSplitJob(next)
	if err != nil {
		return splitJobCatalogStatusError(err)
	}
	key := distribution.CatalogSplitJobKey(jobID)
	if _, err := s.coordinator.Dispatch(ctx, &kv.OperationGroup[kv.OP]{
		Elems: []*kv.Elem[kv.OP]{{
			Op:    kv.Put,
			Key:   key,
			Value: encoded,
		}},
		IsTxn:    true,
		StartTS:  readTS,
		ReadKeys: [][]byte{key},
	}); err != nil {
		return splitJobCoordinatorStatusError(err)
	}
	return nil
}

func (s *DistributionServer) completeSplitJobTargetPromotionViaCoordinator(
	ctx context.Context,
	expectedVersion uint64,
	expected distribution.SplitJob,
	nowMs int64,
) (distribution.CatalogSnapshot, distribution.SplitJob, error) {
	if err := s.requirePromotionCompletionDeps(); err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, err
	}
	snapshot, current, alreadyDone, err := s.loadPromotionCompletionCandidate(ctx, expectedVersion, expected, nowMs)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, err
	}
	if alreadyDone {
		return snapshot, current, nil
	}
	completion, err := distribution.CompleteTargetPromotionState(current, snapshot.Routes, nowMs)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, splitJobPromotionStatusError(err)
	}
	return s.dispatchPromotionCompletion(ctx, snapshot, expectedVersion, expected.JobID, completion)
}

func (s *DistributionServer) requirePromotionCompletionDeps() error {
	if s.catalog == nil {
		return grpcStatusError(codes.FailedPrecondition, errDistributionCatalogNotConfigured.Error())
	}
	if s.coordinator == nil {
		return grpcStatusError(codes.FailedPrecondition, errDistributionCoordinatorRequired.Error())
	}
	return nil
}

func (s *DistributionServer) loadPromotionCompletionCandidate(
	ctx context.Context,
	expectedVersion uint64,
	expected distribution.SplitJob,
	nowMs int64,
) (distribution.CatalogSnapshot, distribution.SplitJob, bool, error) {
	snapshot, err := s.loadCatalogSnapshot(ctx)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, false, err
	}
	current, found, err := s.catalog.SplitJobAt(ctx, expected.JobID, snapshot.ReadTS)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, false, splitJobPromotionStatusError(err)
	}
	if !found {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, false, splitJobPromotionStatusError(distribution.ErrCatalogSplitJobConflict)
	}
	if snapshot.Version == expectedVersion && distribution.SplitJobsEquivalent(current, expected) {
		return snapshot, current, false, nil
	}
	completion, err := completedPromotionRetry(snapshot.Routes, expected, current, nowMs)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, false, splitJobPromotionStatusError(err)
	}
	if completion.Job.TargetPromotionDone {
		return snapshot, current, !completion.Changed, nil
	}
	if snapshot.Version != expectedVersion {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, false, splitJobPromotionStatusError(distribution.ErrCatalogVersionMismatch)
	}
	return distribution.CatalogSnapshot{}, distribution.SplitJob{}, false, splitJobPromotionStatusError(distribution.ErrCatalogSplitJobConflict)
}

func completedPromotionRetry(
	routes []distribution.RouteDescriptor,
	expected distribution.SplitJob,
	current distribution.SplitJob,
	nowMs int64,
) (distribution.TargetPromotionCompletion, error) {
	matches, err := splitJobPromotionMatchesExpected(expected, current)
	if err != nil {
		return distribution.TargetPromotionCompletion{}, errors.WithStack(err)
	}
	if !matches {
		return distribution.TargetPromotionCompletion{}, nil
	}
	completion, err := distribution.CompleteTargetPromotionState(current, routes, nowMs)
	if err != nil {
		return distribution.TargetPromotionCompletion{}, errors.WithStack(err)
	}
	return completion, nil
}

func (s *DistributionServer) dispatchPromotionCompletion(
	ctx context.Context,
	snapshot distribution.CatalogSnapshot,
	expectedVersion uint64,
	jobID uint64,
	completion distribution.TargetPromotionCompletion,
) (distribution.CatalogSnapshot, distribution.SplitJob, error) {
	if !completion.Changed {
		return snapshot, completion.Job, nil
	}
	commitTS, err := s.nextPromotionCompleteCommitTS(ctx, snapshot.ReadTS)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, err
	}
	if completion.Job.PromotionCompletedTS == 0 {
		completion.Job.PromotionCompletedTS = commitTS
	}
	ops, err := s.buildPromotionCompleteOps(ctx, snapshot.ReadTS, expectedVersion, completion)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, splitJobPromotionStatusError(err)
	}
	jobKey := distribution.CatalogSplitJobKey(jobID)
	readKeys := [][]byte{distribution.CatalogVersionKey(), jobKey, distribution.CatalogDeltaKey(expectedVersion + 1), distribution.CatalogDeltaFloorKey()}
	for _, routeID := range completion.ClearedRouteIDs {
		readKeys = append(readKeys, distribution.CatalogRouteKey(routeID))
	}
	if _, err := s.coordinator.Dispatch(ctx, &kv.OperationGroup[kv.OP]{
		Elems:    ops,
		IsTxn:    true,
		StartTS:  snapshot.ReadTS,
		CommitTS: commitTS,
		ReadKeys: readKeys,
	}); err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, splitJobCoordinatorStatusError(err)
	}
	loaded, err := s.loadCatalogSnapshotAtLeastVersion(ctx, expectedVersion+1)
	if err != nil {
		return distribution.CatalogSnapshot{}, distribution.SplitJob{}, err
	}
	return loaded, completion.Job, nil
}

func (s *DistributionServer) nextPromotionCompleteCommitTS(ctx context.Context, readTS uint64) (uint64, error) {
	if readTS == math.MaxUint64 {
		return 0, grpcStatusError(codes.Internal, distribution.ErrCatalogVersionOverflow.Error())
	}
	commitTS, err := kv.NextTimestampAfterThrough(ctx, s.coordinator, readTS, "allocate promotion completion timestamp")
	if err != nil {
		return 0, grpcStatusErrorf(codes.FailedPrecondition, "allocate promotion completion timestamp: %v", err)
	}
	if commitTS <= readTS {
		return 0, grpcStatusError(codes.Internal, "promotion completion timestamp did not advance")
	}
	return commitTS, nil
}

func (s *DistributionServer) buildPromotionCompleteOps(
	ctx context.Context,
	readTS uint64,
	expectedVersion uint64,
	completion distribution.TargetPromotionCompletion,
) ([]*kv.Elem[kv.OP], error) {
	if expectedVersion == math.MaxUint64 {
		return nil, errors.WithStack(distribution.ErrCatalogVersionOverflow)
	}
	ops := make([]*kv.Elem[kv.OP], 0, len(completion.ClearedRouteIDs)+promotionCompleteBaseOpCount)
	mutations := make([]distribution.CatalogRouteMutation, 0, len(completion.ClearedRouteIDs))
	for _, routeID := range completion.ClearedRouteIDs {
		route, ok := promotionCompleteRouteByID(completion.Routes, routeID)
		if !ok {
			return nil, errors.WithStack(distribution.ErrMigrationPromotionTargetAbsent)
		}
		encoded, err := distribution.EncodeRouteDescriptorForCatalogWrite(route, s.catalog.AllowsRouteDescriptorV2Writes())
		if err != nil {
			return nil, errors.WithStack(err)
		}
		ops = append(ops, &kv.Elem[kv.OP]{
			Op:    kv.Put,
			Key:   distribution.CatalogRouteKey(route.RouteID),
			Value: encoded,
		})
		mutations = append(mutations, distribution.CatalogRouteMutation{Op: distribution.CatalogMutationUpsert, RouteID: routeID, Route: route})
	}
	deltaOps, err := s.catalogDeltaMutationOps(ctx, readTS, distribution.CatalogDelta{
		PreviousVersion: expectedVersion,
		Version:         expectedVersion + 1,
		Mutations:       mutations,
	})
	if err != nil {
		return nil, err
	}
	ops = append(ops, deltaOps...)
	ops = append(ops, &kv.Elem[kv.OP]{
		Op:    kv.Put,
		Key:   distribution.CatalogVersionKey(),
		Value: distribution.EncodeCatalogVersion(expectedVersion + 1),
	})
	encodedJob, err := distribution.EncodeSplitJob(completion.Job)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	ops = append(ops, &kv.Elem[kv.OP]{
		Op:    kv.Put,
		Key:   distribution.CatalogSplitJobKey(completion.Job.JobID),
		Value: encodedJob,
	})
	return ops, nil
}

func promotionCompleteRouteByID(routes []distribution.RouteDescriptor, routeID uint64) (distribution.RouteDescriptor, bool) {
	for _, route := range routes {
		if route.RouteID == routeID {
			return route, true
		}
	}
	return distribution.RouteDescriptor{}, false
}

func splitJobPromotionMatchesExpected(expected, current distribution.SplitJob) (bool, error) {
	if expected.TargetPromotionDone ||
		!current.TargetPromotionDone ||
		current.PromotionCompletedTS == 0 ||
		(current.Phase != expected.Phase && current.Phase != distribution.SplitJobPhaseDone) {
		return false, nil
	}
	normalized := distribution.CloneSplitJob(current)
	normalized.Phase = expected.Phase
	normalized.TargetPromotionDone = expected.TargetPromotionDone
	normalized.PromotionCompletedTS = expected.PromotionCompletedTS
	normalized.TerminalAtMs = expected.TerminalAtMs
	normalized.UpdatedAtMs = expected.UpdatedAtMs
	expectedRaw, err := distribution.EncodeSplitJob(expected)
	if err != nil {
		return false, errors.WithStack(err)
	}
	normalizedRaw, err := distribution.EncodeSplitJob(normalized)
	if err != nil {
		return false, errors.WithStack(err)
	}
	return bytes.Equal(expectedRaw, normalizedRaw), nil
}

func (s *DistributionServer) verifyKnownTargetGroup(groupID uint64) error {
	if len(s.knownRaftGroups) == 0 {
		return grpcStatusError(codes.FailedPrecondition, errDistributionRaftGroupsNotKnown.Error())
	}
	if _, ok := s.knownRaftGroups[groupID]; !ok {
		return grpcStatusError(codes.InvalidArgument, errDistributionUnknownTargetGroup.Error())
	}
	return nil
}

func (s *DistributionServer) createSplitJobViaCoordinator(ctx context.Context, readTS uint64, job distribution.SplitJob) error {
	if job.JobID == math.MaxUint64 {
		return splitJobCatalogStatusError(distribution.ErrCatalogSplitJobIDOverflow)
	}
	encoded, err := distribution.EncodeSplitJob(job)
	if err != nil {
		return splitJobCatalogStatusError(err)
	}
	jobKey := distribution.CatalogSplitJobKey(job.JobID)
	nextIDKey := distribution.CatalogNextSplitJobIDKey()
	if _, err := s.coordinator.Dispatch(ctx, &kv.OperationGroup[kv.OP]{
		Elems: []*kv.Elem[kv.OP]{
			{
				Op:    kv.Put,
				Key:   jobKey,
				Value: encoded,
			},
			{
				Op:    kv.Put,
				Key:   nextIDKey,
				Value: distribution.EncodeCatalogNextSplitJobID(job.JobID + 1),
			},
		},
		IsTxn:   true,
		StartTS: readTS,
		ReadKeys: [][]byte{
			jobKey,
			nextIDKey,
			distribution.CatalogVersionKey(),
			distribution.CatalogRouteKey(job.SourceRouteID),
		},
	}); err != nil {
		return splitJobCoordinatorStatusError(err)
	}
	return nil
}

func (s *DistributionServer) verifySplitMigrationCapability(ctx context.Context) error {
	if s.migrationCapabilityGate == nil {
		return grpcStatusError(codes.FailedPrecondition, errDistributionClusterNotReady.Error())
	}
	if err := s.migrationCapabilityGate(ctx); err != nil {
		return err
	}
	return nil
}

func validateExpectedCatalogVersion(currentVersion, expectedVersion uint64) error {
	if currentVersion != expectedVersion {
		return grpcStatusError(codes.Aborted, errDistributionCatalogConflict.Error())
	}
	return nil
}

func validateSplitKey(parent distribution.RouteDescriptor, splitKey []byte) error {
	startCmp := bytes.Compare(splitKey, parent.Start)
	if startCmp == 0 {
		return grpcStatusError(codes.InvalidArgument, errDistributionSplitKeyAtBoundary.Error())
	}
	if startCmp < 0 {
		return grpcStatusError(codes.InvalidArgument, errDistributionInvalidSplitKey.Error())
	}
	if parent.End == nil {
		return nil
	}

	endCmp := bytes.Compare(splitKey, parent.End)
	if endCmp == 0 {
		return grpcStatusError(codes.InvalidArgument, errDistributionSplitKeyAtBoundary.Error())
	}
	if endCmp > 0 {
		return grpcStatusError(codes.InvalidArgument, errDistributionInvalidSplitKey.Error())
	}
	return nil
}

func (s *DistributionServer) splitJobOverlapReadKeys(ctx context.Context, snapshot distribution.CatalogSnapshot, parent distribution.RouteDescriptor) ([][]byte, error) {
	jobs, err := s.catalog.ListSplitJobsAt(ctx, snapshot.ReadTS)
	if err != nil {
		return nil, grpcStatusErrorf(codes.Internal, "load split jobs: %v", err)
	}
	readKeys := splitJobReadFenceKeys(jobs)
	for _, job := range jobs {
		if !splitJobIsLive(job) {
			continue
		}
		for _, interval := range liveSplitJobIntervals(job, snapshot.Routes) {
			if routeRangeIntersects(parent.Start, parent.End, interval.start, interval.end) {
				return nil, grpcStatusError(codes.Aborted, distribution.ErrSplitJobOverlap.Error())
			}
		}
	}
	return readKeys, nil
}

func splitJobReadFenceKeys(jobs []distribution.SplitJob) [][]byte {
	readKeys := make([][]byte, 0, len(jobs)+1)
	readKeys = append(readKeys, distribution.CatalogNextSplitJobIDKey())
	for _, job := range jobs {
		if splitJobIsLive(job) {
			readKeys = append(readKeys, distribution.CatalogSplitJobKey(job.JobID))
		}
	}
	return readKeys
}

func (s *DistributionServer) rejectLiveSplitJob(ctx context.Context, snapshot distribution.CatalogSnapshot, parent distribution.RouteDescriptor) error {
	jobs, err := s.catalog.ListSplitJobsAt(ctx, snapshot.ReadTS)
	if err != nil {
		return grpcStatusErrorf(codes.Internal, "load split jobs: %v", err)
	}
	liveJobs := 0
	for _, job := range jobs {
		if !splitJobIsLive(job) {
			continue
		}
		liveJobs++
		for _, interval := range liveSplitJobIntervals(job, snapshot.Routes) {
			if routeRangeIntersects(parent.Start, parent.End, interval.start, interval.end) {
				return grpcStatusError(codes.Aborted, distribution.ErrSplitJobOverlap.Error())
			}
		}
	}
	if liveJobs > 0 {
		return grpcStatusError(codes.ResourceExhausted, distribution.ErrTooManyInFlightSplitJobs.Error())
	}
	return nil
}

func splitJobIsLive(job distribution.SplitJob) bool {
	return job.Phase != distribution.SplitJobPhaseDone && job.Phase != distribution.SplitJobPhaseAbandoned
}

type routeInterval struct {
	start []byte
	end   []byte
}

const initialLiveSplitJobIntervalCapacity = 2

func liveSplitJobIntervals(job distribution.SplitJob, routes []distribution.RouteDescriptor) []routeInterval {
	out := make([]routeInterval, 0, initialLiveSplitJobIntervalCapacity)
	for _, route := range routes {
		switch {
		case route.RouteID == job.SourceRouteID:
			out = append(out, routeInterval{
				start: distribution.CloneBytes(job.SplitKey),
				end:   distribution.CloneBytes(route.End),
			})
		case route.ParentRouteID == job.SourceRouteID && routeRangeIntersects(route.Start, route.End, job.SplitKey, nil):
			out = append(out, routeInterval{
				start: distribution.CloneBytes(route.Start),
				end:   distribution.CloneBytes(route.End),
			})
		case job.JobID != 0 && route.MigrationJobID == job.JobID:
			out = append(out, routeInterval{
				start: distribution.CloneBytes(route.Start),
				end:   distribution.CloneBytes(route.End),
			})
		}
	}
	return out
}

func routeRangeIntersects(aStart, aEnd, bStart, bEnd []byte) bool {
	if aEnd != nil && bytes.Compare(aEnd, bStart) <= 0 {
		return false
	}
	if bEnd != nil && bytes.Compare(bEnd, aStart) <= 0 {
		return false
	}
	return true
}

func splitJobPassesListFilter(job distribution.SplitJob, sinceTerminalAtMs uint64, phaseFilter string) bool {
	if sinceTerminalAtMs > 0 && job.TerminalAtMs > 0 && uint64(job.TerminalAtMs) < sinceTerminalAtMs {
		return false
	}
	if phaseFilter == "" {
		return true
	}
	return normalizeSplitJobPhaseFilter(pb.SplitJobPhase(job.Phase).String()) == phaseFilter ||
		normalizeSplitJobPhaseFilter(strings.TrimPrefix(pb.SplitJobPhase(job.Phase).String(), "SPLIT_JOB_PHASE_")) == phaseFilter
}

func normalizeSplitJobPhaseFilter(phase string) string {
	phase = strings.TrimSpace(phase)
	if phase == "" {
		return ""
	}
	phase = strings.ReplaceAll(phase, "-", "_")
	phase = strings.ReplaceAll(phase, " ", "_")
	return strings.ToUpper(phase)
}

func validSplitJobPhaseFilter(phase string) bool {
	for _, candidate := range pb.SplitJobPhase_name {
		full := normalizeSplitJobPhaseFilter(candidate)
		short := normalizeSplitJobPhaseFilter(strings.TrimPrefix(candidate, "SPLIT_JOB_PHASE_"))
		if phase == full || phase == short {
			return true
		}
	}
	return false
}

func splitJobCatalogStatusError(err error) error {
	switch {
	case errors.Is(err, distribution.ErrCatalogSplitJobIDRequired):
		return grpcStatusError(codes.InvalidArgument, distribution.ErrCatalogSplitJobIDRequired.Error())
	case errors.Is(err, distribution.ErrCatalogSplitJobNotFound):
		return grpcStatusError(codes.NotFound, distribution.ErrCatalogSplitJobNotFound.Error())
	case errors.Is(err, distribution.ErrCatalogSplitJobCannotRetry),
		errors.Is(err, distribution.ErrCatalogSplitJobCannotAbandon):
		return grpcStatusError(codes.FailedPrecondition, err.Error())
	case errors.Is(err, distribution.ErrCatalogSplitJobConflict):
		return grpcStatusError(codes.Aborted, distribution.ErrCatalogSplitJobConflict.Error())
	default:
		return grpcStatusErrorf(codes.Internal, "split job catalog: %v", err)
	}
}

func splitMigrationRangeStatusError(err error) error {
	switch {
	case errors.Is(err, distribution.ErrMigrationResolverOwnedRange):
		return grpcStatusError(codes.FailedPrecondition, err.Error())
	case errors.Is(err, distribution.ErrMigrationReservedRange),
		errors.Is(err, distribution.ErrMigrationInvalidRoute):
		return grpcStatusError(codes.InvalidArgument, err.Error())
	default:
		return grpcStatusErrorf(codes.Internal, "validate split migration range: %v", err)
	}
}

func splitPartitionCoordinatorStatusError(err error) error {
	switch {
	case errors.Is(err, kv.ErrTransactionOutcomeUnknown):
		return grpcStatusError(codes.Unknown, kv.ErrTransactionOutcomeUnknown.Error())
	case errors.Is(err, store.ErrWriteConflict):
		return grpcStatusError(codes.Aborted, errDistributionCatalogConflict.Error())
	default:
		return grpcStatusErrorf(codes.Internal, "commit split mutations: %v", err)
	}
}

func splitJobCoordinatorStatusError(err error) error {
	switch {
	case errors.Is(err, kv.ErrTransactionOutcomeUnknown):
		return grpcStatusError(codes.Unknown, kv.ErrTransactionOutcomeUnknown.Error())
	case errors.Is(err, store.ErrWriteConflict):
		return grpcStatusError(codes.Aborted, distribution.ErrCatalogSplitJobConflict.Error())
	case splitJobCoordinatorLeadershipError(err):
		return grpcStatusError(codes.FailedPrecondition, errDistributionNotLeader.Error())
	default:
		return grpcStatusErrorf(codes.Internal, "commit split job mutation: %v", err)
	}
}

func splitJobPromotionStatusError(err error) error {
	switch {
	case errors.Is(err, kv.ErrTransactionOutcomeUnknown):
		return grpcStatusError(codes.Unknown, kv.ErrTransactionOutcomeUnknown.Error())
	case errors.Is(err, distribution.ErrCatalogVersionMismatch),
		errors.Is(err, distribution.ErrCatalogSplitJobConflict),
		errors.Is(err, store.ErrWriteConflict):
		return grpcStatusError(codes.Aborted, err.Error())
	case errors.Is(err, distribution.ErrMigrationPromotionNotReady),
		errors.Is(err, distribution.ErrMigrationPromotionTargetAbsent):
		return grpcStatusError(codes.FailedPrecondition, err.Error())
	case errors.Is(err, distribution.ErrMigrationInvalidRoute),
		errors.Is(err, distribution.ErrCatalogRouteV2WriteDisabled):
		return grpcStatusError(codes.InvalidArgument, err.Error())
	default:
		return splitJobCatalogStatusError(err)
	}
}

func splitJobListPage(jobs []distribution.SplitJob, req *pb.ListSplitJobsRequest, phaseFilter string) (*pb.ListSplitJobsResponse, error) {
	filtered := make([]distribution.SplitJob, 0, len(jobs))
	for _, job := range jobs {
		if splitJobPassesListFilter(job, req.GetSinceTerminalAtMs(), phaseFilter) {
			filtered = append(filtered, job)
		}
	}
	sortSplitJobsForList(filtered)

	start, err := splitJobListStartIndex(filtered, req.GetPageCursor())
	if err != nil {
		return nil, err
	}
	end := start + listSplitJobsDefaultPageSize
	if end > len(filtered) {
		end = len(filtered)
	}

	resp := &pb.ListSplitJobsResponse{
		Jobs: make([]*pb.SplitJob, 0, end-start),
	}
	for _, job := range filtered[start:end] {
		resp.Jobs = append(resp.Jobs, distribution.SplitJobToProto(job))
	}
	if end < len(filtered) {
		resp.NextPageCursor = encodeSplitJobListCursor(filtered[end-1])
	}
	return resp, nil
}

func sortSplitJobsForList(jobs []distribution.SplitJob) {
	sort.Slice(jobs, func(i, j int) bool {
		left, right := jobs[i], jobs[j]
		leftLive := left.TerminalAtMs <= 0
		rightLive := right.TerminalAtMs <= 0
		if leftLive != rightLive {
			return leftLive
		}
		if leftLive {
			if left.UpdatedAtMs != right.UpdatedAtMs {
				return left.UpdatedAtMs > right.UpdatedAtMs
			}
			return left.JobID > right.JobID
		}
		if left.TerminalAtMs != right.TerminalAtMs {
			return left.TerminalAtMs > right.TerminalAtMs
		}
		return left.JobID > right.JobID
	})
}

func splitJobListStartIndex(jobs []distribution.SplitJob, cursor []byte) (int, error) {
	if len(cursor) == 0 {
		return 0, nil
	}
	terminalAtMs, jobID, err := decodeSplitJobListCursor(cursor)
	if err != nil {
		return 0, err
	}
	for i, job := range jobs {
		if job.JobID == jobID && splitJobListCursorTerminalAtMs(job) == terminalAtMs {
			return i + 1, nil
		}
		if terminalAtMs > 0 && splitJobHistoryAfterCursor(job, terminalAtMs, jobID) {
			return i, nil
		}
	}
	if terminalAtMs > 0 {
		return len(jobs), nil
	}
	return 0, grpcStatusError(codes.InvalidArgument, "live split job page cursor is no longer available")
}

func splitJobHistoryAfterCursor(job distribution.SplitJob, terminalAtMs, jobID uint64) bool {
	jobTerminalAtMs := splitJobListCursorTerminalAtMs(job)
	return jobTerminalAtMs > 0 && (jobTerminalAtMs < terminalAtMs || (jobTerminalAtMs == terminalAtMs && job.JobID < jobID))
}

func encodeSplitJobListCursor(job distribution.SplitJob) []byte {
	cursor := make([]byte, splitJobListCursorEncodedBytes)
	cursor[0] = splitJobListCursorVersion
	binary.BigEndian.PutUint64(
		cursor[splitJobListCursorTerminalOff:splitJobListCursorJobIDOff],
		splitJobListCursorTerminalAtMs(job),
	)
	binary.BigEndian.PutUint64(cursor[splitJobListCursorJobIDOff:], job.JobID)
	return cursor
}

func decodeSplitJobListCursor(cursor []byte) (uint64, uint64, error) {
	if len(cursor) != splitJobListCursorEncodedBytes || cursor[0] != splitJobListCursorVersion {
		return 0, 0, grpcStatusError(codes.InvalidArgument, "invalid split job page cursor")
	}
	terminalAtMs := binary.BigEndian.Uint64(cursor[splitJobListCursorTerminalOff:splitJobListCursorJobIDOff])
	jobID := binary.BigEndian.Uint64(cursor[splitJobListCursorJobIDOff:])
	if jobID == 0 {
		return 0, 0, grpcStatusError(codes.InvalidArgument, "invalid split job page cursor")
	}
	return terminalAtMs, jobID, nil
}

func splitJobListCursorTerminalAtMs(job distribution.SplitJob) uint64 {
	if job.TerminalAtMs <= 0 {
		return 0
	}
	return uint64(job.TerminalAtMs)
}

func splitJobCoordinatorLeadershipError(err error) bool {
	if err == nil {
		return false
	}
	if errors.Is(err, kv.ErrLeaderNotFound) ||
		errors.Is(err, raftengine.ErrNotLeader) ||
		errors.Is(err, raftengine.ErrLeadershipLost) ||
		errors.Is(err, raftengine.ErrLeadershipTransferInProgress) {
		return true
	}
	return hasSplitJobLeaderErrorSuffix(err.Error())
}

var splitJobLeaderErrorPhrases = []string{
	ErrNotLeader.Error(),
	"leader not found",
	"leadership lost",
	"leadership transfer in progress",
}

func hasSplitJobLeaderErrorSuffix(msg string) bool {
	for _, phrase := range splitJobLeaderErrorPhrases {
		if len(msg) >= len(phrase) && strings.EqualFold(msg[len(msg)-len(phrase):], phrase) {
			return true
		}
	}
	return false
}

func splitCatalogRoutes(
	parent distribution.RouteDescriptor,
	splitKey []byte,
	leftID uint64,
	rightID uint64,
	splitAtHLC uint64,
) (distribution.RouteDescriptor, distribution.RouteDescriptor) {
	// parent and splitKey are already cloned before this point and are immutable here.
	left := distribution.RouteDescriptor{
		RouteID:                leftID,
		Start:                  parent.Start,
		End:                    splitKey,
		GroupID:                parent.GroupID,
		State:                  parent.State,
		ParentRouteID:          parent.RouteID,
		StagedVisibilityActive: parent.StagedVisibilityActive,
		MigrationJobID:         parent.MigrationJobID,
		MinWriteTSExclusive:    parent.MinWriteTSExclusive,
		SplitAtHLC:             splitAtHLC,
	}
	right := distribution.RouteDescriptor{
		RouteID:                rightID,
		Start:                  splitKey,
		End:                    parent.End,
		GroupID:                parent.GroupID,
		State:                  parent.State,
		ParentRouteID:          parent.RouteID,
		StagedVisibilityActive: parent.StagedVisibilityActive,
		MigrationJobID:         parent.MigrationJobID,
		MinWriteTSExclusive:    parent.MinWriteTSExclusive,
		SplitAtHLC:             splitAtHLC,
	}
	return left, right
}

func (s *DistributionServer) allocateChildRouteIDs(ctx context.Context, readTS uint64, routes []distribution.RouteDescriptor) (uint64, uint64, error) {
	nextRouteID, err := s.catalog.NextRouteIDAt(ctx, readTS)
	if err != nil {
		return 0, 0, grpcStatusErrorf(codes.Internal, "load next route id: %v", err)
	}

	// Keep floor computation shared with catalog persistence logic.
	minNextRouteID, err := distribution.NextRouteIDFloor(routes)
	if err != nil {
		if errors.Is(err, distribution.ErrCatalogRouteIDOverflow) {
			return 0, 0, grpcStatusError(codes.Internal, errDistributionRouteIDOverflow.Error())
		}
		return 0, 0, grpcStatusErrorf(codes.Internal, "compute next route id floor: %v", err)
	}
	if nextRouteID < minNextRouteID {
		nextRouteID = minNextRouteID
	}

	if nextRouteID > math.MaxUint64-(childRouteCount-1) {
		return 0, 0, grpcStatusError(codes.Internal, errDistributionRouteIDOverflow.Error())
	}
	leftID := nextRouteID
	rightID := nextRouteID + 1
	return leftID, rightID, nil
}

func findRouteByID(routes []distribution.RouteDescriptor, routeID uint64) (distribution.RouteDescriptor, bool) {
	for _, route := range routes {
		if route.RouteID == routeID {
			return distribution.CloneRouteDescriptor(route), true
		}
	}
	return distribution.RouteDescriptor{}, false
}

func toProtoRouteDescriptors(routes []distribution.RouteDescriptor) []*pb.RouteDescriptor {
	out := make([]*pb.RouteDescriptor, 0, len(routes))
	for _, route := range routes {
		out = append(out, toProtoRouteDescriptor(route))
	}
	return out
}

func toProtoRouteDescriptor(route distribution.RouteDescriptor) *pb.RouteDescriptor {
	return &pb.RouteDescriptor{
		RouteId:                route.RouteID,
		Start:                  distribution.CloneBytes(route.Start),
		End:                    distribution.CloneBytes(route.End),
		RaftGroupId:            route.GroupID,
		State:                  toProtoRouteState(route.State),
		ParentRouteId:          route.ParentRouteID,
		StagedVisibilityActive: route.StagedVisibilityActive,
		MigrationJobId:         route.MigrationJobID,
		MinWriteTsExclusive:    route.MinWriteTSExclusive,
		SplitAtHlc:             route.SplitAtHLC,
	}
}

func toProtoRoute(route distribution.Route) *pb.RouteDescriptor {
	return &pb.RouteDescriptor{
		RouteId:                route.RouteID,
		Start:                  distribution.CloneBytes(route.Start),
		End:                    distribution.CloneBytes(route.End),
		RaftGroupId:            route.GroupID,
		State:                  toProtoRouteState(route.State),
		StagedVisibilityActive: route.StagedVisibilityActive,
		MigrationJobId:         route.MigrationJobID,
		MinWriteTsExclusive:    route.MinWriteTSExclusive,
	}
}

func toProtoRouteState(state distribution.RouteState) pb.RouteState {
	switch state {
	case distribution.RouteStateActive:
		return pb.RouteState_ROUTE_STATE_ACTIVE
	case distribution.RouteStateWriteFenced:
		return pb.RouteState_ROUTE_STATE_WRITE_FENCED
	case distribution.RouteStateMigratingSource:
		return pb.RouteState_ROUTE_STATE_MIGRATING_SOURCE
	case distribution.RouteStateMigratingTarget:
		return pb.RouteState_ROUTE_STATE_MIGRATING_TARGET
	default:
		return pb.RouteState_ROUTE_STATE_UNSPECIFIED
	}
}

func grpcStatusError(code codes.Code, msg string) error {
	return errors.WithStack(status.Error(code, msg))
}

func grpcStatusErrorf(code codes.Code, format string, args ...any) error {
	return errors.WithStack(status.Errorf(code, format, args...))
}
