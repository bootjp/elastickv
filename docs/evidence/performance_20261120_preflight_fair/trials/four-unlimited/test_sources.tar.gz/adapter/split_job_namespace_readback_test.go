package adapter

import (
	"context"
	"sync/atomic"
	"testing"

	"github.com/bootjp/elastickv/kv"
	pb "github.com/bootjp/elastickv/proto"
	"github.com/bootjp/elastickv/store"
	"github.com/stretchr/testify/require"
)

func TestActiveNamespaceUsesFreshAllMemberReadback(t *testing.T) {
	var namespaceProbes atomic.Int32
	members := SplitMigrationApplyMemberSnapshot{ConfigurationIndex: 41}
	for _, id := range []string{"voter", "learner"} {
		client := &transferAdmissionClient{probe: func(req *pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
			if req.GetKind() == pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_NAMESPACE_ADMISSION {
				namespaceProbes.Add(1)
			}
			return &pb.ProbeMigrationStateResponse{Ready: true, AppliedConfigurationIndex: 41, NamespaceAdmissionVersion: kv.MigrationNamespaceVersion, TransferSizeGuardVersion: store.MigrationTransferSizeGuardVersion, OwnershipPartitionProtocol: MigrationOwnershipPartitionProtocolVersion}, nil
		}}
		members.Members = append(members.Members, SplitMigrationVoter{ID: id, Address: id + ":1", Client: client})
	}
	server := &DistributionServer{splitApplyMemberFactory: func(context.Context, uint64) (SplitMigrationApplyMemberSnapshot, error) { return members, nil }, splitMigrationGroupFactory: func(context.Context, uint64) (SplitMigrationClient, error) { return members.Members[0].Client, nil }}
	require.NoError(t, server.ensureMigrationNamespaces(t.Context(), []uint64{1}))
	require.Equal(t, int32(2), namespaceProbes.Load(), "one current activation ACK per apply member must suffice without replaying negotiation")
	require.NoError(t, server.ensureMigrationNamespaces(t.Context(), []uint64{1}))
	require.Equal(t, int32(4), namespaceProbes.Load(), "ACKs are re-read, never cached across attempts")
}

func TestActiveNamespaceReadbackRejectsMissingLearnerProof(t *testing.T) {
	for _, mode := range []string{"pending", "unsupported", "configuration", "transport"} {
		t.Run(mode, func(t *testing.T) {
			members := SplitMigrationApplyMemberSnapshot{ConfigurationIndex: 41}
			for _, id := range []string{"voter", "learner"} {
				client := &transferAdmissionClient{probe: func(*pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
					response := &pb.ProbeMigrationStateResponse{Ready: true, AppliedConfigurationIndex: 41, NamespaceAdmissionVersion: kv.MigrationNamespaceVersion}
					if id == "learner" {
						switch mode {
						case "pending":
							response.Ready = false
						case "unsupported":
							response.NamespaceAdmissionVersion = 0
						case "configuration":
							response.AppliedConfigurationIndex++
						case "transport":
							return nil, context.DeadlineExceeded
						}
					}
					return response, nil
				}}
				members.Members = append(members.Members, SplitMigrationVoter{ID: id, Address: id + ":1", Client: client})
			}
			active, err := readActiveSplitNamespace(t.Context(), splitNamespaceGroup{members: members})
			require.False(t, active)
			if mode == "pending" {
				require.NoError(t, err, "only missing activation may take the normal activation path")
			} else {
				require.Error(t, err)
			}
		})
	}
}

func TestActiveNamespaceReadbackRechecksAuthoritativeConfiguration(t *testing.T) {
	var changed atomic.Bool
	members := SplitMigrationApplyMemberSnapshot{ConfigurationIndex: 41}
	for _, id := range []string{"voter", "learner"} {
		client := &transferAdmissionClient{probe: func(req *pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
			if req.GetKind() == pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_NAMESPACE_ADMISSION && id == "learner" {
				changed.Store(true)
			}
			return &pb.ProbeMigrationStateResponse{Ready: true, AppliedConfigurationIndex: 41, NamespaceAdmissionVersion: kv.MigrationNamespaceVersion, TransferSizeGuardVersion: store.MigrationTransferSizeGuardVersion, OwnershipPartitionProtocol: MigrationOwnershipPartitionProtocolVersion}, nil
		}}
		members.Members = append(members.Members, SplitMigrationVoter{ID: id, Address: id + ":1", Client: client})
	}
	server := &DistributionServer{splitApplyMemberFactory: func(context.Context, uint64) (SplitMigrationApplyMemberSnapshot, error) {
		result := members
		if changed.Load() {
			result.ConfigurationIndex++
		}
		return result, nil
	}, splitMigrationGroupFactory: func(context.Context, uint64) (SplitMigrationClient, error) { return members.Members[0].Client, nil }}
	require.Error(t, server.ensureMigrationNamespaces(t.Context(), []uint64{1}), "ACKs at the previous configuration cannot authorize progress")
}
