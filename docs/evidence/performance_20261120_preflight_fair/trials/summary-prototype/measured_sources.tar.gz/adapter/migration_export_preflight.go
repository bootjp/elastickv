package adapter

import (
	"bytes"

	pb "github.com/bootjp/elastickv/proto"
	"github.com/bootjp/elastickv/store"
	"github.com/cockroachdb/errors"
)

const migrationExportPreflightVersion = uint32(1)

// Validate the full page before omitting its values. Only lengths are read
// from borrowed values; ordinary export still owns cloned response values.
func migrationExportResponse(result store.ExportVersionsResult, preflight bool) (*pb.ExportRangeVersionsResponse, error) {
	response := &pb.ExportRangeVersionsResponse{NextCursor: result.NextCursor, Done: result.Done}
	if preflight {
		response.Versions = make([]*pb.MVCCVersion, 0, len(result.Versions))
		for _, version := range result.Versions {
			response.Versions = append(response.Versions, &pb.MVCCVersion{Key: bytes.Clone(version.Key), Value: version.Value})
		}
	} else {
		response.Versions = protoMVCCVersionsFromStore(result.Versions)
	}
	if err := checkMigrationExportPageSize(response); err != nil {
		return nil, err
	}
	if preflight {
		response.PreflightVersion = migrationExportPreflightVersion
		response.CheckedVersions = uint64(len(response.Versions))
		response.CheckedPayloadBytes = uint64(migrationExportPagePayloadBytes(response))
		response.Versions = nil
	}
	return response, nil
}

// Older sources return ordinary values. A summary must explicitly attest its
// format, and its original payload still consumes the controller's byte budget.
func preflightExportPageMetrics(response *pb.ExportRangeVersionsResponse) (uint64, int, error) {
	if response.GetPreflightVersion() == 0 {
		if response.GetCheckedVersions() != 0 || response.GetCheckedPayloadBytes() != 0 {
			return 0, 0, errors.New("migration preflight summary has no protocol version")
		}
		return uint64(len(response.GetVersions())), migrationExportPagePayloadBytes(response), nil
	}
	if response.GetPreflightVersion() != migrationExportPreflightVersion || len(response.GetVersions()) != 0 || response.GetCheckedPayloadBytes() > uint64(migrationExportPageByteBudget) {
		return 0, 0, errors.New("invalid or unsupported migration preflight summary")
	}
	return response.GetCheckedVersions(), int(response.GetCheckedPayloadBytes()), nil
}
