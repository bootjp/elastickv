package adapter

import (
	"bytes"
	"context"
	"os"
	"strings"
	"sync/atomic"
	"time"

	"github.com/bootjp/elastickv/distribution"
	"github.com/bootjp/elastickv/internal"
	"github.com/bootjp/elastickv/internal/fskeys"
	"github.com/bootjp/elastickv/internal/raftengine"
	"github.com/bootjp/elastickv/internal/s3keys"
	"github.com/bootjp/elastickv/kv"
	pb "github.com/bootjp/elastickv/proto"
	"github.com/bootjp/elastickv/store"
	"github.com/cockroachdb/errors"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

const (
	// MigrationImportOpcodeEnv enables the internal staged import opcode after
	// every voter is running a compatible build.
	MigrationImportOpcodeEnv = "ELASTICKV_ENABLE_MIGRATION_IMPORT_OPCODE"
	// MigrationPromoteOpcodeEnv enables the internal staged promotion opcode
	// after every voter is running a compatible build.
	MigrationPromoteOpcodeEnv = "ELASTICKV_ENABLE_MIGRATION_PROMOTE_OPCODE"
	// MigrationCleanupOpcodeEnv enables the internal migration cleanup opcode
	// after every voter is running a compatible build.
	MigrationCleanupOpcodeEnv = "ELASTICKV_ENABLE_MIGRATION_CLEANUP_OPCODE"
)

type InternalOption func(*Internal)

// WithKVForwardRejected refuses Forward before it can propose.
//
// The dedicated TSO group runs TSOStateMachine, whose Apply halts on any tag it
// does not recognise. TransactionManager.Commit encodes KV requests with the
// 0x00 / 0x01 tags, so a single forwarded PUT reaching this group's Internal
// server would commit an entry that permanently stops group-0 apply -- and with
// it all centralized timestamp issuance. The registration loop wires an Internal
// server for every runtime, so the refusal has to live here.
func WithKVForwardRejected() InternalOption {
	return func(i *Internal) {
		i.kvForwardRejected = true
	}
}

// WithInternalWriteGate re-applies the coordinator's route-floor check to
// writes that were forwarded here from a follower.
func WithInternalWriteGate(gate kv.MutationWriteGate) InternalOption {
	return func(i *Internal) {
		i.writeGate = gate
	}
}

func WithInternalTimestampAllocator(alloc kv.TimestampAllocator) InternalOption {
	return func(i *Internal) {
		i.tsAllocator = alloc
	}
}

func WithInternalStore(st store.MVCCStore) InternalOption {
	return func(i *Internal) {
		i.store = st
	}
}

func WithInternalPrimaryCommitEvidence(reader kv.PrimaryCommitEvidenceReader) InternalOption {
	return func(i *Internal) {
		i.primaryCommitEvidence = reader
	}
}

func WithInternalTSOCutoverState(state interface{ CutoverActive() bool }) InternalOption {
	return func(i *Internal) { i.tsoCutoverState = state }
}

func WithInternalMigrationProposer(proposer raftengine.Proposer) InternalOption {
	return func(i *Internal) {
		i.migrationProposer = proposer
	}
}

func WithInternalMigrationImportGate(gate func(context.Context) error) InternalOption {
	return func(i *Internal) {
		i.migrationImportGate = gate
	}
}

func WithInternalMigrationPromoteGate(gate func(context.Context) error) InternalOption {
	return func(i *Internal) {
		i.migrationPromoteGate = gate
	}
}

func WithInternalMigrationCleanupGate(gate func(context.Context) error) InternalOption {
	return func(i *Internal) {
		i.migrationCleanupGate = gate
	}
}

func WithInternalRouteEngine(engine *distribution.Engine) InternalOption {
	return func(i *Internal) {
		i.routeEngine = engine
	}
}

func WithInternalActiveTimestampTracker(tracker *kv.ActiveTimestampTracker) InternalOption {
	return func(i *Internal) {
		i.readTracker = tracker
	}
}

func WithInternalMigrationExportRouting(groupID uint64, resolver kv.PartitionResolver) InternalOption {
	return func(i *Internal) {
		i.migrationExportGroupID = groupID
		i.migrationExportResolver = resolver
	}
}

// WithInternalReadWatermarkProposer sets the proposer that applies forwarded
// read-watermark advances to this group. Without it a forwarded advance is
// refused. It is wired, whether or not the admin server runs, only when the
// advance is enabled (--readWatermarkAdvance).
func WithInternalReadWatermarkProposer(proposer raftengine.Proposer) InternalOption {
	return func(i *Internal) {
		i.readWatermarkProposer = proposer
	}
}

func WithInternalAdminProposer(proposer raftengine.Proposer) InternalOption {
	return func(i *Internal) {
		i.adminProposer = proposer
	}
}

func WithInternalLastCommitTimestamp(reader func() uint64) InternalOption {
	return func(i *Internal) {
		i.lastCommitTimestamp = reader
	}
}

// ForwardWriteObserver observes successfully committed leader-side forwarded
// writes. It lets the autosplit sampler account for writes that entered through
// followers without coupling adapter.Internal to keyviz.
type ForwardWriteObserver func([]*pb.Request)

func WithInternalForwardWriteObserver(observer ForwardWriteObserver) InternalOption {
	return func(i *Internal) {
		i.forwardWriteObserver = observer
	}
}

func NewInternalWithEngine(txm kv.Transactional, leader raftengine.LeaderView, clock *kv.HLC, relay *RedisPubSubRelay, opts ...InternalOption) *Internal {
	i := &Internal{
		leader:               leader,
		transactionManager:   txm,
		clock:                clock,
		relay:                relay,
		migrationImportGate:  defaultMigrationImportGate,
		migrationPromoteGate: defaultMigrationPromoteGate,
		migrationCleanupGate: defaultMigrationCleanupGate,
	}
	for _, opt := range opts {
		opt(i)
	}
	return i
}

type Internal struct {
	leader                          raftengine.LeaderView
	transactionManager              kv.Transactional
	clock                           *kv.HLC
	tsAllocator                     kv.TimestampAllocator
	timestampAdmissionIssuer        kv.TimestampAfterAllocator
	timestampAdmissionToken         string
	adminProposer                   raftengine.Proposer
	bootstrapPolicyProposer         raftengine.Proposer
	prepareStartupAuthorization     func(context.Context, *pb.PrepareEvidenceStateRequest) bool
	readWatermarkProposer           raftengine.Proposer
	lastCommitTimestamp             func() uint64
	relay                           *RedisPubSubRelay
	store                           store.MVCCStore
	primaryCommitEvidence           kv.PrimaryCommitEvidenceReader
	tsoCutoverState                 interface{ CutoverActive() bool }
	prepareEvidenceToken            string
	prepareEvidenceScanning         atomic.Bool
	migrationProposer               raftengine.Proposer
	migrationImportGate             func(context.Context) error
	migrationPromoteGate            func(context.Context) error
	migrationCleanupGate            func(context.Context) error
	migrationOwnershipReady         func() bool
	migrationPartitionProtocolReady func() bool
	migrationNamespaceReady         func() bool
	transferSizeReady               func() bool
	routeEngine                     *distribution.Engine
	readTracker                     *kv.ActiveTimestampTracker
	migrationExportGroupID          uint64
	migrationExportResolver         kv.PartitionResolver
	writeGate                       kv.MutationWriteGate
	// kvForwardRejected marks a runtime whose state machine cannot apply KV
	// entries -- the dedicated TSO group. See WithKVForwardRejected.
	kvForwardRejected    bool
	forwardWriteObserver ForwardWriteObserver

	pb.UnimplementedInternalServer
}

var _ pb.InternalServer = (*Internal)(nil)

type adapterLeaderSentinel string

func (e adapterLeaderSentinel) Error() string { return string(e) }

var ErrNotLeader = adapterLeaderSentinel("not leader")
var ErrKVForwardNotSupported = errors.New("kv forward not supported on this raft group")
var ErrLeaderNotFound = adapterLeaderSentinel("leader not found")
var ErrTxnTimestampOverflow = errors.New("txn timestamp overflow")

const (
	defaultMigrationExportChunkBytes  = 4 << 20
	defaultMigrationExportScanFactor  = 4
	defaultMigrationExportMaxVersions = 1024

	// Hard server-side ceilings. The defaults above only fill in a bound the
	// request left unset, so without these a caller could ask one
	// ExportVersions call to scan and decode an arbitrary portion of the source
	// store before producing its next streamed response -- for a sparse family
	// or route filter that accepts few rows, math.MaxUint64 removes the only
	// work bound there is and the serving leader's I/O and CPU go with it. A
	// clamped caller simply advances through more cursor rounds, which the
	// response already supports. Same shape as the promotion path's clamp.
	maxMigrationExportChunkBytes = 32 << 20
	maxMigrationExportScanBytes  = maxMigrationExportChunkBytes * defaultMigrationExportScanFactor

	// Headroom for proto framing over the payload bytes a page carries: field
	// tags and length prefixes for at most defaultMigrationExportMaxVersions
	// entries come to tens of kilobytes, so a mebibyte covers them with room
	// to spare.
	migrationExportPageFramingHeadroom = 1 << 20
	migrationExportPageByteBudget      = store.MigrationPagePayloadBudget
)

func (i *Internal) Forward(ctx context.Context, req *pb.ForwardRequest) (*pb.ForwardResponse, error) {
	// Before the leader check, so a non-leader gets the accurate reason and a
	// leader can never reach stampTimestamps and propose.
	if i.kvForwardRejected {
		return nil, forwardUnknownStatus(req.GetRequests(), ErrKVForwardNotSupported)
	}
	if i.leader == nil || i.leader.State() != raftengine.StateLeader {
		return nil, forwardUnknownStatus(req.GetRequests(), kv.ErrLeaderNotFound)
	}
	if err := i.leader.VerifyLeader(ctx); err != nil {
		return nil, forwardUnknownStatus(req.GetRequests(), err)
	}
	if err := rejectUnactivatedBoundForward(req.GetRequests()); err != nil {
		return nil, forwardUnknownStatus(req.GetRequests(), err)
	}

	commitTS, err := i.stampTimestamps(ctx, req)
	if err != nil {
		return &pb.ForwardResponse{
			Success:     false,
			CommitIndex: 0,
		}, forwardUnknownStatus(req.GetRequests(), err)
	}
	if err := kv.StampTimestampAdmission(ctx, i.tsAllocator, i.store, req.GetRequests()); err != nil {
		return nil, forwardUnknownStatus(req.GetRequests(), err)
	}

	r, err := i.transactionManager.Commit(ctx, req.Requests)
	if err != nil {
		return &pb.ForwardResponse{
			Success:     false,
			CommitIndex: 0,
		}, forwardCommitStatus(req.GetRequests(), err)
	}
	if i.forwardWriteObserver != nil {
		i.forwardWriteObserver(req.GetRequests())
	}

	return &pb.ForwardResponse{
		Success:     true,
		CommitIndex: r.CommitIndex,
		CommitTs:    commitTS,
	}, nil
}

func forwardCommitStatus(reqs []*pb.Request, err error) error {
	phase, ok := kv.ForwardFailurePhaseForRequests(reqs)
	var rejected *kv.AppliedRequestRejection
	// Only an indexed, terminal one-phase apply verdict proves this attempt
	// had no effect. The receiver must separately rule out earlier attempts.
	if ok && phase == pb.ForwardFailurePhase_FORWARD_FAILURE_PHASE_ONE_PHASE_APPLY &&
		!errors.Is(err, kv.ErrTransactionOutcomeUnknown) && errors.As(err, &rejected) &&
		rejected.CommitIndex() != 0 && errors.Is(err, store.ErrWriteConflict) {
		return &forwardWireFailure{
			wire: kv.ForwardDecisionStatus(phase, pb.ForwardFailureReason_FORWARD_FAILURE_REASON_CONFLICT,
				pb.ForwardDecisionClass_FORWARD_DECISION_CLASS_DEFINITIVELY_ABORTED),
			cause: err,
		}
	}
	return forwardUnknownStatus(reqs, err)
}

func forwardUnknownStatus(reqs []*pb.Request, err error) error {
	phase, ok := kv.ForwardFailurePhaseForRequests(reqs)
	if !ok {
		return &forwardWireFailure{wire: status.Error(codes.Unknown, "forward outcome unknown"), cause: err}
	}
	reason := pb.ForwardFailureReason_FORWARD_FAILURE_REASON_INTERRUPTED
	switch {
	case errors.Is(err, store.ErrWriteConflict), errors.Is(err, kv.ErrTxnLocked):
		reason = pb.ForwardFailureReason_FORWARD_FAILURE_REASON_CONFLICT
	case errors.Is(err, kv.ErrComposed1Violation), errors.Is(err, kv.ErrComposed1VersionGCd),
		errors.Is(err, kv.ErrRouteWriteFenced), errors.Is(err, kv.ErrRouteWriteTimestampTooLow):
		reason = pb.ForwardFailureReason_FORWARD_FAILURE_REASON_FENCE
	case errors.Is(err, kv.ErrLeaderNotFound), errors.Is(err, raftengine.ErrNotLeader):
		reason = pb.ForwardFailureReason_FORWARD_FAILURE_REASON_NO_LEADER
	}
	return &forwardWireFailure{
		wire:  kv.ForwardDecisionStatus(phase, reason, pb.ForwardDecisionClass_FORWARD_DECISION_CLASS_OUTCOME_UNKNOWN),
		cause: err,
	}
}

type forwardWireFailure struct {
	wire  error
	cause error
}

func (f *forwardWireFailure) Error() string {
	return f.wire.Error()
}

func (f *forwardWireFailure) Unwrap() error {
	return f.cause
}

func (f *forwardWireFailure) GRPCStatus() *status.Status {
	return status.Convert(errors.Cause(f.wire))
}

func (i *Internal) ProbeMigrationState(ctx context.Context, req *pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
	if req == nil || req.GetJobId() == 0 {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "migration probe job_id is required"))
	}
	resp, err := i.probeMigrationStateKind(ctx, req)
	if err != nil {
		return nil, err
	}
	resp.NamespaceAdmissionVersion = i.migrationNamespaceProtocolVersion()
	i.decorateMigrationTransferCapability(req, resp)
	i.bindMigrationProbeConfiguration(req, resp)
	return resp, nil
}

func (i *Internal) decorateMigrationTransferCapability(req *pb.ProbeMigrationStateRequest, resp *pb.ProbeMigrationStateResponse) {
	if i.MigrationTransferSizeGuardSupported() {
		resp.TransferSizeGuardVersion = store.MigrationTransferSizeGuardVersion
	}
	if req.GetTransferSizeGuardVersion() != 0 &&
		(req.GetTransferSizeGuardVersion() != resp.GetTransferSizeGuardVersion() || !i.MigrationTransferSizeGuardReady()) {
		resp.Ready = false
	}
}

func (i *Internal) bindMigrationProbeConfiguration(req *pb.ProbeMigrationStateRequest, resp *pb.ProbeMigrationStateResponse) {
	if !req.GetRequireConfigurationIndex() {
		return
	}
	reader, supported := i.leader.(raftengine.AppliedConfigurationReader)
	if !supported {
		resp.Ready = false
		return
	}
	index, supported := reader.AppliedConfigurationIndex()
	resp.AppliedConfigurationIndex = index
	resp.Ready = resp.GetReady() && supported && index != 0 &&
		(req.GetExpectedConfigurationIndex() == 0 || req.GetExpectedConfigurationIndex() == index)
}

func (i *Internal) probeMigrationStateKind(ctx context.Context, req *pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
	if req.GetKind() == pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_NAMESPACE_ADMISSION {
		return i.probeMigrationNamespace(ctx, req)
	}
	if req.GetKind() == pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_PARTITION_APPLIED {
		return i.probeMigrationPartition(ctx, req)
	}
	if migrationOwnershipProbeKind(req.GetKind()) {
		return i.probeMigrationOwnership(ctx, req)
	}
	return i.probeLegacyMigrationStateKind(ctx, req)
}

func migrationOwnershipProbeKind(kind pb.MigrationStateProbeKind) bool {
	return kind == pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_OWNERSHIP_CAPABILITY ||
		kind == pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_OWNERSHIP_APPLIED
}

func (i *Internal) probeLegacyMigrationStateKind(ctx context.Context, req *pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
	switch req.GetKind() {
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_OWNERSHIP_CAPABILITY,
		pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_OWNERSHIP_APPLIED,
		pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_NAMESPACE_ADMISSION,
		pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_PARTITION_APPLIED:
		return i.probeMigrationStateKind(ctx, req)
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_CONTROL_APPLIED:
		return i.probeMigrationControl(ctx, req)
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_SOURCE_GUARD_PRESENT:
		return i.probeMigrationSourceGuard(ctx, req)
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_TARGET_DESCRIPTOR_CLEARED:
		return i.probeMigrationRoute(req, true), nil
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_SOURCE_ROUTE_REMOVED:
		return i.probeMigrationRoute(req, false), nil
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_SOURCE_READ_DRAINED:
		return i.probeMigrationReadDrain(req), nil
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_METADATA_CLEARED:
		return i.probeMigrationMetadataCleared(ctx, req.GetJobId())
	case pb.MigrationStateProbeKind_MIGRATION_STATE_PROBE_KIND_UNSPECIFIED:
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "migration probe kind is required"))
	default:
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "unknown migration probe kind"))
	}
}

func (i *Internal) probeMigrationReadDrain(req *pb.ProbeMigrationStateRequest) *pb.ProbeMigrationStateResponse {
	return &pb.ProbeMigrationStateResponse{
		Ready:          time.Now().UnixMilli() >= req.GetReadDrainNotBeforeMs() && i.sourceReadsDrained(req.GetReadDrainMinTs()),
		CatalogVersion: i.migrationCatalogVersion(),
	}
}

func (i *Internal) probeMigrationSourceGuard(ctx context.Context, req *pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
	if len(req.GetRouteStart()) == 0 {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "source guard probe requires route_start"))
	}
	if err := i.verifyInternalLeaderApplied(ctx); err != nil {
		return nil, err
	}
	reader, ok := i.store.(store.MigrationTargetReadinessReader)
	if !ok {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "migration readiness reader is not configured"))
	}
	states, err := reader.MigrationTargetReadinessStates(ctx)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	for _, state := range states {
		if migrationSourceGuardMatches(state, req) {
			return &pb.ProbeMigrationStateResponse{Ready: true, CatalogVersion: i.migrationCatalogVersion()}, nil
		}
	}
	return &pb.ProbeMigrationStateResponse{}, nil
}

func migrationSourceGuardMatches(state store.TargetStagedReadinessState, req *pb.ProbeMigrationStateRequest) bool {
	return state.JobID == req.GetJobId() && state.MigrationJobID == req.GetJobId() && state.Armed &&
		(state.TrackWrites || state.SourceWriteFence || state.SourceReadFence) &&
		bytes.Equal(state.RouteStart, req.GetRouteStart()) && bytes.Equal(state.RouteEnd, normalizeOptionalEnd(req.GetRouteEnd()))
}

// sourceReadsDrained reports whether every read that could still observe the
// migrating range on this node has finished. The read tracker is process-wide,
// so unrelated frontend reads would otherwise keep it non-empty forever on a
// busy node. Reads issued after the source read fence armed carry a timestamp
// above drainMinTS and are already rejected for the moving range, so only
// older pins block the drain. A zero drainMinTS means the control plane did
// not supply the fence point (pre-upgrade coordinator), so fall back to
// requiring a fully empty tracker.
func (i *Internal) sourceReadsDrained(drainMinTS uint64) bool {
	if i.readTracker == nil {
		return true
	}
	oldest := i.readTracker.Oldest()
	if oldest == 0 {
		return true
	}
	if drainMinTS == 0 {
		return false
	}
	return oldest > drainMinTS
}

func (i *Internal) IssueMigrationTimestamp(ctx context.Context, _ *pb.IssueMigrationTimestampRequest) (*pb.IssueMigrationTimestampResponse, error) {
	if err := i.verifyInternalLeaderApplied(ctx); err != nil {
		return nil, err
	}
	if i.store == nil {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "migration timestamp store is not configured"))
	}
	lastCommitTS := i.store.LastCommitTS()
	ts, err := i.nextTimestampAfter(ctx, lastCommitTS, "issue migration timestamp")
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return &pb.IssueMigrationTimestampResponse{Timestamp: ts, LastCommitTs: lastCommitTS}, nil
}

func (i *Internal) probeMigrationControl(ctx context.Context, req *pb.ProbeMigrationStateRequest) (*pb.ProbeMigrationStateResponse, error) {
	reader, ok := i.store.(store.MigrationTargetReadinessReader)
	if !ok {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "migration readiness reader is not configured"))
	}
	states, err := reader.MigrationTargetReadinessStates(ctx)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	for _, state := range states {
		if state.JobID != req.GetJobId() {
			continue
		}
		ready := migrationControlMatches(state, req)
		return &pb.ProbeMigrationStateResponse{Ready: ready, CatalogVersion: i.migrationCatalogVersion(), MinAdmittedTs: state.MinAdmittedTS}, nil
	}
	return &pb.ProbeMigrationStateResponse{CatalogVersion: i.migrationCatalogVersion()}, nil
}

func migrationControlMatches(state store.TargetStagedReadinessState, req *pb.ProbeMigrationStateRequest) bool {
	return state.Armed &&
		bytes.Equal(state.RouteStart, req.GetRouteStart()) &&
		bytes.Equal(state.RouteEnd, normalizeOptionalEnd(req.GetRouteEnd())) &&
		state.ExpectedCutoverVersion == req.GetExpectedCatalogVersion() &&
		state.MigrationJobID == req.GetMigrationJobId() &&
		state.MinWriteTSExclusive == req.GetMinWriteTsExclusive() &&
		migrationControlModesMatch(state, req) &&
		(req.GetTransferSizeGuardVersion() == 0 || state.TransferSizeGuardVersion == req.GetTransferSizeGuardVersion()) &&
		state.RetentionPinTS == req.GetRetentionPinTs()
}

func migrationControlModesMatch(state store.TargetStagedReadinessState, req *pb.ProbeMigrationStateRequest) bool {
	return state.SourceWriteFence == req.GetSourceWriteFence() && state.SourceReadFence == req.GetSourceReadFence() &&
		state.TrackWrites == req.GetTrackWrites()
}

func (i *Internal) probeMigrationRoute(req *pb.ProbeMigrationStateRequest, requireCleared bool) *pb.ProbeMigrationStateResponse {
	version := i.migrationCatalogVersion()
	if i.routeEngine == nil || version < req.GetExpectedCatalogVersion() {
		return &pb.ProbeMigrationStateResponse{CatalogVersion: version}
	}
	route, found := i.routeEngine.GetRoute(req.GetRouteStart())
	ready := found && route.GroupID == req.GetExpectedGroupId() &&
		bytes.Equal(route.Start, req.GetRouteStart()) &&
		bytes.Equal(route.End, normalizeOptionalEnd(req.GetRouteEnd()))
	if requireCleared {
		ready = ready && !route.StagedVisibilityActive && route.MigrationJobID == 0 &&
			route.MinWriteTSExclusive == req.GetMinWriteTsExclusive()
	}
	return &pb.ProbeMigrationStateResponse{Ready: ready, CatalogVersion: version}
}

func (i *Internal) probeMigrationMetadataCleared(ctx context.Context, jobID uint64) (*pb.ProbeMigrationStateResponse, error) {
	reader, supported := i.store.(store.MigrationRetirementReader)
	if !supported {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "migration retirement proof is unavailable"))
	}
	retired, err := reader.MigrationRetired(ctx, jobID)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if !retired {
		return &pb.ProbeMigrationStateResponse{CatalogVersion: i.migrationCatalogVersion()}, nil
	}
	present, err := i.migrationReadinessMetadataPresent(ctx, jobID)
	if err != nil {
		return nil, err
	}
	if present {
		return &pb.ProbeMigrationStateResponse{CatalogVersion: i.migrationCatalogVersion()}, nil
	}
	present, err = i.migrationPromotionMetadataPresent(ctx, jobID)
	if err != nil {
		return nil, err
	}
	if present {
		return &pb.ProbeMigrationStateResponse{CatalogVersion: i.migrationCatalogVersion()}, nil
	}
	present, err = i.migrationImportMetadataPresent(ctx, jobID)
	if err != nil {
		return nil, err
	}
	if present {
		return &pb.ProbeMigrationStateResponse{CatalogVersion: i.migrationCatalogVersion()}, nil
	}
	return &pb.ProbeMigrationStateResponse{Ready: true, CatalogVersion: i.migrationCatalogVersion()}, nil
}

func (i *Internal) migrationReadinessMetadataPresent(ctx context.Context, jobID uint64) (bool, error) {
	readiness, ok := i.store.(store.MigrationTargetReadinessReader)
	if !ok {
		return false, errors.WithStack(status.Error(codes.FailedPrecondition, "migration readiness reader is not configured"))
	}
	states, err := readiness.MigrationTargetReadinessStates(ctx)
	if err != nil {
		return false, errors.WithStack(err)
	}
	for _, state := range states {
		if state.JobID == jobID {
			return true, nil
		}
	}
	return false, nil
}

func (i *Internal) migrationPromotionMetadataPresent(ctx context.Context, jobID uint64) (bool, error) {
	promotion, ok := i.store.(store.MigrationPromotionStateReader)
	if !ok {
		return false, errors.WithStack(status.Error(codes.FailedPrecondition, "migration promotion reader is not configured"))
	}
	_, found, err := promotion.MigrationPromotionState(ctx, jobID)
	if err != nil {
		return false, errors.WithStack(err)
	}
	return found, nil
}

func (i *Internal) migrationImportMetadataPresent(ctx context.Context, jobID uint64) (bool, error) {
	importMetadata, ok := i.store.(store.MigrationImportMetadataReader)
	if !ok {
		return false, errors.WithStack(status.Error(codes.FailedPrecondition, "migration import metadata reader is not configured"))
	}
	present, err := importMetadata.MigrationImportMetadataPresent(ctx, jobID)
	if err != nil {
		return false, errors.WithStack(err)
	}
	return present, nil
}

func (i *Internal) migrationCatalogVersion() uint64 {
	if i.routeEngine == nil {
		return 0
	}
	return i.routeEngine.Version()
}

func normalizeOptionalEnd(end []byte) []byte {
	if len(end) == 0 {
		return nil
	}
	return end
}

func (i *Internal) ForwardAdminProposal(
	ctx context.Context,
	req *pb.ForwardAdminProposalRequest,
) (*pb.ForwardAdminProposalResponse, error) {
	if i.leader == nil || i.leader.State() != raftengine.StateLeader {
		return nil, errors.WithStack(ErrNotLeader)
	}
	if err := i.leader.VerifyLeader(ctx); err != nil {
		return nil, errors.WithStack(ErrNotLeader)
	}
	if ts, ok, err := kv.DecodeWatermarkAdvance(req.GetPayload()); ok {
		return i.forwardReadWatermarkAdvance(ctx, req.GetPayload(), ts, req.GetForceEntry(), err)
	}
	if req.GetForceEntry() {
		return nil, errors.WithStack(status.Error(codes.PermissionDenied, "force-entry forwarding is only valid for read watermark advances"))
	}
	if reply, matched, err := i.forwardBootstrapActivation(ctx, req); matched {
		return reply, err
	}
	return i.forwardSupportedAdminProposal(ctx, req)
}

func (i *Internal) forwardSupportedAdminProposal(ctx context.Context, req *pb.ForwardAdminProposalRequest) (*pb.ForwardAdminProposalResponse, error) {
	if i.adminProposer == nil {
		return nil, errors.New("admin proposer is unavailable")
	}
	if err := kv.ValidateForwardedAdminPayload(req.GetPayload()); err != nil {
		return nil, errors.WithStack(status.Error(codes.PermissionDenied, "admin forwarding requires a supported typed admin entry"))
	}
	result, err := i.adminProposer.ProposeAdmin(ctx, req.GetPayload())
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if err := forwardedAdminProposalResponseError(result); err != nil {
		return nil, err
	}
	return &pb.ForwardAdminProposalResponse{CommitIndex: result.CommitIndex}, nil
}

// forwardReadWatermarkAdvance applies a read-watermark advance a follower
// forwarded before serving a snapshot read on this group. Ordinary reads are
// a no-op when the group already covers ts; explicit receipt requests force a
// new entry. Both modes refuse timestamps beyond the HLC bound.
func (i *Internal) forwardReadWatermarkAdvance(
	ctx context.Context,
	payload []byte,
	ts uint64,
	forceEntry bool,
	decodeErr error,
) (*pb.ForwardAdminProposalResponse, error) {
	if decodeErr != nil {
		return nil, errors.WithStack(status.Error(codes.PermissionDenied, "admin forwarding requires a supported typed admin entry"))
	}
	if !forceEntry && i.store != nil && ts <= i.store.LastCommitTS() {
		return &pb.ForwardAdminProposalResponse{}, nil
	}
	if i.readWatermarkProposer == nil {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "read watermark advance is not enabled on this node"))
	}
	// The wall clock only bounds how far ahead an advance may reach, the
	// same role it has as the input to the physical ceiling.
	if !kv.ReadWatermarkAdvanceAdmissible(time.Now().UnixMilli(), ts) {
		return nil, errors.WithStack(status.Errorf(codes.FailedPrecondition,
			"read watermark advance to %d is ahead of this leader's clock", ts))
	}
	result, err := i.readWatermarkProposer.ProposeAdmin(ctx, payload)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if err := forwardedAdminProposalResponseError(result); err != nil {
		return nil, err
	}
	return &pb.ForwardAdminProposalResponse{CommitIndex: result.CommitIndex}, nil
}

func (i *Internal) ForwardLeaseRead(
	ctx context.Context,
	_ *pb.ForwardLeaseReadRequest,
) (*pb.ForwardLeaseReadResponse, error) {
	if i.leader == nil || i.leader.State() != raftengine.StateLeader {
		return nil, errors.WithStack(ErrNotLeader)
	}
	index, err := i.leader.LinearizableRead(ctx)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	lastCommitTS := uint64(0)
	if i.lastCommitTimestamp != nil {
		lastCommitTS = i.lastCommitTimestamp()
	}
	return &pb.ForwardLeaseReadResponse{AppliedIndex: index, LastCommitTs: lastCommitTS}, nil
}

func forwardedAdminProposalResponseError(result *raftengine.ProposalResult) error {
	if result == nil {
		return errors.New("admin proposal returned nil result")
	}
	if result.Response == nil {
		return nil
	}
	if err, ok := result.Response.(error); ok {
		if errors.Is(err, kv.ErrTooManyActiveBackups) {
			return status.Errorf(codes.ResourceExhausted, "%s", kv.ErrTooManyActiveBackups)
		}
		return errors.WithStack(err)
	}
	return errors.Errorf("unexpected admin proposal response %T", result.Response)
}

func (i *Internal) RelayPublish(_ context.Context, req *pb.RelayPublishRequest) (*pb.RelayPublishResponse, error) {
	if req == nil || i.relay == nil {
		return &pb.RelayPublishResponse{}, nil
	}
	return &pb.RelayPublishResponse{
		Subscribers: i.relay.Publish(req.Channel, req.Message),
	}, nil
}

func (i *Internal) ExportRangeVersions(req *pb.ExportRangeVersionsRequest, stream pb.Internal_ExportRangeVersionsServer) error {
	if err := i.validateExportRangeVersionsRequest(req); err != nil {
		return err
	}
	if err := i.verifyInternalLeaderApplied(stream.Context()); err != nil {
		return err
	}
	return i.streamExportRangeVersions(req, stream)
}

func (i *Internal) validateExportRangeVersionsRequest(req *pb.ExportRangeVersionsRequest) error {
	if req == nil {
		return errors.WithStack(status.Error(codes.InvalidArgument, "export range versions request is nil"))
	}
	if i.store == nil {
		return errors.WithStack(status.Error(codes.FailedPrecondition, "migration export store is not configured"))
	}
	if req.GetMaxCommitTs() == 0 {
		return errors.WithStack(status.Error(codes.InvalidArgument, "migration export max_commit_ts is required"))
	}
	if req.GetKeyFamily() == 0 {
		return errors.WithStack(status.Error(codes.InvalidArgument, "migration export key_family is required"))
	}
	if exportRangeVersionsRequestRouteUnbounded(req) {
		return errors.WithStack(status.Error(codes.InvalidArgument, "migration export requires route bounds"))
	}
	return nil
}

func exportRangeVersionsRequestRouteUnbounded(req *pb.ExportRangeVersionsRequest) bool {
	return len(req.GetRouteStart()) == 0 &&
		len(req.GetRouteEnd()) == 0
}

func (i *Internal) streamExportRangeVersions(req *pb.ExportRangeVersionsRequest, stream pb.Internal_ExportRangeVersionsServer) error {
	opts := i.exportRangeVersionsOptions(req)
	for pages := uint32(1); ; pages++ {
		result, err := i.store.ExportVersions(stream.Context(), opts)
		if err != nil {
			return errors.WithStack(err)
		}
		if !result.Done && bytes.Equal(opts.Cursor, result.NextCursor) {
			return errors.WithStack(status.Error(codes.Internal, "migration export cursor did not progress"))
		}
		resp, err := migrationExportResponse(result, req.GetPreflightOnly())
		if err != nil {
			return err
		}
		if err := stream.Send(resp); err != nil {
			return errors.WithStack(err)
		}
		// A caller that checkpoints one page must not trigger another scan
		// while cancelling this stream. Preserve the resumable cursor/Done.
		if result.Done || (req.GetMaxPages() != 0 && pages >= req.GetMaxPages()) {
			return nil
		}
		opts.Cursor = result.NextCursor
	}
}

// checkMigrationExportPageSize refuses to send a page the transport cannot
// carry. The store's MaxBytes budget is only consulted after a version has
// been appended, and storage accepts values far above the message limit
// (store.maxSnapshotValueSize is 256 MiB against internal.GRPCMaxMessageBytes'
// 64 MiB), so a single oversized row can land in an otherwise bounded page.
// Sending it fails with ResourceExhausted, and so does every retry of the same
// cursor -- the bracket never completes and the error says nothing about which
// row is responsible. Naming the row instead keeps the failure diagnosable.
// Carrying values that large needs a chunked migration wire format, which is a
// protocol change rather than a fix here.
func checkMigrationExportPageSize(resp *pb.ExportRangeVersionsResponse) error {
	for _, version := range resp.GetVersions() {
		if !store.MigrationVersionFitsTransfer(version.GetKey(), version.GetValue()) {
			return migrationOversizedVersionError(version)
		}
	}
	if migrationExportPagePayloadBytes(resp) <= migrationExportPageByteBudget {
		return nil
	}
	widest := widestMigrationExportVersion(resp.GetVersions())
	return errors.WithStack(status.Errorf(codes.FailedPrecondition,
		"migration export page exceeds the %d byte message limit; key %q holds %d value bytes",
		internal.GRPCMaxMessageBytes, widest.GetKey(), len(widest.GetValue())))
}

// migrationExportPagePayloadBytes sums the caller-controlled bytes in a page.
// It deliberately undercounts the proto framing rather than calling
// proto.Size, which caches its result inside the message; the budget carries
// enough headroom to cover the framing of a full page.
func migrationExportPagePayloadBytes(resp *pb.ExportRangeVersionsResponse) int {
	total := len(resp.GetNextCursor())
	for _, version := range resp.GetVersions() {
		total += len(version.GetKey()) + len(version.GetValue())
	}
	return total
}

func widestMigrationExportVersion(versions []*pb.MVCCVersion) *pb.MVCCVersion {
	var widest *pb.MVCCVersion
	for _, version := range versions {
		if widest == nil || len(version.GetValue()) > len(widest.GetValue()) {
			widest = version
		}
	}
	return widest
}

func (i *Internal) ImportRangeVersions(ctx context.Context, req *pb.ImportRangeVersionsRequest) (*pb.ImportRangeVersionsResponse, error) {
	if req == nil {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "import range versions request is nil"))
	}
	if err := validateImportRangeVersionsRequest(req); err != nil {
		return nil, err
	}
	if err := i.verifyMigrationImportProposal(ctx); err != nil {
		return nil, err
	}
	if err := i.requireMigrationNamespaceAdmission(ctx); err != nil {
		return nil, err
	}
	result, err := i.proposeMigrationImport(ctx, req)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if i.clock != nil && result.MaxImportedTS > 0 {
		i.clock.Observe(result.MaxImportedTS)
	}
	return &pb.ImportRangeVersionsResponse{AckedCursor: result.AckedCursor, Duplicate: result.Duplicate}, nil
}

func validateImportRangeVersionsRequest(req *pb.ImportRangeVersionsRequest) error {
	if req.GetJobId() == 0 {
		return errors.WithStack(status.Error(codes.InvalidArgument, "import range versions job_id is required"))
	}
	if req.GetBracketId() == 0 {
		return errors.WithStack(status.Error(codes.InvalidArgument, "import range versions bracket_id is required"))
	}
	return nil
}

func (i *Internal) verifyMigrationImportEnabled(ctx context.Context) error {
	if i.migrationImportGate == nil {
		return nil
	}
	if err := i.migrationImportGate(ctx); err != nil {
		return errors.WithStack(err)
	}
	return nil
}

func (i *Internal) PromoteStagedVersions(ctx context.Context, req *pb.PromoteStagedVersionsRequest) (*pb.PromoteStagedVersionsResponse, error) {
	if req == nil {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "promote staged versions request is nil"))
	}
	if req.GetJobId() == 0 {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "promote staged versions job_id is required"))
	}
	if err := i.verifyMigrationPromoteProposal(ctx); err != nil {
		return nil, err
	}
	if err := validatePromoteStagedVersionsRequest(req); err != nil {
		return nil, errors.WithStack(err)
	}
	if err := i.requireMigrationNamespaceAdmission(ctx); err != nil {
		return nil, err
	}
	result, err := i.proposeMigrationPromote(ctx, req)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if i.clock != nil && result.MaxPromotedTS > 0 {
		i.clock.Observe(result.MaxPromotedTS)
	}
	return &pb.PromoteStagedVersionsResponse{
		NextCursor:    result.NextCursor,
		Done:          result.Done,
		PromotedRows:  result.PromotedRows,
		MaxPromotedTs: result.MaxPromotedTS,
	}, nil
}

func (i *Internal) ApplyTargetStagedReadiness(ctx context.Context, req *pb.TargetStagedReadinessRequest) (*pb.TargetStagedReadinessResponse, error) {
	if err := validateTargetStagedReadinessRequest(req); err != nil {
		return nil, err
	}
	if err := i.validateTransferSizeGuardActivation(ctx, req); err != nil {
		return nil, err
	}
	if i.migrationProposer == nil {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "target staged readiness proposer is not configured"))
	}
	if err := i.verifyInternalLeader(ctx); err != nil {
		return nil, err
	}
	if err := i.requireMigrationNamespaceAdmission(ctx); err != nil {
		return nil, err
	}
	if err := i.proposeTargetStagedReadiness(ctx, req); err != nil {
		return nil, errors.WithStack(err)
	}
	if req.GetArmed() && i.clock != nil {
		floor := req.GetMinWriteTsExclusive()
		if i.store != nil {
			floor = max(floor, i.store.LastCommitTS())
		}
		i.clock.Observe(floor)
	}
	return &pb.TargetStagedReadinessResponse{MinAdmittedTs: i.migrationMinAdmittedTS(ctx, req.GetJobId())}, nil
}

func (i *Internal) CleanupMigration(ctx context.Context, req *pb.CleanupMigrationRequest) (*pb.CleanupMigrationResponse, error) {
	if req.GetMode() == pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_NAMESPACE_ADMISSION {
		return i.applyMigrationNamespaceAdmission(ctx, req)
	}
	if err := i.validateMigrationCleanupAdmission(ctx, req); err != nil {
		return nil, err
	}
	if err := i.verifyInternalLeader(ctx); err != nil {
		return nil, err
	}
	if err := i.verifyMigrationCleanupEnabled(ctx); err != nil {
		return nil, err
	}
	result, err := i.proposeMigrationCleanup(ctx, req)
	if err != nil {
		if errors.Is(err, kv.ErrMigrationConfigurationChanged) || errors.Is(err, store.ErrMigrationOwnership) {
			return nil, errors.WithStack(status.Error(codes.Aborted, err.Error()))
		}
		return nil, errors.WithStack(err)
	}
	return &pb.CleanupMigrationResponse{
		NextCursor:   result.NextCursor,
		Done:         result.Done,
		DeletedRows:  result.DeletedRows,
		DeletedBytes: result.DeletedBytes,
		ScannedBytes: result.ScannedBytes,
	}, nil
}

func validateCleanupMigrationRequest(req *pb.CleanupMigrationRequest) error {
	switch {
	case req == nil:
		return errors.WithStack(status.Error(codes.InvalidArgument, "migration cleanup request is nil"))
	case req.GetJobId() == 0:
		return errors.WithStack(status.Error(codes.InvalidArgument, "migration cleanup job_id is required"))
	case req.GetMode() != pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_VERSIONS &&
		req.GetMode() != pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_METADATA && !ownershipCleanupMode(req.GetMode()):
		return errors.WithStack(status.Error(codes.InvalidArgument, "migration cleanup mode is invalid"))
	case req.GetMode() == pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_VERSIONS && req.GetKeyFamily() == 0:
		return errors.WithStack(status.Error(codes.InvalidArgument, "migration cleanup key_family is required"))
	}
	if ownershipCleanupMode(req.GetMode()) {
		return validateOwnershipCleanupRequest(req)
	}
	return nil
}

func validateOwnershipCleanupRequest(req *pb.CleanupMigrationRequest) error {
	if req.GetMode() == pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_OWNERSHIP_PARTITION {
		return validatePartitionCleanupRequest(req)
	}
	if !req.GetRequireConfigurationIndex() || req.GetExpectedConfigurationIndex() == 0 {
		return errors.WithStack(status.Error(codes.InvalidArgument, "ownership control requires applied configuration"))
	}
	if _, err := kv.MigrationOwnershipStateFromProto(req.GetJobId(), req.GetOwnership()); err != nil {
		return errors.WithStack(status.Error(codes.InvalidArgument, "invalid migration ownership proof"))
	}
	return nil
}

func (i *Internal) migrationMinAdmittedTS(ctx context.Context, jobID uint64) uint64 {
	reader, ok := i.store.(store.MigrationTargetReadinessReader)
	if !ok {
		return 0
	}
	states, err := reader.MigrationTargetReadinessStates(ctx)
	if err != nil {
		return 0
	}
	for _, state := range states {
		if state.JobID == jobID {
			return state.MinAdmittedTS
		}
	}
	return 0
}

func validateTargetStagedReadinessRequest(req *pb.TargetStagedReadinessRequest) error {
	switch {
	case req == nil:
		return errors.WithStack(status.Error(codes.InvalidArgument, "target staged readiness request is nil"))
	case req.GetJobId() == 0:
		return errors.WithStack(status.Error(codes.InvalidArgument, "target staged readiness job_id is required"))
	case req.GetMigrationJobId() == 0:
		return errors.WithStack(status.Error(codes.InvalidArgument, "target staged readiness migration_job_id is required"))
	case req.GetArmed() && req.GetMinWriteTsExclusive() == 0:
		return errors.WithStack(status.Error(codes.InvalidArgument, "target staged readiness min_write_ts_exclusive is required when armed"))
	}
	return validateSourceMigrationControlRequest(req)
}

func validateSourceMigrationControlRequest(req *pb.TargetStagedReadinessRequest) error {
	if req.GetSourceReadFence() && !req.GetSourceWriteFence() {
		return errors.WithStack(status.Error(codes.InvalidArgument, "source read fence requires source write fence"))
	}
	if (req.GetSourceWriteFence() || req.GetSourceReadFence()) && req.GetRetentionPinTs() == 0 {
		return errors.WithStack(status.Error(codes.InvalidArgument, "source migration control retention_pin_ts is required"))
	}
	return nil
}

func (i *Internal) ProbeMigrationLocks(ctx context.Context, req *pb.ProbeMigrationLocksRequest) (*pb.ProbeMigrationLocksResponse, error) {
	if req == nil || len(req.GetRouteStart()) == 0 {
		return nil, errors.WithStack(status.Error(codes.InvalidArgument, "migration lock probe route_start is required"))
	}
	if i.store == nil {
		return nil, errors.WithStack(status.Error(codes.FailedPrecondition, "migration lock probe store is not configured"))
	}
	if err := i.verifyInternalLeaderApplied(ctx); err != nil {
		return nil, err
	}
	locks, err := kv.PendingTxnLocksInRoute(ctx, i.store, req.GetRouteStart(), req.GetRouteEnd(), ^uint64(0), int(req.GetLimit()))
	if err != nil {
		return nil, errors.WithStack(err)
	}
	return &pb.ProbeMigrationLocksResponse{PendingCount: uint32(len(locks))}, nil //nolint:gosec // result is bounded by uint32 wire limit
}

func (i *Internal) verifyMigrationPromoteEnabled(ctx context.Context) error {
	if i.migrationPromoteGate == nil {
		return nil
	}
	if err := i.migrationPromoteGate(ctx); err != nil {
		return errors.WithStack(err)
	}
	return nil
}

func (i *Internal) verifyMigrationCleanupEnabled(ctx context.Context) error {
	if i.migrationCleanupGate == nil {
		return nil
	}
	if err := i.migrationCleanupGate(ctx); err != nil {
		return errors.WithStack(err)
	}
	return nil
}

func validatePromoteStagedVersionsRequest(req *pb.PromoteStagedVersionsRequest) error {
	prefix := distribution.MigrationStagedDataKeyPrefix(req.GetJobId())
	if err := store.ValidatePromotionCursorForRange(req.GetCursor(), prefix, store.PrefixScanEnd(prefix)); err != nil {
		if errors.Is(err, store.ErrInvalidExportCursor) {
			return errors.WithStack(status.Error(codes.InvalidArgument, store.ErrInvalidExportCursor.Error()))
		}
		return errors.WithStack(status.Errorf(codes.Internal, "validate promote cursor: %v", err))
	}
	return nil
}

func defaultMigrationImportGate(context.Context) error {
	if migrationImportOpcodeEnabledFromEnv() {
		return nil
	}
	return errors.WithStack(status.Error(codes.FailedPrecondition, "migration import opcode is disabled; enable after every voter is running a build that supports migration import"))
}

func migrationImportOpcodeEnabledFromEnv() bool {
	return MigrationImportOpcodeEnabledFromEnv()
}

func defaultMigrationPromoteGate(context.Context) error {
	if migrationPromoteOpcodeEnabledFromEnv() {
		return nil
	}
	return errors.WithStack(status.Error(codes.FailedPrecondition, "migration promote opcode is disabled; enable after every voter is running a build that supports migration promotion"))
}

func defaultMigrationCleanupGate(context.Context) error {
	if MigrationCleanupOpcodeEnabledFromEnv() {
		return nil
	}
	return errors.WithStack(status.Error(codes.FailedPrecondition, "migration cleanup opcode is disabled; enable after every voter is running a build that supports migration cleanup"))
}

func migrationPromoteOpcodeEnabledFromEnv() bool {
	return MigrationPromoteOpcodeEnabledFromEnv()
}

// MigrationImportOpcodeEnabledFromEnv reports whether the staged import opcode
// is enabled for this process.
func MigrationImportOpcodeEnabledFromEnv() bool {
	return envFlagEnabled(MigrationImportOpcodeEnv)
}

// MigrationPromoteOpcodeEnabledFromEnv reports whether the staged promotion
// opcode is enabled for this process.
func MigrationPromoteOpcodeEnabledFromEnv() bool {
	return envFlagEnabled(MigrationPromoteOpcodeEnv)
}

// MigrationCleanupOpcodeEnabledFromEnv reports whether the migration cleanup
// opcode is enabled for this process.
func MigrationCleanupOpcodeEnabledFromEnv() bool {
	return envFlagEnabled(MigrationCleanupOpcodeEnv)
}

func envFlagEnabled(name string) bool {
	switch strings.ToLower(strings.TrimSpace(os.Getenv(name))) {
	case "1", "true", "yes", "on":
		return true
	default:
		return false
	}
}

func (i *Internal) verifyInternalLeader(ctx context.Context) error {
	if i.leader == nil {
		return errors.WithStack(ErrNotLeader)
	}
	if i.leader.State() != raftengine.StateLeader {
		return errors.WithStack(ErrNotLeader)
	}
	if err := i.leader.VerifyLeader(ctx); err != nil {
		return errors.WithStack(ErrNotLeader)
	}
	return nil
}

func (i *Internal) verifyInternalLeaderApplied(ctx context.Context) error {
	if i.leader == nil {
		return errors.WithStack(ErrNotLeader)
	}
	if i.leader.State() != raftengine.StateLeader {
		return errors.WithStack(ErrNotLeader)
	}
	_, err := i.leader.LinearizableRead(ctx)
	return errors.WithStack(err)
}

func (i *Internal) proposeMigrationImport(ctx context.Context, req *pb.ImportRangeVersionsRequest) (store.ImportVersionsResult, error) {
	cmd, err := kv.MarshalMigrationImportCommand(req)
	if err != nil {
		return store.ImportVersionsResult{}, errors.WithStack(err)
	}
	resp, err := i.proposeMigrationCommand(ctx, cmd, "migration import")
	if err != nil {
		return store.ImportVersionsResult{}, errors.WithStack(err)
	}
	switch resp := resp.(type) {
	case store.ImportVersionsResult:
		return resp, nil
	case *store.ImportVersionsResult:
		if resp == nil {
			return store.ImportVersionsResult{}, errors.New("migration import apply returned nil result")
		}
		return *resp, nil
	case error:
		return store.ImportVersionsResult{}, errors.WithStack(resp)
	default:
		return store.ImportVersionsResult{}, errors.WithStack(errors.Newf("unexpected migration import apply response type %T", resp))
	}
}

func (i *Internal) proposeMigrationPromote(ctx context.Context, req *pb.PromoteStagedVersionsRequest) (store.PromoteVersionsResult, error) {
	cmd, err := kv.MarshalMigrationPromoteCommand(req)
	if err != nil {
		return store.PromoteVersionsResult{}, errors.WithStack(err)
	}
	resp, err := i.proposeMigrationCommand(ctx, cmd, "migration promote")
	if err != nil {
		return store.PromoteVersionsResult{}, errors.WithStack(err)
	}
	switch resp := resp.(type) {
	case store.PromoteVersionsResult:
		return resp, nil
	case *store.PromoteVersionsResult:
		if resp == nil {
			return store.PromoteVersionsResult{}, errors.New("migration promote apply returned nil result")
		}
		return *resp, nil
	case error:
		return store.PromoteVersionsResult{}, errors.WithStack(resp)
	default:
		return store.PromoteVersionsResult{}, errors.WithStack(errors.Newf("unexpected migration promote apply response type %T", resp))
	}
}

func (i *Internal) proposeMigrationCleanup(ctx context.Context, req *pb.CleanupMigrationRequest) (store.CleanupVersionsResult, error) {
	cmd, err := kv.MarshalMigrationCleanupCommand(req)
	if err != nil {
		return store.CleanupVersionsResult{}, errors.WithStack(err)
	}
	resp, err := i.proposeMigrationCommand(ctx, cmd, "migration cleanup")
	if err != nil {
		return store.CleanupVersionsResult{}, errors.WithStack(err)
	}
	if req.GetMode() == pb.MigrationCleanupMode_MIGRATION_CLEANUP_MODE_METADATA && resp == nil {
		return store.CleanupVersionsResult{Done: true}, nil
	}
	switch resp := resp.(type) {
	case store.CleanupVersionsResult:
		return resp, nil
	case *store.CleanupVersionsResult:
		if resp == nil {
			return store.CleanupVersionsResult{}, errors.New("migration cleanup apply returned nil result")
		}
		return *resp, nil
	case error:
		return store.CleanupVersionsResult{}, errors.WithStack(resp)
	default:
		return store.CleanupVersionsResult{}, errors.WithStack(errors.Newf("unexpected migration cleanup apply response type %T", resp))
	}
}

func (i *Internal) proposeTargetStagedReadiness(ctx context.Context, req *pb.TargetStagedReadinessRequest) error {
	cmd, err := kv.MarshalTargetStagedReadinessCommand(req)
	if err != nil {
		return errors.WithStack(err)
	}
	resp, err := i.proposeMigrationCommand(ctx, cmd, "target staged readiness")
	if err != nil {
		return errors.WithStack(err)
	}
	if resp == nil {
		return nil
	}
	if err, ok := resp.(error); ok {
		return errors.WithStack(err)
	}
	return errors.WithStack(errors.Newf("unexpected target readiness apply response type %T", resp))
}

func (i *Internal) proposeMigrationCommand(ctx context.Context, cmd []byte, label string) (any, error) {
	result, err := i.migrationProposer.Propose(ctx, cmd)
	if err != nil {
		return nil, errors.WithStack(err)
	}
	if result == nil {
		return nil, errors.WithStack(errors.Newf("%s proposal returned nil result", label))
	}
	return result.Response, nil
}

func (i *Internal) exportRangeVersionsOptions(req *pb.ExportRangeVersionsRequest) store.ExportVersionsOptions {
	chunkBytes := clampMigrationExportBound(
		uint64(req.GetChunkBytes()), defaultMigrationExportChunkBytes, maxMigrationExportChunkBytes)
	maxScannedBytes := clampMigrationExportBound(
		req.GetMaxScannedBytes(), chunkBytes*defaultMigrationExportScanFactor, maxMigrationExportScanBytes)
	startKey, endKey := migrationExportScanBounds(req)
	opts := store.ExportVersionsOptions{
		StartKey:             startKey,
		EndKey:               endKey,
		MinCommitTSExclusive: req.GetMinCommitTs(),
		MaxCommitTSInclusive: req.GetMaxCommitTs(),
		Cursor:               req.GetCursor(),
		MaxVersions:          defaultMigrationExportMaxVersions,
		MaxBytes:             chunkBytes,
		MaxScannedBytes:      maxScannedBytes,
		KeyFamily:            req.GetKeyFamily(),
		AcceptKey:            i.migrationExportFilter(req),
		AcceptVersion:        i.migrationExportVersionFilter(req),
	}
	return opts
}

func migrationExportScanBounds(req *pb.ExportRangeVersionsRequest) ([]byte, []byte) {
	start := bytes.Clone(req.GetRangeStart())
	end := bytes.Clone(req.GetRangeEnd())
	switch req.GetKeyFamily() {
	case distribution.MigrationFamilyFilesystemChunk:
		if bytes.HasPrefix(start, fskeys.ChunkAllPrefix()) {
			return start, end
		}
		if scanStart, scanEnd, ok := filesystemChunkExportScanBounds(req.GetRouteStart(), req.GetRouteEnd()); ok {
			return scanStart, scanEnd
		}
		return fskeys.ChunkAllPrefix(), prefixScanEnd(fskeys.ChunkAllPrefix())
	case distribution.MigrationFamilyFilesystemUsage:
		if bytes.HasPrefix(start, fskeys.UsageRouteAllPrefix()) {
			return start, end
		}
		return filesystemUsageExportScanBounds(req.GetRouteStart(), req.GetRouteEnd())
	default:
		return start, end
	}
}

func filesystemChunkExportScanBounds(routeStart, routeEnd []byte) ([]byte, []byte, bool) {
	routePrefix := fskeys.ChunkRouteAllPrefix()
	routeDomainEnd := prefixScanEnd(routePrefix)
	if !rangesIntersect(routeStart, routeEnd, routePrefix, routeDomainEnd) {
		return fskeys.ChunkAllPrefix(), fskeys.ChunkAllPrefix(), true
	}
	rawPrefix := fskeys.ChunkAllPrefix()
	rawDomainEnd := prefixScanEnd(rawPrefix)
	start := rawPrefix
	if len(routeStart) > 0 && bytes.Compare(routeStart, routePrefix) > 0 {
		if !bytes.HasPrefix(routeStart, routePrefix) {
			return nil, nil, false
		}
		start = append(bytes.Clone(rawPrefix), routeStart[len(routePrefix):]...)
	}
	end := rawDomainEnd
	if len(routeEnd) > 0 && bytes.Compare(routeEnd, routeDomainEnd) < 0 {
		if bytes.Compare(routeEnd, routePrefix) <= 0 {
			return rawPrefix, rawPrefix, true
		}
		if !bytes.HasPrefix(routeEnd, routePrefix) {
			return nil, nil, false
		}
		end = append(bytes.Clone(rawPrefix), routeEnd[len(routePrefix):]...)
	}
	return bytes.Clone(start), bytes.Clone(end), true
}

func filesystemUsageExportScanBounds(routeStart, routeEnd []byte) ([]byte, []byte) {
	start := fskeys.UsageRouteAllPrefix()
	if len(routeStart) > 0 {
		start = fskeys.UsageRouteKey(routeStart)
	}
	end := prefixScanEnd(fskeys.UsageRouteAllPrefix())
	if len(routeEnd) > 0 {
		end = fskeys.UsageRouteKey(routeEnd)
	}
	return start, end
}

// clampMigrationExportBound resolves one export bound: unset takes the default,
// anything above the hard ceiling is clamped down to it.
func clampMigrationExportBound(requested, fallback, ceiling uint64) uint64 {
	if requested == 0 {
		return fallback
	}
	return min(requested, ceiling)
}

func (i *Internal) migrationExportFilter(req *pb.ExportRangeVersionsRequest) func([]byte) bool {
	bracket := migrationExportBracket(req)
	if req.GetKeyFamily() == distribution.MigrationFamilyLegacyListMetaDelta {
		return bracket.ContainsRawKey
	}
	routeFilter := i.migrationExportRouteFilter(req)
	if migrationFamilyRequiresDecodedS3(req.GetKeyFamily()) {
		routeFilter = decodedS3BucketRouteFilter(req.GetKeyFamily(), req.GetRouteStart(), req.GetRouteEnd())
	}
	return func(rawKey []byte) bool {
		return bracket.ContainsRawKey(rawKey) && routeFilter(rawKey)
	}
}

func (i *Internal) migrationExportVersionFilter(req *pb.ExportRangeVersionsRequest) func([]byte, []byte) bool {
	if req.GetKeyFamily() != distribution.MigrationFamilyLegacyListMetaDelta {
		return nil
	}
	bracket := migrationExportBracket(req)
	return func(rawKey, value []byte) bool {
		return bracket.ContainsRoutedVersion(rawKey, value, req.GetRouteStart(), req.GetRouteEnd(), nil)
	}
}

func migrationExportBracket(req *pb.ExportRangeVersionsRequest) distribution.MigrationBracket {
	excludeKnownInternal := req.GetExcludeKnownInternal() || req.GetKeyFamily() == distribution.MigrationFamilyUser
	start, end := migrationExportScanBounds(req)
	return distribution.MigrationBracket{
		Family:               req.GetKeyFamily(),
		Start:                start,
		End:                  end,
		ExcludeKnownInternal: excludeKnownInternal,
		ExcludePrefixes:      cloneByteSlices(req.GetExcludePrefixes()),
	}
}

func (i *Internal) migrationExportRouteFilter(req *pb.ExportRangeVersionsRequest) func([]byte) bool {
	if i != nil && i.migrationExportGroupID != 0 && i.migrationExportResolver != nil {
		return kv.RouteKeyFilterForGroup(req.GetRouteStart(), req.GetRouteEnd(), i.migrationExportGroupID, i.migrationExportResolver)
	}
	return kv.RouteKeyFilter(req.GetRouteStart(), req.GetRouteEnd())
}

func migrationFamilyRequiresDecodedS3(family uint32) bool {
	return family == distribution.MigrationFamilyS3BucketMeta ||
		family == distribution.MigrationFamilyS3BucketGeneration ||
		family == distribution.MigrationFamilyS3BucketCleanup
}

func decodedS3BucketRouteFilter(family uint32, routeStart, routeEnd []byte) func([]byte) bool {
	return func(rawKey []byte) bool {
		bucket, ok := decodedS3BucketName(family, rawKey)
		if !ok {
			return false
		}
		if keyInRouteRange(rawKey, routeStart, routeEnd) {
			return true
		}
		return decodedS3BucketRouteSelected(bucket, routeStart, routeEnd)
	}
}

// decodedS3BucketRouteSelected delegates to the one definition of bucket
// auxiliary ownership. Keeping a second copy here is how the export filter and
// the cleanup bracket drifted apart in the first place.
func decodedS3BucketRouteSelected(bucket string, routeStart, routeEnd []byte) bool {
	return distribution.S3BucketAuxiliaryRouteSelected(bucket, routeStart, routeEnd)
}

func rangesIntersect(aStart, aEnd, bStart, bEnd []byte) bool {
	if len(aEnd) > 0 && bytes.Compare(aEnd, bStart) <= 0 {
		return false
	}
	if len(bEnd) > 0 && bytes.Compare(bEnd, aStart) <= 0 {
		return false
	}
	return true
}

func keyInRouteRange(key, start, end []byte) bool {
	if bytes.Compare(key, start) < 0 {
		return false
	}
	return len(end) == 0 || bytes.Compare(key, end) < 0
}

func decodedS3BucketName(family uint32, rawKey []byte) (string, bool) {
	switch family {
	case distribution.MigrationFamilyS3BucketMeta:
		return s3keys.ParseBucketMetaKey(rawKey)
	case distribution.MigrationFamilyS3BucketGeneration:
		return s3keys.ParseBucketGenerationKey(rawKey)
	case distribution.MigrationFamilyS3BucketCleanup:
		bucket, _, ok := s3keys.ParseBucketCleanupKey(rawKey)
		return bucket, ok
	default:
		return "", false
	}
}

func cloneByteSlices(in [][]byte) [][]byte {
	if len(in) == 0 {
		return nil
	}
	out := make([][]byte, len(in))
	for i := range in {
		out[i] = bytes.Clone(in[i])
	}
	return out
}

func protoMVCCVersionsFromStore(in []store.MVCCVersion) []*pb.MVCCVersion {
	out := make([]*pb.MVCCVersion, 0, len(in))
	for _, version := range in {
		out = append(out, &pb.MVCCVersion{
			Key:       bytes.Clone(version.Key),
			CommitTs:  version.CommitTS,
			Tombstone: version.Tombstone,
			Value:     bytes.Clone(version.Value),
			KeyFamily: version.KeyFamily,
			ExpireAt:  version.ExpireAt,
		})
	}
	return out
}

func (i *Internal) stampTimestamps(ctx context.Context, req *pb.ForwardRequest) (uint64, error) {
	if req == nil {
		return 0, nil
	}
	// The envelope flag decides how the batch is stamped, but
	// TransactionManager.Commit decides how it is applied from the inner
	// requests' own IsTxn. A batch that says raw on the outside and carries a
	// transactional request inside took the raw stamping path -- which only ever
	// looks at Request.Ts -- and then went down the transactional apply path,
	// where the FSM takes the persistence timestamp from a transaction meta
	// nothing validated. Insist the two agree.
	if !forwardedBatchMatchesEnvelope(req.IsTxn, req.Requests) {
		return 0, errors.WithStack(kv.ErrInvalidRequest)
	}
	if req.IsTxn {
		return i.stampTxnTimestamps(ctx, req.Requests)
	}

	return 0, i.stampRawTimestamps(ctx, req.Requests)
}

// forwardedBatchMatchesEnvelope reports whether every inner request agrees with
// the envelope's mode.
//
// It is not enough to ask whether any request is transactional, the way
// TransactionManager.Commit does. That test is an OR, so both mixed shapes slip
// through in one direction or the other:
//
//   - a raw envelope holding a transactional request is stamped raw, which only
//     looks at Request.Ts, then applied transactionally, where the FSM takes the
//     persistence timestamp from an unvalidated transaction meta;
//   - a transactional envelope holding a raw request is stamped with the
//     transaction's start timestamp, then applied raw by commitSequential,
//     persisting at that timestamp without ever passing stampRawTimestamps.
//
// Neither legitimate sender builds a mixed batch -- both set the envelope from
// reqs[0].IsTxn over a batch the coordinator constructed as all raw or all
// transactional -- so requiring agreement costs nothing and closes both shapes.
func forwardedBatchMatchesEnvelope(envelopeIsTxn bool, reqs []*pb.Request) bool {
	for _, r := range reqs {
		if r != nil && r.IsTxn != envelopeIsTxn {
			return false
		}
	}
	return true
}

func (i *Internal) nextTimestamp(ctx context.Context, label string) (uint64, error) {
	if i.tsAllocator != nil {
		ts, err := i.tsAllocator.Next(ctx)
		if err == nil {
			return ts, nil
		}
		if !errors.Is(err, kv.ErrTSOAllocatorRequired) {
			return 0, errors.Wrap(err, label)
		}
	}
	return i.nextLegacyTimestamp(label)
}

func (i *Internal) nextLegacyTimestamp(label string) (uint64, error) {
	if i.clock == nil {
		return 1, nil
	}
	ts, err := i.clock.NextFenced()
	if err != nil {
		return 0, errors.Wrap(err, label)
	}
	return ts, nil
}

func (i *Internal) nextTimestampAfter(ctx context.Context, min uint64, label string) (uint64, error) {
	if min == ^uint64(0) {
		return 0, errors.Wrap(kv.ErrTxnCommitTSRequired, label)
	}
	if i.tsAllocator != nil {
		ts, err := i.nextTimestampAfterFromAllocator(ctx, min, label)
		if err == nil {
			return ts, nil
		}
		if !errors.Is(err, kv.ErrTSOAllocatorRequired) {
			return 0, err
		}
	}
	return i.nextLegacyTimestampAfter(min, label)
}

func (i *Internal) nextLegacyTimestampAfter(min uint64, label string) (uint64, error) {
	if i.clock == nil {
		return min + 1, nil
	}
	i.clock.Observe(min)
	ts, err := i.nextLegacyTimestamp(label)
	if err != nil {
		return 0, err
	}
	if ts <= min {
		return 0, errors.Wrap(kv.ErrTxnCommitTSRequired, label)
	}
	return ts, nil
}

func (i *Internal) nextTimestampAfterFromAllocator(ctx context.Context, min uint64, label string) (uint64, error) {
	if after, ok := i.tsAllocator.(kv.TimestampAfterAllocator); ok {
		ts, err := after.NextAfter(ctx, min)
		if err != nil {
			return 0, errors.Wrap(err, label)
		}
		return ts, nil
	}
	ts, err := i.tsAllocator.Next(ctx)
	if err != nil {
		return 0, errors.Wrap(err, label)
	}
	if ts <= min {
		return 0, errors.Wrap(kv.ErrTxnCommitTSRequired, label)
	}
	return ts, nil
}

func (i *Internal) stampRawTimestamps(ctx context.Context, reqs []*pb.Request) error {
	for _, r := range reqs {
		if r == nil {
			continue
		}
		if r.Ts != 0 {
			// Somebody else already stamped this write. It is the timestamp the
			// value will be persisted under, and this receiver is downstream of
			// the coordinator that would otherwise have validated it, so check
			// it here rather than taking it on trust. The route-floor check
			// below still runs: validation says the timestamp is allocatable,
			// not that the route still accepts a write at it.
			if err := kv.ValidateDurablePersistenceTimestamp(
				ctx, i.tsAllocator, r.Ts, "stampRawTimestamps: forwarded raw ts"); err != nil {
				return errors.WithStack(err)
			}
		} else {
			ts, err := i.nextTimestamp(ctx, "stampRawTimestamps")
			if err != nil {
				return err
			}
			r.Ts = ts
		}
		// The follower that forwarded this write could not run the route-floor
		// check: its own stamping path bails out when the group engine is not
		// leader, so the timestamp only exists once we assign it here. Without
		// this the write would reach Raft through the bare TransactionManager
		// below with no MinWriteTSExclusive check at all. Already-stamped
		// requests are re-checked too, because the floor may have advanced
		// since the sender stamped them.
		if err := i.ensureRawWriteAllowed(r); err != nil {
			return err
		}
	}
	return nil
}

func (i *Internal) ensureRawWriteAllowed(r *pb.Request) error {
	if i.writeGate == nil || r == nil {
		return nil
	}
	return errors.WithStack(i.writeGate.EnsureMutationsWriteAllowed(r.Mutations, r.Ts))
}

func (i *Internal) stampTxnTimestamps(ctx context.Context, reqs []*pb.Request) (uint64, error) {
	startTS := forwardedTxnStartTS(reqs)
	if startTS == 0 {
		ts, err := i.nextTimestamp(ctx, "stampTxnTimestamps startTS")
		if err != nil {
			return 0, err
		}
		startTS = ts
	} else if err := i.validateForwardedTxnStartForPhase(ctx, reqs, startTS); err != nil {
		// A PREPARE carries no transaction meta, so the commit-timestamp check
		// below never sees it -- yet handlePrepareRequest persists the intent at
		// this value.
		return 0, errors.WithStack(err)
	}
	if startTS == ^uint64(0) {
		return 0, errors.WithStack(ErrTxnTimestampOverflow)
	}

	// Assign the unified timestamp to all requests in the transaction.
	for _, r := range reqs {
		if r != nil {
			r.Ts = startTS
		}
	}

	if err := i.validateForwardedPrepareEvidence(ctx, reqs, startTS); err != nil {
		return 0, err
	}
	commitTS, err := i.fillForwardedTxnCommitTS(ctx, reqs, startTS)
	if err != nil {
		return 0, err
	}
	if err := i.ensureTxnWritesAllowed(reqs, commitTS); err != nil {
		return 0, err
	}
	return commitTS, nil
}

func (i *Internal) validateForwardedTxnStartForPhase(ctx context.Context, reqs []*pb.Request, startTS uint64) error {
	const label = "stampTxnTimestamps: forwarded start ts"
	if forwardedTxnCreationsHavePrepareProof(reqs) {
		err := kv.ValidateDurablePersistenceTimestamp(ctx, i.tsAllocator, startTS, label)
		if errors.Is(err, kv.ErrTSOTimestampPrePhaseD) {
			// Applied-read vouchers can legitimately retain an old startTS.
			// The chosen commit proof and current admission epoch are validated
			// before proposing; no legacy creation-window exemption is needed.
			return nil
		}
		return errors.WithStack(err)
	}
	if forwardedTxnResolutionOnly(reqs) {
		err := kv.ValidateDurablePersistenceTimestamp(ctx, i.tsAllocator, startTS, label)
		if errors.Is(err, kv.ErrTSOTimestampPrePhaseD) || errors.Is(err, kv.ErrTSOPhaseDInactive) {
			return nil // Existing intents may need COMMIT or ABORT after the creation window closes.
		}
		return errors.WithStack(err)
	}
	return errors.WithStack(kv.ValidateForwardedTxnStartTimestamp(ctx, i.tsAllocator, startTS, label))
}

func forwardedTxnResolutionOnly(reqs []*pb.Request) bool {
	seen := false
	for _, r := range reqs {
		if r == nil {
			continue
		}
		if !r.IsTxn || (r.Phase != pb.Phase_COMMIT && r.Phase != pb.Phase_ABORT) {
			return false
		}
		seen = true
	}
	return seen
}

func (i *Internal) ensureTxnWritesAllowed(reqs []*pb.Request, commitTS uint64) error {
	if i.writeGate == nil || commitTS == 0 {
		return nil
	}
	for _, r := range reqs {
		if r == nil || !r.IsTxn {
			continue
		}
		if r.Phase != pb.Phase_COMMIT && r.Phase != pb.Phase_NONE {
			continue
		}
		muts := forwardedTxnUserMutations(r.Mutations)
		if len(muts) == 0 {
			continue
		}
		if err := i.writeGate.EnsureMutationsWriteAllowed(muts, commitTS); err != nil {
			return errors.WithStack(err)
		}
	}
	return nil
}

func forwardedTxnUserMutations(muts []*pb.Mutation) []*pb.Mutation {
	out := make([]*pb.Mutation, 0, len(muts))
	metaPrefix := []byte(kv.TxnMetaPrefix)
	for _, mut := range muts {
		if mut == nil || bytes.HasPrefix(mut.Key, metaPrefix) {
			continue
		}
		out = append(out, mut)
	}
	return out
}

func forwardedTxnStartTS(reqs []*pb.Request) uint64 {
	for _, r := range reqs {
		if r != nil && r.Ts != 0 {
			return r.Ts
		}
	}
	return 0
}

func forwardedTxnMetaMutation(r *pb.Request, metaPrefix []byte) (*pb.Mutation, bool) {
	if r == nil || !r.IsTxn {
		return nil, false
	}
	if r.Phase != pb.Phase_COMMIT && r.Phase != pb.Phase_ABORT && r.Phase != pb.Phase_NONE {
		return nil, false
	}
	if len(r.Mutations) == 0 || r.Mutations[0] == nil {
		return nil, false
	}
	if !bytes.HasPrefix(r.Mutations[0].Key, metaPrefix) {
		return nil, false
	}
	return r.Mutations[0], true
}

type forwardedTxnMetaToUpdate struct {
	m    *pb.Mutation
	meta kv.TxnMeta
}

func (i *Internal) fillForwardedTxnCommitTS(ctx context.Context, reqs []*pb.Request, startTS uint64) (uint64, error) {
	metaMutations, commitTS, resolution, err := collectForwardedTxnMetas(reqs)
	if err != nil {
		return 0, err
	}

	if commitTS == 0 && len(metaMutations) > 0 {
		commitTS, err = i.forwardedTxnCommitTS(ctx, startTS)
		if err != nil {
			return 0, err
		}
	} else if err := kv.ValidateForwardedTxnCommitTimestamp(
		ctx, i.tsAllocator, startTS, commitTS, resolution,
		"fillForwardedTxnCommitTS: forwarded commit ts", func(ctx context.Context, pending bool) error {
			return i.verifyCommitEvidence(ctx, reqs, startTS, commitTS, pending)
		}); err != nil {
		// A commit timestamp that arrived already set in the transaction meta
		// is the timestamp every mutation in this batch is persisted under, and
		// it never passed through the coordinator's own validation. A legacy
		// transaction still being resolved replays a pre-Phase-D pair, which the
		// validator admits; see ValidateForwardedTxnCommitTimestamp.
		return 0, errors.WithStack(err)
	}

	for _, item := range metaMutations {
		item.meta.CommitTS = commitTS
		item.m.Value = kv.EncodeTxnMeta(item.meta)
	}
	if err := stampRequestMutationCommitTS(reqs, commitTS); err != nil {
		return 0, err
	}
	return commitTS, nil
}

func stampRequestMutationCommitTS(reqs []*pb.Request, commitTS uint64) error {
	for _, r := range reqs {
		if r == nil {
			continue
		}
		if err := kv.StampMutationCommitTS(r.Mutations, commitTS); err != nil {
			return errors.WithStack(err)
		}
	}
	return nil
}

// collectForwardedTxnMetas also reports whether an already-set commit timestamp
// arrived on a resolution request. Only COMMIT and ABORT replay a timestamp the
// primary recorded; Phase_NONE is a one-phase transaction that chose its own and
// has no recorded intent behind it.
func collectForwardedTxnMetas(reqs []*pb.Request) ([]forwardedTxnMetaToUpdate, uint64, bool, error) {
	metaMutations := make([]forwardedTxnMetaToUpdate, 0, len(reqs))
	var commitTS uint64
	// Starts true and is narrowed by every meta that carries the timestamp; a
	// batch with no such meta leaves commitTS zero, and the caller allocates.
	resolution := true
	prefix := []byte(kv.TxnMetaPrefix)
	for _, r := range reqs {
		m, ok := forwardedTxnMetaMutation(r, prefix)
		if !ok {
			continue
		}
		meta, err := kv.DecodeTxnMeta(m.Value)
		if err != nil {
			continue
		}
		// Narrowed for every meta, not only the ones that arrive carrying a
		// timestamp. commitSequential applies the requests in order, and a
		// zero-valued Phase_NONE meta is filled with the selected timestamp
		// below -- so it receives the exemption just as surely as one that
		// carried the value in, and a one-phase write would persist under a
		// resolution's exemption either way.
		resolution = resolution && (r.Phase == pb.Phase_COMMIT || r.Phase == pb.Phase_ABORT)
		if meta.CommitTS != 0 {
			if commitTS != 0 && commitTS != meta.CommitTS {
				return nil, 0, false, errors.WithStack(kv.ErrInvalidRequest)
			}
			commitTS = meta.CommitTS
			continue
		}
		metaMutations = append(metaMutations, forwardedTxnMetaToUpdate{m: m, meta: meta})
	}
	return metaMutations, commitTS, resolution, nil
}

// forwardedTxnCommitTS allocates a commit timestamp for a forwarded
// transaction, strictly greater than startTS. Pulled out of
// fillForwardedTxnCommitTS so that function stays under cyclop.
func (i *Internal) forwardedTxnCommitTS(ctx context.Context, startTS uint64) (uint64, error) {
	commitTS := startTS + 1
	if commitTS == 0 {
		// Overflow: can't choose a commit timestamp strictly greater than startTS.
		return 0, errors.WithStack(ErrTxnTimestampOverflow)
	}
	if i.clock != nil {
		i.clock.Observe(startTS)
	}
	if i.tsAllocator != nil || i.clock != nil {
		ts, err := i.nextTimestampAfter(ctx, startTS, "fillForwardedTxnCommitTS")
		if err != nil {
			return 0, err
		}
		commitTS = ts
	}
	if commitTS <= startTS {
		// Defensive: avoid writing an invalid CommitTS.
		return 0, errors.WithStack(ErrTxnTimestampOverflow)
	}
	return commitTS, nil
}
